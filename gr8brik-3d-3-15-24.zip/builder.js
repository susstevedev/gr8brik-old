!(function (e) {
    function t(n) {
        if (r[n]) return r[n].exports;
        var o = (r[n] = { i: n, l: !1, exports: {} });
        return e[n].call(o.exports, o, o.exports, t), (o.l = !0), o.exports;
    }
    var r = {};
    (t.m = e),
        (t.c = r),
        (t.d = function (e, r, n) {
            t.o(e, r) || Object.defineProperty(e, r, { enumerable: !0, get: n });
        }),
        (t.r = function (e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
        }),
        (t.t = function (e, r) {
            if ((1 & r && (e = t(e)), 8 & r)) return e;
            if (4 & r && "object" == typeof e && e && e.__esModule) return e;
            var n = Object.create(null);
            if ((t.r(n), Object.defineProperty(n, "default", { enumerable: !0, value: e }), 2 & r && "string" != typeof e))
                for (var o in e)
                    t.d(
                        n,
                        o,
                        function (t) {
                            return e[t];
                        }.bind(null, o)
                    );
            return n;
        }),
        (t.n = function (e) {
            var r =
                e && e.__esModule
                    ? function () {
                          return e.default;
                      }
                    : function () {
                          return e;
                      };
            return t.d(r, "a", r), r;
        }),
        (t.o = function (e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }),
        (t.p = ""),
        t((t.s = 131));
})([
    function (e, t, r) {
        "use strict";
        e.exports = r(134);
    },
    function (module, exports, __webpack_require__) {
        "use strict";
        var evalAllowed = !1;
        try {
            eval("evalAllowed = true");
        } catch (e) {}
        var platformSupported = !!Object.setPrototypeOf && evalAllowed;
        module.exports = __webpack_require__(133);
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.ReactCSS = t.loop = t.handleActive = t.handleHover = t.hover = void 0);
        var o = n(r(157)),
            a = n(r(230)),
            i = n(r(255)),
            l = n(r(256)),
            u = n(r(257)),
            s = n(r(258));
        (t.hover = l.default), (t.handleHover = l.default), (t.handleActive = u.default), (t.loop = s.default);
        var c = (t.ReactCSS = function (e) {
            for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
            var l = (0, o.default)(r),
                u = (0, a.default)(e, l);
            return (0, i.default)(u);
        });
        t.default = c;
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            r.d(t, "a", function () {
                return n;
            }),
                r.d(t, "b", function () {
                    return o;
                }),
                r.d(t, "c", function () {
                    return a;
                }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var n = 25,
                o = [
                    { x: 1, z: 1 },
                    { x: 2, z: 1 },
                    { x: 2, z: 2 },
                    { x: 3, z: 1 },
                    { x: 3, z: 2 },
                    { x: 4, z: 1 },
                    { x: 4, z: 2 },
                ],
                a = ["#FF0000", "#FF9800", "#F0E100", "#00DE00", "#A1BC24", "#0011CF", "#FFFFFF", "#000000", "#652A0C"];
            !(function () {
                var t = r(1).default,
                    i = r(1).leaveModule;
                t &&
                    (t.register(n, "base", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/constants.js"),
                    t.register(o, "bricks", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/constants.js"),
                    t.register(a, "colors", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/constants.js"),
                    i(e));
            })(),
                (function () {
                    var t = r(1).default,
                        i = r(1).leaveModule;
                    t &&
                        (t.register(n, "base", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/constants.js"),
                        t.register(o, "bricks", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/constants.js"),
                        t.register(a, "colors", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/constants.js"),
                        i(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t) {
        e.exports = function (e) {
            if (!e.webpackPolyfill) {
                var t = Object.create(e);
                t.children || (t.children = []),
                    Object.defineProperty(t, "loaded", {
                        enumerable: !0,
                        get: function () {
                            return t.l;
                        },
                    }),
                    Object.defineProperty(t, "id", {
                        enumerable: !0,
                        get: function () {
                            return t.i;
                        },
                    }),
                    Object.defineProperty(t, "exports", { enumerable: !0 }),
                    (t.webpackPolyfill = 1);
            }
            return t;
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 });
        var o = r(259);
        Object.defineProperty(t, "Alpha", {
            enumerable: !0,
            get: function () {
                return n(o).default;
            },
        });
        var a = r(105);
        Object.defineProperty(t, "Checkboard", {
            enumerable: !0,
            get: function () {
                return n(a).default;
            },
        });
        var i = r(262);
        Object.defineProperty(t, "EditableInput", {
            enumerable: !0,
            get: function () {
                return n(i).default;
            },
        });
        var l = r(263);
        Object.defineProperty(t, "Hue", {
            enumerable: !0,
            get: function () {
                return n(l).default;
            },
        });
        var u = r(265);
        Object.defineProperty(t, "Raised", {
            enumerable: !0,
            get: function () {
                return n(u).default;
            },
        });
        var s = r(266);
        Object.defineProperty(t, "Saturation", {
            enumerable: !0,
            get: function () {
                return n(s).default;
            },
        });
        var c = r(107);
        Object.defineProperty(t, "ColorWrap", {
            enumerable: !0,
            get: function () {
                return n(c).default;
            },
        });
        var p = r(274);
        Object.defineProperty(t, "Swatch", {
            enumerable: !0,
            get: function () {
                return n(p).default;
            },
        });
    },
    function (e, t, r) {
        e.exports = r(148)();
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                return parseInt("0x".concat(e.substring(1)), 16);
            }
            function o(e, t) {
                var r = parseInt(e.substring(1, 3), 16),
                    n = parseInt(e.substring(3, 5), 16),
                    o = parseInt(e.substring(5, 7), 16);
                return (
                    (r = parseInt((r * (100 + t)) / 100)),
                    (n = parseInt((n * (100 + t)) / 100)),
                    (o = parseInt((o * (100 + t)) / 100)),
                    (r = r < 255 ? r : 255),
                    (n = n < 255 ? n : 255),
                    (o = o < 255 ? o : 255),
                    "#" + (1 == r.toString(16).length ? "0" + r.toString(16) : r.toString(16)) + (1 == n.toString(16).length ? "0" + n.toString(16) : n.toString(16)) + (1 == o.toString(16).length ? "0" + o.toString(16) : o.toString(16))
                );
            }
            function a(e) {
                var t = e.x,
                    r = e.y,
                    n = e.z;
                return { width: c.a * t, height: c.a * r || (2 * c.a) / 1.5, depth: c.a * n };
            }
            function i(e) {
                return "".concat(e.x, "x").concat(e.z);
            }
            function l(e) {
                var t = p["B".concat(e.x, "x").concat(e.z)];
                return s.a.createElement(t, null);
            }
            r.d(t, "a", function () {
                return n;
            }),
                r.d(t, "d", function () {
                    return a;
                }),
                r.d(t, "b", function () {
                    return i;
                }),
                r.d(t, "c", function () {
                    return l;
                });
            var u = r(0),
                s = r.n(u),
                c = r(3),
                p = r(43);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).default,
                        u = r(1).leaveModule;
                    t &&
                        (t.register(n, "CSSToHex", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(o, "shadeColor", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(a, "getMeasurementsFromDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(i, "displayNameFromDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(l, "getBrickIconFromDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        u(e));
                })(),
                (function () {
                    var t = r(1).default,
                        u = r(1).leaveModule;
                    t &&
                        (t.register(n, "CSSToHex", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(o, "shadeColor", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(a, "getMeasurementsFromDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(i, "displayNameFromDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        t.register(l, "getBrickIconFromDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/index.js"),
                        u(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t) {
        var r = Array.isArray;
        e.exports = r;
    },
    function (e, t, r) {
        var n = r(77),
            o = "object" == typeof self && self && self.Object === Object && self,
            a = n || o || Function("return this")();
        e.exports = a;
    },
    function (e, t, r) {
        "use strict";
        var n = r(19);
        r.d(t, "d", function () {
            return n.e;
        }),
            r.d(t, "e", function () {
                return n.f;
            }),
            r.d(t, "f", function () {
                return n.g;
            }),
            r.d(t, "h", function () {
                return n.h;
            });
        var o = r(40);
        r.d(t, "i", function () {
            return o.b;
        });
        var a = r(16);
        r.d(t, "a", function () {
            return a.f;
        }),
            r.d(t, "b", function () {
                return a.g;
            }),
            r.d(t, "c", function () {
                return a.h;
            }),
            r.d(t, "g", function () {
                return a.i;
            }),
            r.d(t, "j", function () {
                return a.j;
            });
    },
    function (e, t) {
        e.exports = function (e) {
            return null != e && "object" == typeof e;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            var t = typeof e;
            return null != e && ("object" == t || "function" == t);
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.red = void 0);
        var o = n(r(271)),
            a = n(r(273));
        t.default = {
            simpleCheckForValidColor: function (e) {
                var t = ["r", "g", "b", "a", "h", "s", "l", "v"],
                    r = 0,
                    n = 0;
                return (
                    (0, o.default)(t, function (t) {
                        e[t] && ((r += 1), isNaN(e[t]) || (n += 1));
                    }),
                    r === n && e
                );
            },
            toState: function (e, t) {
                var r = e.hex ? (0, a.default)(e.hex) : (0, a.default)(e),
                    n = r.toHsl(),
                    o = r.toHsv(),
                    i = r.toRgb(),
                    l = r.toHex();
                return 0 === n.s && ((n.h = t || 0), (o.h = t || 0)), { hsl: n, hex: "000000" === l && 0 === i.a ? "transparent" : "#" + l, rgb: i, hsv: o, oldHue: e.h || t || n.h, source: e.source };
            },
            isValidHex: function (e) {
                return (0, a.default)(e).isValid();
            },
        };
        t.red = { hsl: { a: 1, h: 0, l: 0.5, s: 1 }, hex: "#ff0000", rgb: { r: 255, g: 0, b: 0, a: 1 }, hsv: { h: 0, s: 1, v: 1, a: 1 } };
    },
    function (e, t, r) {
        var n = r(87),
            o = r(170),
            a = r(228),
            i = r(8);
        e.exports = function (e, t) {
            return (i(e) ? n : a)(e, o(t, 3));
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e, t, r) {
            function o() {
                h === _ && (h = _.slice());
            }
            function a() {
                return p;
            }
            function i(e) {
                if ("function" != typeof e) throw new Error("Expected listener to be a function.");
                var t = !0;
                return (
                    o(),
                    h.push(e),
                    function () {
                        if (t) {
                            (t = !1), o();
                            var r = h.indexOf(e);
                            h.splice(r, 1);
                        }
                    }
                );
            }
            function l(e) {
                if (!Object(c.a)(e)) throw new Error("Actions must be plain objects. Use custom middleware for async actions.");
                if (void 0 === e.type) throw new Error('Actions may not have an undefined "type" property. Have you misspelled a constant?');
                if (b) throw new Error("Reducers may not dispatch actions.");
                try {
                    (b = !0), (p = s(p, e));
                } finally {
                    b = !1;
                }
                for (var t = (_ = h), r = 0; r < t.length; r++) (0, t[r])();
                return e;
            }
            var u;
            if (("function" == typeof t && void 0 === r && ((r = t), (t = void 0)), void 0 !== r)) {
                if ("function" != typeof r) throw new Error("Expected the enhancer to be a function.");
                return r(n)(e, t);
            }
            if ("function" != typeof e) throw new Error("Expected the reducer to be a function.");
            var s = e,
                p = t,
                _ = [],
                h = _,
                b = !1;
            return (
                l({ type: d.INIT }),
                (u = {
                    dispatch: l,
                    subscribe: i,
                    getState: a,
                    replaceReducer: function (e) {
                        if ("function" != typeof e) throw new Error("Expected the nextReducer to be a function.");
                        (s = e), l({ type: d.INIT });
                    },
                }),
                (u[f.a] = function () {
                    var e,
                        t = i;
                    return (
                        (e = {
                            subscribe: function (e) {
                                function r() {
                                    e.next && e.next(a());
                                }
                                if ("object" != typeof e) throw new TypeError("Expected the observer to be an object.");
                                return r(), { unsubscribe: t(r) };
                            },
                        }),
                        (e[f.a] = function () {
                            return this;
                        }),
                        e
                    );
                }),
                u
            );
        }
        function o(e, t) {
            var r = t && t.type;
            return (
                "Given action " +
                ((r && '"' + r.toString() + '"') || "an action") +
                ', reducer "' +
                e +
                '" returned undefined. To ignore an action, you must explicitly return the previous state. If you want this reducer to hold no value, you can return null instead of undefined.'
            );
        }
        function a(e) {
            Object.keys(e).forEach(function (t) {
                var r = e[t];
                if (void 0 === r(void 0, { type: d.INIT }))
                    throw new Error(
                        'Reducer "' +
                            t +
                            "\" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined."
                    );
                if (void 0 === r(void 0, { type: "@@redux/PROBE_UNKNOWN_ACTION_" + Math.random().toString(36).substring(7).split("").join(".") }))
                    throw new Error(
                        'Reducer "' +
                            t +
                            "\" returned undefined when probed with a random type. Don't try to handle " +
                            d.INIT +
                            ' or other actions in "redux/*" namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined, but can be null.'
                    );
            });
        }
        function i(e) {
            for (var t = Object.keys(e), r = {}, n = 0; n < t.length; n++) {
                var i = t[n];
                "function" == typeof e[i] && (r[i] = e[i]);
            }
            var l = Object.keys(r),
                u = void 0;
            try {
                a(r);
            } catch (e) {
                u = e;
            }
            return function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments[1];
                if (u) throw u;
                for (var n = !1, a = {}, i = 0; i < l.length; i++) {
                    var s = l[i],
                        c = r[s],
                        p = e[s],
                        f = c(p, t);
                    if (void 0 === f) {
                        var d = o(s, t);
                        throw new Error(d);
                    }
                    (a[s] = f), (n = n || f !== p);
                }
                return n ? a : e;
            };
        }
        function l(e, t) {
            return function () {
                return t(e.apply(void 0, arguments));
            };
        }
        function u(e, t) {
            if ("function" == typeof e) return l(e, t);
            if ("object" != typeof e || null === e)
                throw new Error("bindActionCreators expected an object or a function, instead received " + (null === e ? "null" : typeof e) + '. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?');
            for (var r = Object.keys(e), n = {}, o = 0; o < r.length; o++) {
                var a = r[o],
                    i = e[a];
                "function" == typeof i && (n[a] = l(i, t));
            }
            return n;
        }
        function s() {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
            return 0 === t.length
                ? function (e) {
                      return e;
                  }
                : 1 === t.length
                ? t[0]
                : t.reduce(function (e, t) {
                      return function () {
                          return e(t.apply(void 0, arguments));
                      };
                  });
        }
        var c = r(23),
            p = r(63),
            f = r.n(p),
            d = { INIT: "@@redux/INIT" };
        Object.assign;
        r.d(t, "d", function () {
            return n;
        }),
            r.d(t, "b", function () {
                return i;
            }),
            r.d(t, "a", function () {
                return u;
            }),
            r.d(t, "c", function () {
                return s;
            });
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                return { type: u, payload: { brick: e } };
            }
            function o(e) {
                return { type: s, payload: { id: e } };
            }
            function a(e) {
                return { type: c, payload: { brick: e } };
            }
            function i() {
                return { type: p };
            }
            function l(e) {
                return { type: f, payload: { bricks: e } };
            }
            r.d(t, "a", function () {
                return u;
            }),
                r.d(t, "f", function () {
                    return n;
                }),
                r.d(t, "b", function () {
                    return s;
                }),
                r.d(t, "g", function () {
                    return o;
                }),
                r.d(t, "e", function () {
                    return c;
                }),
                r.d(t, "j", function () {
                    return a;
                }),
                r.d(t, "c", function () {
                    return p;
                }),
                r.d(t, "h", function () {
                    return i;
                }),
                r.d(t, "d", function () {
                    return f;
                }),
                r.d(t, "i", function () {
                    return l;
                }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var u = "ADD_BRICK",
                s = "REMOVE_BRICK",
                c = "UPDATE_BRICK",
                p = "RESET_SCENE",
                f = "SET_SCENE";
            !(function () {
                var t = r(1).default,
                    d = r(1).leaveModule;
                t &&
                    (t.register(u, "ADD_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(n, "addBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(s, "REMOVE_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(o, "removeBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(c, "UPDATE_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(a, "updateBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(p, "RESET_SCENE", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(i, "resetScene", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(f, "SET_SCENE", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    t.register(l, "setScene", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                    d(e));
            })(),
                (function () {
                    var t = r(1).default,
                        d = r(1).leaveModule;
                    t &&
                        (t.register(u, "ADD_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(n, "addBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(s, "REMOVE_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(o, "removeBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(c, "UPDATE_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(a, "updateBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(p, "RESET_SCENE", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(i, "resetScene", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(f, "SET_SCENE", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        t.register(l, "setScene", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/scene.js"),
                        d(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        var n = r(24),
            o = r(159),
            a = r(160),
            i = "[object Null]",
            l = "[object Undefined]",
            u = n ? n.toStringTag : void 0;
        e.exports = function (e) {
            return null == e ? (void 0 === e ? l : i) : u && u in Object(e) ? o(e) : a(e);
        };
    },
    function (e, t, r) {
        var n = r(183),
            o = r(186);
        e.exports = function (e, t) {
            var r = o(e, t);
            return n(r) ? r : void 0;
        };
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                return { type: l, payload: { mode: e } };
            }
            function o(e) {
                return { type: u, payload: { color: e } };
            }
            function a() {
                return { type: s };
            }
            function i(e) {
                return { type: c, payload: { brick: e } };
            }
            r.d(t, "c", function () {
                return l;
            }),
                r.d(t, "g", function () {
                    return n;
                }),
                r.d(t, "b", function () {
                    return u;
                }),
                r.d(t, "f", function () {
                    return o;
                }),
                r.d(t, "d", function () {
                    return s;
                }),
                r.d(t, "h", function () {
                    return a;
                }),
                r.d(t, "a", function () {
                    return c;
                }),
                r.d(t, "e", function () {
                    return i;
                }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var l = "SET_MODE",
                u = "SET_COLOR",
                s = "TOGGLE_GRID",
                c = "SET_BRICK";
            !(function () {
                var t = r(1).default,
                    p = r(1).leaveModule;
                t &&
                    (t.register(l, "SET_MODE", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    t.register(n, "setMode", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    t.register(u, "SET_COLOR", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    t.register(o, "setColor", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    t.register(s, "TOGGLE_GRID", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    t.register(a, "toggleGrid", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    t.register(c, "SET_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    t.register(i, "setBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                    p(e));
            })(),
                (function () {
                    var t = r(1).default,
                        p = r(1).leaveModule;
                    t &&
                        (t.register(l, "SET_MODE", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        t.register(n, "setMode", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        t.register(u, "SET_COLOR", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        t.register(o, "setColor", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        t.register(s, "TOGGLE_GRID", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        t.register(a, "toggleGrid", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        t.register(c, "SET_BRICK", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        t.register(i, "setBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/builder.js"),
                        p(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        var n = r(68);
        r.d(t, "b", function () {
            return n.a;
        }),
            r.d(t, "d", function () {
                return n.b;
            }),
            r.d(t, "e", function () {
                return n.c;
            }),
            r.d(t, "f", function () {
                return n.d;
            });
        var o = r(69);
        r.d(t, "a", function () {
            return o.a;
        });
        var a = r(70);
        r.d(t, "c", function () {
            return a.a;
        });
    },
    function (e, t, r) {
        "use strict";
        var n = r(73);
        r.d(t, "f", function () {
            return n.a;
        });
        var o = r(41);
        r.d(t, "d", function () {
            return o.b;
        });
        var a = r(74);
        r.d(t, "b", function () {
            return a.a;
        });
        var i = r(75);
        r.d(t, "a", function () {
            return i.a;
        }),
            r.d(t, "c", function () {
                return i.b;
            });
        var l = r(76);
        r.d(t, "e", function () {
            return l.a;
        });
    },
    function (e, t) {
        e.exports = function (e) {
            return (
                e.webpackPolyfill ||
                    ((e.deprecate = function () {}),
                    (e.paths = []),
                    e.children || (e.children = []),
                    Object.defineProperty(e, "loaded", {
                        enumerable: !0,
                        get: function () {
                            return e.l;
                        },
                    }),
                    Object.defineProperty(e, "id", {
                        enumerable: !0,
                        get: function () {
                            return e.i;
                        },
                    }),
                    (e.webpackPolyfill = 1)),
                e
            );
        };
    },
    function (e, t, r) {
        "use strict";
        var n = r(110),
            o = "object" == typeof self && self && self.Object === Object && self,
            a = (n.a || o || Function("return this")()).Symbol,
            i = Object.prototype,
            l = i.hasOwnProperty,
            u = i.toString,
            s = a ? a.toStringTag : void 0,
            c = function (e) {
                var t = l.call(e, s),
                    r = e[s];
                try {
                    e[s] = void 0;
                    var n = !0;
                } catch (e) {}
                var o = u.call(e);
                return n && (t ? (e[s] = r) : delete e[s]), o;
            },
            p = Object.prototype.toString,
            f = function (e) {
                return p.call(e);
            },
            d = "[object Null]",
            _ = "[object Undefined]",
            h = a ? a.toStringTag : void 0,
            b = function (e) {
                return null == e ? (void 0 === e ? _ : d) : h && h in Object(e) ? c(e) : f(e);
            },
            m = (function (e, t) {
                return function (r) {
                    return e(t(r));
                };
            })(Object.getPrototypeOf, Object),
            g = function (e) {
                return null != e && "object" == typeof e;
            },
            v = "[object Object]",
            y = Function.prototype,
            E = Object.prototype,
            C = y.toString,
            k = E.hasOwnProperty,
            P = C.call(Object);
        t.a = function (e) {
            if (!g(e) || b(e) != v) return !1;
            var t = m(e);
            if (null === t) return !0;
            var r = k.call(t, "constructor") && t.constructor;
            return "function" == typeof r && r instanceof r && C.call(r) == P;
        };
    },
    function (e, t, r) {
        var n = r(9).Symbol;
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(79),
            o = r(167),
            a = r(31);
        e.exports = function (e) {
            return a(e) ? n(e) : o(e);
        };
    },
    function (e, t, r) {
        var n;
        !(function (o, a) {
            "use strict";
            var i = {};
            (o.PubSub = i),
                a(i),
                void 0 !==
                    (n = function () {
                        return i;
                    }.call(t, r, t, e)) && (e.exports = n);
        })(("object" == typeof window && window) || this, function (e) {
            "use strict";
            function t(e) {
                var t;
                for (t in e) if (e.hasOwnProperty(t)) return !0;
                return !1;
            }
            function r(e) {
                return function () {
                    throw e;
                };
            }
            function n(e, t, n) {
                try {
                    e(t, n);
                } catch (e) {
                    setTimeout(r(e), 0);
                }
            }
            function o(e, t, r) {
                e(t, r);
            }
            function a(e, t, r, a) {
                var i,
                    l = s[t],
                    u = a ? o : n;
                if (s.hasOwnProperty(t)) for (i in l) l.hasOwnProperty(i) && u(l[i], e, r);
            }
            function i(e, t, r) {
                return function () {
                    var n = String(e),
                        o = n.lastIndexOf(".");
                    for (a(e, e, t, r); -1 !== o; ) (o = (n = n.substr(0, o)).lastIndexOf(".")), a(e, n, t, r);
                };
            }
            function l(e) {
                for (var r = String(e), n = Boolean(s.hasOwnProperty(r) && t(s[r])), o = r.lastIndexOf("."); !n && -1 !== o; ) (o = (r = r.substr(0, o)).lastIndexOf(".")), (n = Boolean(s.hasOwnProperty(r) && t(s[r])));
                return n;
            }
            function u(e, t, r, n) {
                var o = i(e, t, n);
                return !!l(e) && (!0 === r ? o() : setTimeout(o, 0), !0);
            }
            var s = {},
                c = -1;
            (e.publish = function (t, r) {
                return u(t, r, !1, e.immediateExceptions);
            }),
                (e.publishSync = function (t, r) {
                    return u(t, r, !0, e.immediateExceptions);
                }),
                (e.subscribe = function (e, t) {
                    if ("function" != typeof t) return !1;
                    s.hasOwnProperty(e) || (s[e] = {});
                    var r = "uid_" + String(++c);
                    return (s[e][r] = t), r;
                }),
                (e.clearAllSubscriptions = function () {
                    s = {};
                }),
                (e.clearSubscriptions = function (e) {
                    var t;
                    for (t in s) s.hasOwnProperty(t) && 0 === t.indexOf(e) && delete s[t];
                }),
                (e.unsubscribe = function (t) {
                    var r,
                        n,
                        o,
                        a =
                            "string" == typeof t &&
                            (s.hasOwnProperty(t) ||
                                (function (e) {
                                    var t;
                                    for (t in s) if (s.hasOwnProperty(t) && 0 === t.indexOf(e)) return !0;
                                    return !1;
                                })(t)),
                        i = !a && "string" == typeof t,
                        l = "function" == typeof t,
                        u = !1;
                    {
                        if (!a) {
                            for (r in s)
                                if (s.hasOwnProperty(r)) {
                                    if (((n = s[r]), i && n[t])) {
                                        delete n[t], (u = t);
                                        break;
                                    }
                                    if (l) for (o in n) n.hasOwnProperty(o) && n[o] === t && (delete n[o], (u = !0));
                                }
                            return u;
                        }
                        e.clearSubscriptions(t);
                    }
                });
        });
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
        var n = (function (e) {
            return e && e.__esModule ? e : { default: e };
        })(r(0));
        t.default = function (e) {
            var t = e.cond,
                r = e.children,
                o = e.inline,
                a = e.style,
                i = e.className,
                l = e.component,
                u = n.default.Children.toArray(r).length;
            return t
                ? i || a || l || o
                    ? (console.warn("Using className, style, component or inline props in If component is deprecated. In future versions, the If component would only return the children."),
                      l
                          ? n.default.createElement(l, { style: a, className: i })
                          : 1 === u
                          ? n.default.cloneElement(r)
                          : o
                          ? n.default.createElement("span", { style: a, className: i }, r)
                          : n.default.createElement("div", { style: a, className: i }, r))
                    : r
                : null;
        };
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _toConsumableArray(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = new Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r;
                }
                return Array.from(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            function createMesh(e, t, r, n, o) {
                var a = [],
                    i = new THREE.BoxGeometry(t - 0.1, r - 0.1, n - 0.1),
                    l = new THREE.CylinderGeometry(knobSize, knobSize, knobSize, 20),
                    u = new THREE.Mesh(i, e);
                a.push(u), (u.castShadow = !0), (u.receiveShadow = !0);
                for (var s = 0; s < o.x; s++)
                    for (var c = 0; c < o.z; c++) {
                        var p = new THREE.Mesh(l, e);
                        (p.position.x = utils_constants__WEBPACK_IMPORTED_MODULE_4__.a * s - ((o.x - 1) * utils_constants__WEBPACK_IMPORTED_MODULE_4__.a) / 2),
                            (p.position.y = utils_constants__WEBPACK_IMPORTED_MODULE_4__.a / 1.5),
                            (p.position.z = utils_constants__WEBPACK_IMPORTED_MODULE_4__.a * c - ((o.z - 1) * utils_constants__WEBPACK_IMPORTED_MODULE_4__.a) / 2),
                            (p.castShadow = !0),
                            (p.receiveShadow = !0),
                            a.push(p);
                    }
                return [Object(utils_threejs__WEBPACK_IMPORTED_MODULE_1__.a)(a), e];
            }
            __webpack_require__.d(__webpack_exports__, "a", function () {
                return Brick;
            });
            var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(114),
                uuid__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(uuid__WEBPACK_IMPORTED_MODULE_0__),
                utils_threejs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(115),
                utils_threejs_BufferSubdivisionModifier__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(154),
                utils_threejs_BufferSubdivisionModifier__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(utils_threejs_BufferSubdivisionModifier__WEBPACK_IMPORTED_MODULE_2__),
                utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7),
                utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var knobSize = 7,
                Brick = (function (_THREE$Mesh) {
                    function Brick(e, t, r, n, o) {
                        var a, i;
                        _classCallCheck(this, Brick);
                        var l = new THREE.MeshStandardMaterial({ color: Object(utils__WEBPACK_IMPORTED_MODULE_3__.a)(t), metalness: 0.4, roughness: 0.5 }),
                            u = Object(utils__WEBPACK_IMPORTED_MODULE_3__.d)(r),
                            s = u.height,
                            c = u.width,
                            p = u.depth,
                            f = createMesh(l, c, s, p, r);
                        i = _possibleConstructorReturn(this, (a = Brick.__proto__ || Object.getPrototypeOf(Brick)).call.apply(a, [this].concat(_toConsumableArray(f))));
                        var d = r.x % 2 == 0,
                            _ = r.z % 2 == 0;
                        return (
                            (i.height = s),
                            (i.width = c),
                            (i.depth = p),
                            i.position.copy(e.point).add(e.face.normal),
                            i.position
                                .divide(new THREE.Vector3(utils_constants__WEBPACK_IMPORTED_MODULE_4__.a, s, utils_constants__WEBPACK_IMPORTED_MODULE_4__.a))
                                .floor()
                                .multiply(new THREE.Vector3(utils_constants__WEBPACK_IMPORTED_MODULE_4__.a, s, utils_constants__WEBPACK_IMPORTED_MODULE_4__.a))
                                .add(
                                    new THREE.Vector3(
                                        d ? utils_constants__WEBPACK_IMPORTED_MODULE_4__.a : utils_constants__WEBPACK_IMPORTED_MODULE_4__.a / 2,
                                        s / 2,
                                        _ ? utils_constants__WEBPACK_IMPORTED_MODULE_4__.a : utils_constants__WEBPACK_IMPORTED_MODULE_4__.a / 2
                                    )
                                ),
                            (i.rotation.y = n),
                            i.geometry.translate(o, 0, o),
                            (i.castShadow = !0),
                            (i.receiveShadow = !0),
                            (i.customId = uuid__WEBPACK_IMPORTED_MODULE_0___default()()),
                            (i.defaultColor = l.color),
                            (i._intersect = e),
                            (i._color = t),
                            (i._dimensions = r),
                            (i._rotation = n),
                            (i._translation = o),
                            i
                        );
                    }
                    return (
                        _inherits(Brick, _THREE$Mesh),
                        _createClass(Brick, [
                            {
                                key: "updateColor",
                                value: function (e) {
                                    this.material.setValues({ color: Object(utils__WEBPACK_IMPORTED_MODULE_3__.a)(e) }), (this.defaultColor = this.material.color), (this._color = e);
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        Brick
                    );
                })(THREE.Mesh);
            !(function () {
                var e = __webpack_require__(1).default,
                    t = __webpack_require__(1).leaveModule;
                e &&
                    (e.register(knobSize, "knobSize", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Brick.js"),
                    e.register(Brick, "Brick", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Brick.js"),
                    e.register(createMesh, "createMesh", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Brick.js"),
                    t(module));
            })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Brick, "Brick", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Brick.js"),
                        e.register(createMesh, "createMesh", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Brick.js"),
                        e.register(knobSize, "knobSize", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Brick.js"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            var t = void 0;
            return (
                "undefined" != typeof Reflect && "function" == typeof Reflect.ownKeys
                    ? (t = Reflect.ownKeys(e.prototype))
                    : ((t = Object.getOwnPropertyNames(e.prototype)), "function" == typeof Object.getOwnPropertySymbols && (t = t.concat(Object.getOwnPropertySymbols(e.prototype)))),
                t.forEach(function (t) {
                    if ("constructor" !== t) {
                        var r = Object.getOwnPropertyDescriptor(e.prototype, t);
                        "function" == typeof r.value && Object.defineProperty(e.prototype, t, o(e, t, r));
                    }
                }),
                e
            );
        }
        function o(e, t, r) {
            var n = r.value;
            if ("function" != typeof n) throw new Error("@autobind decorator can only be applied to methods not: " + (void 0 === n ? "undefined" : a(n)));
            var o = !1;
            return {
                configurable: !0,
                get: function () {
                    if (o || this === e.prototype || this.hasOwnProperty(t) || "function" != typeof n) return n;
                    var r = n.bind(this);
                    return (
                        (o = !0),
                        Object.defineProperty(this, t, {
                            configurable: !0,
                            get: function () {
                                return r;
                            },
                            set: function (e) {
                                (n = e), delete this[t];
                            },
                        }),
                        (o = !1),
                        r
                    );
                },
                set: function (e) {
                    n = e;
                },
            };
        }
        Object.defineProperty(t, "__esModule", { value: !0 });
        var a =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                      return typeof e;
                  }
                : function (e) {
                      return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                  };
        t.default = function () {
            return 1 === arguments.length ? n.apply(void 0, arguments) : o.apply(void 0, arguments);
        };
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            var n = r(0),
                o = r.n(n),
                a = r(319),
                i = r.n(a);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var l = function (e) {
                    var t = e.text,
                        r = e.icon,
                        n = e.active,
                        a = e.onClick;
                    return o.a.createElement(
                        "div",
                        { className: n ? i.a.active : i.a.button, onClick: a },
                        o.a.createElement("div", { className: i.a.icon }, o.a.createElement("i", { className: "ion-".concat(r) })),
                        o.a.createElement("div", { className: i.a.text }, t)
                    );
                },
                u = l,
                s = u;
            (t.a = s),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(l, "Button", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Button.jsx"),
                        t.register(u, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Button.jsx"),
                        n(e));
                })(),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(l, "Button", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Button.jsx"),
                        t.register(s, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Button.jsx"),
                        n(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        var n = r(84),
            o = r(50);
        e.exports = function (e) {
            return null != e && o(e.length) && !n(e);
        };
    },
    function (e, t, r) {
        function n(e) {
            var t = -1,
                r = null == e ? 0 : e.length;
            for (this.clear(); ++t < r; ) {
                var n = e[t];
                this.set(n[0], n[1]);
            }
        }
        var o = r(173),
            a = r(174),
            i = r(175),
            l = r(176),
            u = r(177);
        (n.prototype.clear = o), (n.prototype.delete = a), (n.prototype.get = i), (n.prototype.has = l), (n.prototype.set = u), (e.exports = n);
    },
    function (e, t, r) {
        var n = r(56);
        e.exports = function (e, t) {
            for (var r = e.length; r--; ) if (n(e[r][0], t)) return r;
            return -1;
        };
    },
    function (e, t, r) {
        var n = r(18)(Object, "create");
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(195);
        e.exports = function (e, t) {
            var r = e.__data__;
            return n(t) ? r["string" == typeof t ? "string" : "hash"] : r.map;
        };
    },
    function (e, t, r) {
        var n = r(210),
            o = r(57),
            a = r(211),
            i = r(212),
            l = r(213),
            u = r(17),
            s = r(88),
            c = s(n),
            p = s(o),
            f = s(a),
            d = s(i),
            _ = s(l),
            h = u;
        ((n && "[object DataView]" != h(new n(new ArrayBuffer(1)))) || (o && "[object Map]" != h(new o())) || (a && "[object Promise]" != h(a.resolve())) || (i && "[object Set]" != h(new i())) || (l && "[object WeakMap]" != h(new l()))) &&
            (h = function (e) {
                var t = u(e),
                    r = "[object Object]" == t ? e.constructor : void 0,
                    n = r ? s(r) : "";
                if (n)
                    switch (n) {
                        case c:
                            return "[object DataView]";
                        case p:
                            return "[object Map]";
                        case f:
                            return "[object Promise]";
                        case d:
                            return "[object Set]";
                        case _:
                            return "[object WeakMap]";
                    }
                return t;
            }),
            (e.exports = h);
    },
    function (e, t, r) {
        var n = r(17),
            o = r(11),
            a = "[object Symbol]";
        e.exports = function (e) {
            return "symbol" == typeof e || (o(e) && n(e) == a);
        };
    },
    function (e, t, r) {
        var n = r(37),
            o = 1 / 0;
        e.exports = function (e) {
            if ("string" == typeof e || n(e)) return e;
            var t = e + "";
            return "0" == t && 1 / e == -o ? "-0" : t;
        };
    },
    function (e, t, r) {
        var n = r(101),
            o = r(102);
        e.exports = function (e, t, r, a) {
            var i = !r;
            r || (r = {});
            for (var l = -1, u = t.length; ++l < u; ) {
                var s = t[l],
                    c = a ? a(r[s], e[s], s, r, e) : void 0;
                void 0 === c && (c = e[s]), i ? o(r, s, c) : n(r, s, c);
            }
            return r;
        };
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n() {
                return { type: o };
            }
            r.d(t, "a", function () {
                return o;
            }),
                r.d(t, "b", function () {
                    return n;
                }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var o = "TOGGLE_UTILS";
            !(function () {
                var t = r(1).default,
                    a = r(1).leaveModule;
                t && (t.register(o, "TOGGLE_UTILS", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/ui.js"), t.register(n, "toggleUtils", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/ui.js"), a(e));
            })(),
                (function () {
                    var t = r(1).default,
                        a = r(1).leaveModule;
                    t &&
                        (t.register(o, "TOGGLE_UTILS", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/ui.js"),
                        t.register(n, "toggleUtils", "/Users/nick/Documents/Programming/repos/brick-builder/app/actions/ui.js"),
                        a(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            __webpack_require__.d(__webpack_exports__, "b", function () {
                return PerspectiveCamera;
            }),
                __webpack_require__.d(__webpack_exports__, "a", function () {
                    return OrthographicCamera;
                }),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var PerspectiveCamera = (function (_THREE$PerspectiveCam) {
                    function PerspectiveCamera() {
                        return _classCallCheck(this, PerspectiveCamera), _possibleConstructorReturn(this, (PerspectiveCamera.__proto__ || Object.getPrototypeOf(PerspectiveCamera)).apply(this, arguments));
                    }
                    return (
                        _inherits(PerspectiveCamera, _THREE$PerspectiveCam),
                        _createClass(PerspectiveCamera, [
                            {
                                key: "init",
                                value: function () {
                                    this.position.set(-600, 500, 500), this.lookAt(new THREE.Vector3());
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        PerspectiveCamera
                    );
                })(THREE.PerspectiveCamera),
                OrthographicCamera = (function (e) {
                    function t() {
                        return _classCallCheck(this, t), _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
                    }
                    return _inherits(t, THREE.OrthographicCamera), t;
                })();
            !(function () {
                var e = __webpack_require__(1).default,
                    t = __webpack_require__(1).leaveModule;
                e &&
                    (e.register(PerspectiveCamera, "PerspectiveCamera", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Camera.js"),
                    e.register(OrthographicCamera, "OrthographicCamera", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Camera.js"),
                    t(module));
            })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(PerspectiveCamera, "PerspectiveCamera", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Camera.js"),
                        e.register(OrthographicCamera, "OrthographicCamera", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Camera.js"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        "use strict";
        function n() {
            if ("undefined" != typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" == typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)
                try {
                    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n);
                } catch (e) {
                    console.error(e);
                }
        }
        n(), (e.exports = r(138));
    },
    function (e, t, r) {
        "use strict";
        r.r(t),
            function (e) {
                r.d(t, "SimpleBrick", function () {
                    return a;
                }),
                    r.d(t, "B1x1", function () {
                        return i;
                    }),
                    r.d(t, "B2x1", function () {
                        return l;
                    }),
                    r.d(t, "B2x2", function () {
                        return u;
                    }),
                    r.d(t, "B3x1", function () {
                        return s;
                    }),
                    r.d(t, "B3x2", function () {
                        return c;
                    }),
                    r.d(t, "B4x1", function () {
                        return p;
                    }),
                    r.d(t, "B4x2", function () {
                        return f;
                    });
                var n = r(0),
                    o = r.n(n);
                !(function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                    (function () {
                        var t = r(1).enterModule;
                        t && t(e);
                    })();
                var a = function (e) {
                        var t = e.color;
                        return o.a.createElement(
                            "svg",
                            { width: "100%", height: "100%", viewBox: "0 0 36 26" },
                            o.a.createElement(
                                "g",
                                { stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { transform: "translate(-16.000000, -245.000000)", fill: t || "#000000" },
                                    o.a.createElement("path", { d: "M16,248 L52,248 L52,271 L16,271 L16,248 Z M19,245 L30,245 L30,248 L19,248 L19,245 Z M37,245 L48,245 L48,248 L37,248 L37,245 Z", id: "Brick" })
                                )
                            )
                        );
                    },
                    i = function () {
                        return o.a.createElement(
                            "svg",
                            { height: "100%", viewBox: "0 0 55 75" },
                            o.a.createElement(
                                "defs",
                                null,
                                o.a.createElement(
                                    "linearGradient",
                                    { x1: "8.42483761%", y1: "50%", x2: "100%", y2: "62.9645067%", id: "linearGradient-1" },
                                    o.a.createElement("stop", { stopColor: "#FFC058", offset: "0%" }),
                                    o.a.createElement("stop", { stopColor: "#FDB43B", offset: "100%" })
                                )
                            ),
                            o.a.createElement(
                                "g",
                                { id: "Page-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { id: "Desktop", transform: "translate(-723.000000, -266.000000)" },
                                    o.a.createElement(
                                        "g",
                                        { id: "Group-Copy-4", transform: "translate(723.000000, 266.000000)" },
                                        o.a.createElement("polygon", { id: "Rectangle-4", fill: "#EB9507", points: "0.5 20 28 39 28 75 0.5 56" }),
                                        o.a.createElement("polygon", { id: "Rectangle-4-Copy", fill: "#FFC058", points: "27.5 0.5 55 20 28 39 0.5 20" }),
                                        o.a.createElement("polygon", { id: "Rectangle", fill: "#D58400", points: "28 39 55 20 55 56 28 75" }),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy", transform: "translate(16.000000, 6.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        )
                                    )
                                )
                            )
                        );
                    },
                    l = function () {
                        return o.a.createElement(
                            "svg",
                            { height: "100%", viewBox: "0 0 81 93" },
                            o.a.createElement(
                                "defs",
                                null,
                                o.a.createElement(
                                    "linearGradient",
                                    { x1: "8.42483761%", y1: "50%", x2: "100%", y2: "62.9645067%", id: "linearGradient-1" },
                                    o.a.createElement("stop", { stopColor: "#FFC058", offset: "0%" }),
                                    o.a.createElement("stop", { stopColor: "#FDB43B", offset: "100%" })
                                )
                            ),
                            o.a.createElement(
                                "g",
                                { id: "Page-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { id: "Desktop", transform: "translate(-431.000000, -308.000000)" },
                                    o.a.createElement(
                                        "g",
                                        { id: "Group-Copy-5", transform: "translate(471.500000, 354.500000) scale(-1, 1) translate(-471.500000, -354.500000) translate(431.000000, 308.000000)" },
                                        o.a.createElement("polygon", { id: "Rectangle-4", fill: "#EA9100", points: "0 20 54 57 54 93 0 56" }),
                                        o.a.createElement("polygon", { id: "Rectangle-4-Copy", fill: "#FFC058", points: "27 0.5 81 38 54 57 0 20" }),
                                        o.a.createElement("polygon", { id: "Rectangle", fill: "#F5A623", points: "54 57 81 38 81 74 54 93" }),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2", transform: "translate(16.000000, 5.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy", transform: "translate(42.000000, 24.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        )
                                    )
                                )
                            )
                        );
                    },
                    u = function () {
                        return o.a.createElement(
                            "svg",
                            { height: "100%", viewBox: "0 0 110 114", version: "1.1" },
                            o.a.createElement(
                                "defs",
                                null,
                                o.a.createElement(
                                    "linearGradient",
                                    { x1: "8.42483761%", y1: "50%", x2: "100%", y2: "62.9645067%", id: "linearGradient-1" },
                                    o.a.createElement("stop", { stopColor: "#FFC058", offset: "0%" }),
                                    o.a.createElement("stop", { stopColor: "#FDB43B", offset: "100%" })
                                )
                            ),
                            o.a.createElement(
                                "g",
                                { id: "Page-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { id: "Desktop", transform: "translate(-830.000000, -172.000000)" },
                                    o.a.createElement(
                                        "g",
                                        { id: "Group-Copy-3", transform: "translate(830.000000, 172.000000)" },
                                        o.a.createElement("polygon", { id: "Rectangle-4", fill: "#EB9507", points: "0 41 54 78 54 114 0 77" }),
                                        o.a.createElement("polygon", { id: "Rectangle-4-Copy", fill: "#FFC058", points: "55.5 0 109.5 39 54 78 0 41" }),
                                        o.a.createElement("polygon", { id: "Rectangle", fill: "#D58400", points: "54 78 109.5 39 109.5 75 54 114" }),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2", transform: "translate(16.000000, 26.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-2", transform: "translate(43.000000, 6.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy", transform: "translate(42.000000, 45.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-3", transform: "translate(69.000000, 25.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        )
                                    )
                                )
                            )
                        );
                    },
                    s = function () {
                        return o.a.createElement(
                            "svg",
                            { height: "100%", viewBox: "0 0 108 116" },
                            o.a.createElement(
                                "defs",
                                null,
                                o.a.createElement(
                                    "linearGradient",
                                    { x1: "8.42483761%", y1: "50%", x2: "100%", y2: "62.9645067%", id: "linearGradient-1" },
                                    o.a.createElement("stop", { stopColor: "#FFC058", offset: "0%" }),
                                    o.a.createElement("stop", { stopColor: "#FDB43B", offset: "100%" })
                                )
                            ),
                            o.a.createElement(
                                "g",
                                { id: "Page-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { id: "Desktop", transform: "translate(-561.000000, -387.000000)" },
                                    o.a.createElement(
                                        "g",
                                        { id: "Group-Copy-6", transform: "translate(561.000000, 387.000000)" },
                                        o.a.createElement("polygon", { id: "Rectangle-4", fill: "#F5A623", points: "0 60 28 79.5 28 116 0 96" }),
                                        o.a.createElement("polygon", { id: "Rectangle-4-Copy", fill: "#FFC058", points: "80.5 0.5 108 20 28 79.5 0 60" }),
                                        o.a.createElement("polygon", { id: "Rectangle", fill: "#EA9100", points: "28 79.5 108 20 108 56 28 116" }),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2", transform: "translate(16.000000, 45.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-2", transform: "translate(43.000000, 25.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-4", transform: "translate(69.000000, 6.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        )
                                    )
                                )
                            )
                        );
                    },
                    c = function () {
                        return o.a.createElement(
                            "svg",
                            { height: "100%", viewBox: "0 0 136 133" },
                            o.a.createElement(
                                "defs",
                                null,
                                o.a.createElement(
                                    "linearGradient",
                                    { x1: "8.42483761%", y1: "50%", x2: "100%", y2: "62.9645067%", id: "linearGradient-1" },
                                    o.a.createElement("stop", { stopColor: "#FFC058", offset: "0%" }),
                                    o.a.createElement("stop", { stopColor: "#FDB43B", offset: "100%" })
                                )
                            ),
                            o.a.createElement(
                                "g",
                                { id: "Page-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { id: "Desktop", transform: "translate(-642.000000, -57.000000)" },
                                    o.a.createElement(
                                        "g",
                                        { id: "Group-Copy-2", transform: "translate(642.000000, 57.000000)" },
                                        o.a.createElement("polygon", { id: "Rectangle-4", fill: "#EB9507", points: "0 60 54 97 54 133 0 96" }),
                                        o.a.createElement("polygon", { id: "Rectangle-4-Copy", fill: "#FFC058", points: "82 0.5 136 39.5 54 97 0 60" }),
                                        o.a.createElement("polygon", { id: "Rectangle", fill: "#D58400", points: "54 97 136 39.5 136 75.5 54 133" }),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2", transform: "translate(16.000000, 45.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-2", transform: "translate(43.000000, 25.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-4", transform: "translate(69.000000, 6.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy", transform: "translate(42.000000, 64.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-3", transform: "translate(69.000000, 44.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-5", transform: "translate(95.000000, 25.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        )
                                    )
                                )
                            )
                        );
                    },
                    p = function () {
                        return o.a.createElement(
                            "svg",
                            { height: "100%", viewBox: "0 0 135 131" },
                            o.a.createElement(
                                "defs",
                                null,
                                o.a.createElement(
                                    "linearGradient",
                                    { x1: "8.42483761%", y1: "50%", x2: "100%", y2: "62.9645067%", id: "linearGradient-1" },
                                    o.a.createElement("stop", { stopColor: "#FFC058", offset: "0%" }),
                                    o.a.createElement("stop", { stopColor: "#FDB43B", offset: "100%" })
                                )
                            ),
                            o.a.createElement(
                                "g",
                                { id: "Page-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { id: "Desktop", transform: "translate(-524.000000, -324.000000)" },
                                    o.a.createElement(
                                        "g",
                                        { id: "Group-Copy-4", transform: "translate(524.000000, 324.000000)" },
                                        o.a.createElement("polygon", { id: "Rectangle-4", fill: "#EC9B16", points: "0 77 27 96 27 131 0 113" }),
                                        o.a.createElement("polygon", { id: "Rectangle-4-Copy", fill: "#FFC058", points: "108 0 135 20 27 96 0 77" }),
                                        o.a.createElement("polygon", { id: "Rectangle", fill: "#D58400", points: "27 96 135 20 135 56 27 131" }),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2", transform: "translate(16.000000, 62.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-2", transform: "translate(43.000000, 42.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-4", transform: "translate(69.000000, 23.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-6", transform: "translate(97.000000, 5.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        )
                                    )
                                )
                            )
                        );
                    },
                    f = function () {
                        return o.a.createElement(
                            "svg",
                            { height: "100%", viewBox: "0 0 162 150" },
                            o.a.createElement(
                                "defs",
                                null,
                                o.a.createElement(
                                    "linearGradient",
                                    { x1: "8.42483761%", y1: "50%", x2: "100%", y2: "62.9645067%", id: "linearGradient-1" },
                                    o.a.createElement("stop", { stopColor: "#FFC058", offset: "0%" }),
                                    o.a.createElement("stop", { stopColor: "#FDB43B", offset: "100%" })
                                )
                            ),
                            o.a.createElement(
                                "g",
                                { id: "Page-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
                                o.a.createElement(
                                    "g",
                                    { id: "Desktop", transform: "translate(-422.000000, -79.000000)" },
                                    o.a.createElement(
                                        "g",
                                        { id: "Group", transform: "translate(422.000000, 79.000000)" },
                                        o.a.createElement("polygon", { id: "Rectangle-4", fill: "#EB9507", points: "0 77 54 114 54 150 0 113" }),
                                        o.a.createElement("polygon", { id: "Rectangle-4-Copy", fill: "#FFC058", points: "108 0 162 39 54 114 0 77" }),
                                        o.a.createElement("polygon", { id: "Rectangle", fill: "#D58400", points: "54 114 162 39 162 75 54 150" }),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2", transform: "translate(16.000000, 62.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-2", transform: "translate(43.000000, 42.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-4", transform: "translate(69.000000, 23.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-6", transform: "translate(97.000000, 5.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy", transform: "translate(42.000000, 81.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-3", transform: "translate(69.000000, 61.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-5", transform: "translate(95.000000, 42.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        ),
                                        o.a.createElement(
                                            "g",
                                            { id: "Group-2-Copy-7", transform: "translate(123.000000, 24.000000)" },
                                            o.a.createElement("path", {
                                                d:
                                                    "M12,23 C18.627417,23 24,19.418278 24,15 C24,12.1878766 24,9.68787658 24,7.5 L0,7.5 C1.10578213e-13,9.7172403 1.6586732e-13,12.2172403 1.6586732e-13,15 C1.6586732e-13,19.418278 5.372583,23 12,23 Z",
                                                id: "Oval-Copy",
                                                fill: "#EB9507",
                                            }),
                                            o.a.createElement("ellipse", { id: "Oval", fill: "url(#linearGradient-1)", cx: "12", cy: "8", rx: "12", ry: "8" })
                                        )
                                    )
                                )
                            )
                        );
                    };
                !(function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(a, "SimpleBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        t.register(i, "B1x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        t.register(l, "B2x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        t.register(u, "B2x2", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        t.register(s, "B3x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        t.register(c, "B3x2", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        t.register(p, "B4x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        t.register(f, "B4x2", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                        n(e));
                })(),
                    (function () {
                        var t = r(1).default,
                            n = r(1).leaveModule;
                        t &&
                            (t.register(a, "SimpleBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            t.register(i, "B1x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            t.register(l, "B2x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            t.register(u, "B2x2", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            t.register(s, "B3x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            t.register(c, "B3x2", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            t.register(p, "B4x1", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            t.register(f, "B4x2", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Icons.jsx"),
                            n(e));
                    })();
            }.call(this, r(4)(e));
    },
    function (e, t, r) {
        "use strict";
        function n(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function o(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function l() {
            var e = [],
                t = [];
            return {
                clear: function () {
                    (t = F), (e = F);
                },
                notify: function () {
                    for (var r = (e = t), n = 0; n < r.length; n++) r[n]();
                },
                get: function () {
                    return t;
                },
                subscribe: function (r) {
                    var n = !0;
                    return (
                        t === e && (t = e.slice()),
                        t.push(r),
                        function () {
                            n && e !== F && ((n = !1), t === e && (t = e.slice()), t.splice(t.indexOf(r), 1));
                        }
                    );
                },
            };
        }
        function u(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function c(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        function p(e, t) {
            var r = {};
            for (var n in e) t.indexOf(n) >= 0 || (Object.prototype.hasOwnProperty.call(e, n) && (r[n] = e[n]));
            return r;
        }
        function f() {}
        function d(e, t) {
            var r = {
                run: function (n) {
                    try {
                        var o = e(t.getState(), n);
                        (o !== r.props || r.error) && ((r.shouldComponentUpdate = !0), (r.props = o), (r.error = null));
                    } catch (e) {
                        (r.shouldComponentUpdate = !0), (r.error = e);
                    }
                },
            };
            return r;
        }
        function _(e) {
            var t,
                r,
                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                o = n.getDisplayName,
                a =
                    void 0 === o
                        ? function (e) {
                              return "ConnectAdvanced(" + e + ")";
                          }
                        : o,
                i = n.methodName,
                l = void 0 === i ? "connectAdvanced" : i,
                _ = n.renderCountProp,
                h = void 0 === _ ? void 0 : _,
                b = n.shouldHandleStateChanges,
                m = void 0 === b || b,
                g = n.storeKey,
                v = void 0 === g ? "store" : g,
                y = n.withRef,
                E = void 0 !== y && y,
                C = p(n, ["getDisplayName", "methodName", "renderCountProp", "shouldHandleStateChanges", "storeKey", "withRef"]),
                k = v + "Subscription",
                P = K++,
                x = ((t = {}), (t[v] = j), (t[k] = R), t),
                w = ((r = {}), (r[k] = R), r);
            return function (t) {
                L()("function" == typeof t, "You must pass a component to the function returned by connect. Instead received " + JSON.stringify(t));
                var r = t.displayName || t.name || "Component",
                    n = a(r),
                    o = H({}, C, { getDisplayName: a, methodName: l, renderCountProp: h, shouldHandleStateChanges: m, storeKey: v, withRef: E, displayName: n, wrappedComponentName: r, WrappedComponent: t }),
                    i = (function (r) {
                        function a(e, t) {
                            u(this, a);
                            var o = s(this, r.call(this, e, t));
                            return (
                                (o.version = P),
                                (o.state = {}),
                                (o.renderCount = 0),
                                (o.store = e[v] || t[v]),
                                (o.propsMode = Boolean(e[v])),
                                (o.setWrappedInstance = o.setWrappedInstance.bind(o)),
                                L()(o.store, 'Could not find "' + v + '" in either the context or props of "' + n + '". Either wrap the root component in a <Provider>, or explicitly pass "' + v + '" as a prop to "' + n + '".'),
                                o.initSelector(),
                                o.initSubscription(),
                                o
                            );
                        }
                        return (
                            c(a, r),
                            (a.prototype.getChildContext = function () {
                                var e,
                                    t = this.propsMode ? null : this.subscription;
                                return (e = {}), (e[k] = t || this.context[k]), e;
                            }),
                            (a.prototype.componentDidMount = function () {
                                m && (this.subscription.trySubscribe(), this.selector.run(this.props), this.selector.shouldComponentUpdate && this.forceUpdate());
                            }),
                            (a.prototype.componentWillReceiveProps = function (e) {
                                this.selector.run(e);
                            }),
                            (a.prototype.shouldComponentUpdate = function () {
                                return this.selector.shouldComponentUpdate;
                            }),
                            (a.prototype.componentWillUnmount = function () {
                                this.subscription && this.subscription.tryUnsubscribe(), (this.subscription = null), (this.notifyNestedSubs = f), (this.store = null), (this.selector.run = f), (this.selector.shouldComponentUpdate = !1);
                            }),
                            (a.prototype.getWrappedInstance = function () {
                                return L()(E, "To access the wrapped instance, you need to specify { withRef: true } in the options argument of the " + l + "() call."), this.wrappedInstance;
                            }),
                            (a.prototype.setWrappedInstance = function (e) {
                                this.wrappedInstance = e;
                            }),
                            (a.prototype.initSelector = function () {
                                var t = e(this.store.dispatch, o);
                                (this.selector = d(t, this.store)), this.selector.run(this.props);
                            }),
                            (a.prototype.initSubscription = function () {
                                if (m) {
                                    var e = (this.propsMode ? this.props : this.context)[k];
                                    (this.subscription = new W(this.store, e, this.onStateChange.bind(this))), (this.notifyNestedSubs = this.subscription.notifyNestedSubs.bind(this.subscription));
                                }
                            }),
                            (a.prototype.onStateChange = function () {
                                this.selector.run(this.props), this.selector.shouldComponentUpdate ? ((this.componentDidUpdate = this.notifyNestedSubsOnComponentDidUpdate), this.setState(z)) : this.notifyNestedSubs();
                            }),
                            (a.prototype.notifyNestedSubsOnComponentDidUpdate = function () {
                                (this.componentDidUpdate = void 0), this.notifyNestedSubs();
                            }),
                            (a.prototype.isSubscribed = function () {
                                return Boolean(this.subscription) && this.subscription.isSubscribed();
                            }),
                            (a.prototype.addExtraProps = function (e) {
                                if (!(E || h || (this.propsMode && this.subscription))) return e;
                                var t = H({}, e);
                                return E && (t.ref = this.setWrappedInstance), h && (t[h] = this.renderCount++), this.propsMode && this.subscription && (t[k] = this.subscription), t;
                            }),
                            (a.prototype.render = function () {
                                var e = this.selector;
                                if (((e.shouldComponentUpdate = !1), e.error)) throw e.error;
                                return Object(D.createElement)(t, this.addExtraProps(e.props));
                            }),
                            a
                        );
                    })(D.Component);
                return (i.WrappedComponent = t), (i.displayName = n), (i.childContextTypes = w), (i.contextTypes = x), (i.propTypes = x), U()(i, t);
            };
        }
        function h(e, t) {
            return e === t ? 0 !== e || 0 !== t || 1 / e == 1 / t : e !== e && t !== t;
        }
        function b(e, t) {
            if (h(e, t)) return !0;
            if ("object" != typeof e || null === e || "object" != typeof t || null === t) return !1;
            var r = Object.keys(e),
                n = Object.keys(t);
            if (r.length !== n.length) return !1;
            for (var o = 0; o < r.length; o++) if (!q.call(t, r[o]) || !h(e[r[o]], t[r[o]])) return !1;
            return !0;
        }
        function m(e) {
            return function (t, r) {
                function n() {
                    return o;
                }
                var o = e(t, r);
                return (n.dependsOnOwnProps = !1), n;
            };
        }
        function g(e) {
            return null !== e.dependsOnOwnProps && void 0 !== e.dependsOnOwnProps ? Boolean(e.dependsOnOwnProps) : 1 !== e.length;
        }
        function v(e, t) {
            return function (t, r) {
                r.displayName;
                var n = function (e, t) {
                    return n.dependsOnOwnProps ? n.mapToProps(e, t) : n.mapToProps(e);
                };
                return (
                    (n.dependsOnOwnProps = !0),
                    (n.mapToProps = function (t, r) {
                        (n.mapToProps = e), (n.dependsOnOwnProps = g(e));
                        var o = n(t, r);
                        return "function" == typeof o && ((n.mapToProps = o), (n.dependsOnOwnProps = g(o)), (o = n(t, r))), o;
                    }),
                    n
                );
            };
        }
        function y(e, t, r) {
            return $({}, r, e, t);
        }
        function E(e) {
            return function (t, r) {
                r.displayName;
                var n = r.pure,
                    o = r.areMergedPropsEqual,
                    a = !1,
                    i = void 0;
                return function (t, r, l) {
                    var u = e(t, r, l);
                    return a ? (n && o(u, i)) || (i = u) : ((a = !0), (i = u)), i;
                };
            };
        }
        function C(e, t) {
            var r = {};
            for (var n in e) t.indexOf(n) >= 0 || (Object.prototype.hasOwnProperty.call(e, n) && (r[n] = e[n]));
            return r;
        }
        function k(e, t, r, n) {
            return function (o, a) {
                return r(e(o, a), t(n, a), a);
            };
        }
        function P(e, t, r, n, o) {
            function a(o, a) {
                return (_ = o), (h = a), (b = e(_, h)), (m = t(n, h)), (g = r(b, m, h)), (d = !0), g;
            }
            function i() {
                return (b = e(_, h)), t.dependsOnOwnProps && (m = t(n, h)), (g = r(b, m, h));
            }
            function l() {
                return e.dependsOnOwnProps && (b = e(_, h)), t.dependsOnOwnProps && (m = t(n, h)), (g = r(b, m, h));
            }
            function u() {
                var t = e(_, h),
                    n = !f(t, b);
                return (b = t), n && (g = r(b, m, h)), g;
            }
            function s(e, t) {
                var r = !p(t, h),
                    n = !c(e, _);
                return (_ = e), (h = t), r && n ? i() : r ? l() : n ? u() : g;
            }
            var c = o.areStatesEqual,
                p = o.areOwnPropsEqual,
                f = o.areStatePropsEqual,
                d = !1,
                _ = void 0,
                h = void 0,
                b = void 0,
                m = void 0,
                g = void 0;
            return function (e, t) {
                return d ? s(e, t) : a(e, t);
            };
        }
        function x(e, t) {
            var r = t.initMapStateToProps,
                n = t.initMapDispatchToProps,
                o = t.initMergeProps,
                a = C(t, ["initMapStateToProps", "initMapDispatchToProps", "initMergeProps"]),
                i = r(e, a),
                l = n(e, a),
                u = o(e, a);
            return (a.pure ? P : k)(i, l, u, e, a);
        }
        function w(e, t) {
            var r = {};
            for (var n in e) t.indexOf(n) >= 0 || (Object.prototype.hasOwnProperty.call(e, n) && (r[n] = e[n]));
            return r;
        }
        function O(e, t, r) {
            for (var n = t.length - 1; n >= 0; n--) {
                var o = t[n](e);
                if (o) return o;
            }
            return function (t, n) {
                throw new Error("Invalid value of type " + typeof e + " for " + r + " argument when connecting component " + n.wrappedComponentName + ".");
            };
        }
        function M(e, t) {
            return e === t;
        }
        var D = r(0),
            T = r(6),
            S = r.n(T),
            R = S.a.shape({ trySubscribe: S.a.func.isRequired, tryUnsubscribe: S.a.func.isRequired, notifyNestedSubs: S.a.func.isRequired, isSubscribed: S.a.func.isRequired }),
            j = S.a.shape({ subscribe: S.a.func.isRequired, dispatch: S.a.func.isRequired, getState: S.a.func.isRequired }),
            B = (function () {
                var e,
                    t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "store",
                    r = arguments[1] || t + "Subscription",
                    i = (function (e) {
                        function i(r, a) {
                            n(this, i);
                            var l = o(this, e.call(this, r, a));
                            return (l[t] = r.store), l;
                        }
                        return (
                            a(i, e),
                            (i.prototype.getChildContext = function () {
                                var e;
                                return (e = {}), (e[t] = this[t]), (e[r] = null), e;
                            }),
                            (i.prototype.render = function () {
                                return D.Children.only(this.props.children);
                            }),
                            i
                        );
                    })(D.Component);
                return (i.propTypes = { store: j.isRequired, children: S.a.element.isRequired }), (i.childContextTypes = ((e = {}), (e[t] = j.isRequired), (e[r] = R), e)), i;
            })(),
            A = r(109),
            U = r.n(A),
            I = r(45),
            L = r.n(I),
            F = null,
            N = { notify: function () {} },
            W = (function () {
                function e(t, r, n) {
                    i(this, e), (this.store = t), (this.parentSub = r), (this.onStateChange = n), (this.unsubscribe = null), (this.listeners = N);
                }
                return (
                    (e.prototype.addNestedSub = function (e) {
                        return this.trySubscribe(), this.listeners.subscribe(e);
                    }),
                    (e.prototype.notifyNestedSubs = function () {
                        this.listeners.notify();
                    }),
                    (e.prototype.isSubscribed = function () {
                        return Boolean(this.unsubscribe);
                    }),
                    (e.prototype.trySubscribe = function () {
                        this.unsubscribe || ((this.unsubscribe = this.parentSub ? this.parentSub.addNestedSub(this.onStateChange) : this.store.subscribe(this.onStateChange)), (this.listeners = l()));
                    }),
                    (e.prototype.tryUnsubscribe = function () {
                        this.unsubscribe && (this.unsubscribe(), (this.unsubscribe = null), this.listeners.clear(), (this.listeners = N));
                    }),
                    e
                );
            })(),
            H =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            K = 0,
            z = {},
            q = Object.prototype.hasOwnProperty,
            G = r(15),
            V =
                (r(23),
                [
                    function (e) {
                        return "function" == typeof e ? v(e, "mapDispatchToProps") : void 0;
                    },
                    function (e) {
                        return e
                            ? void 0
                            : m(function (e) {
                                  return { dispatch: e };
                              });
                    },
                    function (e) {
                        return e && "object" == typeof e
                            ? m(function (t) {
                                  return Object(G.a)(e, t);
                              })
                            : void 0;
                    },
                ]),
            Y = [
                function (e) {
                    return "function" == typeof e ? v(e, "mapStateToProps") : void 0;
                },
                function (e) {
                    return e
                        ? void 0
                        : m(function () {
                              return {};
                          });
                },
            ],
            $ =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            X = [
                function (e) {
                    return "function" == typeof e ? E(e) : void 0;
                },
                function (e) {
                    return e
                        ? void 0
                        : function () {
                              return y;
                          };
                },
            ],
            Z =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            Q = (function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = e.connectHOC,
                    r = void 0 === t ? _ : t,
                    n = e.mapStateToPropsFactories,
                    o = void 0 === n ? Y : n,
                    a = e.mapDispatchToPropsFactories,
                    i = void 0 === a ? V : a,
                    l = e.mergePropsFactories,
                    u = void 0 === l ? X : l,
                    s = e.selectorFactory,
                    c = void 0 === s ? x : s;
                return function (e, t, n) {
                    var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                        l = a.pure,
                        s = void 0 === l || l,
                        p = a.areStatesEqual,
                        f = void 0 === p ? M : p,
                        d = a.areOwnPropsEqual,
                        _ = void 0 === d ? b : d,
                        h = a.areStatePropsEqual,
                        m = void 0 === h ? b : h,
                        g = a.areMergedPropsEqual,
                        v = void 0 === g ? b : g,
                        y = w(a, ["pure", "areStatesEqual", "areOwnPropsEqual", "areStatePropsEqual", "areMergedPropsEqual"]),
                        E = O(e, o, "mapStateToProps"),
                        C = O(t, i, "mapDispatchToProps"),
                        k = O(n, u, "mergeProps");
                    return r(
                        c,
                        Z(
                            {
                                methodName: "connect",
                                getDisplayName: function (e) {
                                    return "Connect(" + e + ")";
                                },
                                shouldHandleStateChanges: Boolean(e),
                                initMapStateToProps: E,
                                initMapDispatchToProps: C,
                                initMergeProps: k,
                                pure: s,
                                areStatesEqual: f,
                                areOwnPropsEqual: _,
                                areStatePropsEqual: m,
                                areMergedPropsEqual: v,
                            },
                            y
                        )
                    );
                };
            })();
        r.d(t, "a", function () {
            return B;
        }),
            r.d(t, "b", function () {
                return Q;
            });
    },
    function (e, t, r) {
        "use strict";
        e.exports = function (e, t, r, n, o, a, i, l) {
            if (!e) {
                var u;
                if (void 0 === t) u = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                else {
                    var s = [r, n, o, a, i, l],
                        c = 0;
                    (u = new Error(
                        t.replace(/%s/g, function () {
                            return s[c++];
                        })
                    )).name = "Invariant Violation";
                }
                throw ((u.framesToPop = 1), u);
            }
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return function () {
                return e;
            };
        }
        var o = function () {};
        (o.thatReturns = n),
            (o.thatReturnsFalse = n(!1)),
            (o.thatReturnsTrue = n(!0)),
            (o.thatReturnsNull = n(null)),
            (o.thatReturnsThis = function () {
                return this;
            }),
            (o.thatReturnsArgument = function (e) {
                return e;
            }),
            (e.exports = o);
    },
    function (e, t) {
        var r;
        r = (function () {
            return this;
        })();
        try {
            r = r || new Function("return this")();
        } catch (e) {
            "object" == typeof window && (r = window);
        }
        e.exports = r;
    },
    function (e, t, r) {
        var n = r(78),
            o = r(85);
        e.exports = function (e, t) {
            return e && n(e, o(t));
        };
    },
    function (e, t, r) {
        (function (e) {
            var n = r(9),
                o = r(165),
                a = t && !t.nodeType && t,
                i = a && "object" == typeof e && e && !e.nodeType && e,
                l = i && i.exports === a ? n.Buffer : void 0,
                u = (l ? l.isBuffer : void 0) || o;
            e.exports = u;
        }.call(this, r(22)(e)));
    },
    function (e, t) {
        var r = 9007199254740991;
        e.exports = function (e) {
            return "number" == typeof e && e > -1 && e % 1 == 0 && e <= r;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            return function (t) {
                return e(t);
            };
        };
    },
    function (e, t, r) {
        (function (e) {
            var n = r(77),
                o = t && !t.nodeType && t,
                a = o && "object" == typeof e && e && !e.nodeType && e,
                i = a && a.exports === o && n.process,
                l = (function () {
                    try {
                        return i && i.binding && i.binding("util");
                    } catch (e) {}
                })();
            e.exports = l;
        }.call(this, r(22)(e)));
    },
    function (e, t) {
        var r = Object.prototype;
        e.exports = function (e) {
            var t = e && e.constructor;
            return e === (("function" == typeof t && t.prototype) || r);
        };
    },
    function (e, t, r) {
        var n = r(83)(Object.getPrototypeOf, Object);
        e.exports = n;
    },
    function (e, t, r) {
        function n(e) {
            var t = (this.__data__ = new o(e));
            this.size = t.size;
        }
        var o = r(32),
            a = r(178),
            i = r(179),
            l = r(180),
            u = r(181),
            s = r(182);
        (n.prototype.clear = a), (n.prototype.delete = i), (n.prototype.get = l), (n.prototype.has = u), (n.prototype.set = s), (e.exports = n);
    },
    function (e, t) {
        e.exports = function (e, t) {
            return e === t || (e !== e && t !== t);
        };
    },
    function (e, t, r) {
        var n = r(18)(r(9), "Map");
        e.exports = n;
    },
    function (e, t, r) {
        function n(e) {
            var t = -1,
                r = null == e ? 0 : e.length;
            for (this.clear(); ++t < r; ) {
                var n = e[t];
                this.set(n[0], n[1]);
            }
        }
        var o = r(187),
            a = r(194),
            i = r(196),
            l = r(197),
            u = r(198);
        (n.prototype.clear = o), (n.prototype.delete = a), (n.prototype.get = i), (n.prototype.has = l), (n.prototype.set = u), (e.exports = n);
    },
    function (e, t, r) {
        function n(e, t, r, i, l) {
            return e === t || (null == e || null == t || (!a(e) && !a(t)) ? e !== e && t !== t : o(e, t, r, i, n, l));
        }
        var o = r(199),
            a = r(11);
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(209),
            o = r(94),
            a = Object.prototype.propertyIsEnumerable,
            i = Object.getOwnPropertySymbols,
            l = i
                ? function (e) {
                      return null == e
                          ? []
                          : ((e = Object(e)),
                            n(i(e), function (t) {
                                return a.call(e, t);
                            }));
                  }
                : o;
        e.exports = l;
    },
    function (e, t, r) {
        var n = r(8),
            o = r(37),
            a = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
            i = /^\w*$/;
        e.exports = function (e, t) {
            if (n(e)) return !1;
            var r = typeof e;
            return !("number" != r && "symbol" != r && "boolean" != r && null != e && !o(e)) || i.test(e) || !a.test(e) || (null != t && e in Object(t));
        };
    },
    function (e, t, r) {
        var n = r(90);
        e.exports = function (e) {
            var t = new e.constructor(e.byteLength);
            return new n(t).set(new n(e)), t;
        };
    },
    function (e, t, r) {
        e.exports = r(150);
    },
    function (e, t, r) {
        (function (e) {
            function t(e) {
                return (t =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var n = {
                canvas: !!window.CanvasRenderingContext2D,
                webgl: (function () {
                    try {
                        var e = document.createElement("canvas");
                        return !(!window.WebGLRenderingContext || (!e.getContext("webgl") && !e.getContext("experimental-webgl")));
                    } catch (e) {
                        return !1;
                    }
                })(),
                workers: !!window.Worker,
                fileapi: window.File && window.FileReader && window.FileList && window.Blob,
                getWebGLErrorMessage: function () {
                    var e = document.createElement("div");
                    return (
                        (e.id = "webgl-error-message"),
                        (e.style.fontFamily = "monospace"),
                        (e.style.fontSize = "13px"),
                        (e.style.fontWeight = "normal"),
                        (e.style.textAlign = "center"),
                        (e.style.background = "#fff"),
                        (e.style.color = "#000"),
                        (e.style.padding = "1.5em"),
                        (e.style.width = "400px"),
                        (e.style.margin = "5em auto 0"),
                        this.webgl ||
                            (e.innerHTML = window.WebGLRenderingContext
                                ? [
                                      '<h1>Oh no!</h1><br />Your graphics card does not seem to support <a href="http://khronos.org/webgl/wiki/Getting_a_WebGL_Implementation" style="color:#000">WebGL</a>.<br />',
                                      'Find out how to get it <a href="http://get.webgl.org" style="color:#000">here</a>.',
                                  ].join("\n")
                                : [
                                      '<h1>Your browser is not supported</h1>Your browser does not seem to support <a href="http://khronos.org/webgl/wiki/Getting_a_WebGL_Implementation" style="color:#000">WebGL</a>.<br/>',
                                      'Most modern browser support it. Update your browser <a href="http://browserhappy.org" style="color:#000">here</a> to use GR8BRIK.',
                                  ].join("\n")),
                        e
                    );
                },
                addGetWebGLMessage: function (e) {
                    var t, r, o;
                    (t = void 0 !== (e = e || {}).parent ? e.parent : document.body), (r = void 0 !== e.id ? e.id : "oldie"), ((o = n.getWebGLErrorMessage()).id = r), t.appendChild(o);
                },
            };
            "object" === t(e) && (e.exports = n),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "Detector", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/detector.js"), o(e));
                })(),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "Detector", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/detector.js"), o(e));
                })();
        }.call(this, r(22)(e)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            var n = r(0),
                o = r.n(n),
                a = r(312),
                i = r.n(a);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var l = function (e) {
                    e.text;
                    var t = e.children;
                    return o.a.createElement("div", { className: i.a.message }, t);
                },
                u = l,
                s = u;
            (t.a = s),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(l, "Message", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Message.jsx"),
                        t.register(u, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Message.jsx"),
                        n(e));
                })(),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(l, "Message", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Message.jsx"),
                        t.register(s, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Message.jsx"),
                        n(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            if (null === e || void 0 === e) throw new TypeError("Object.assign cannot be called with null or undefined");
            return Object(e);
        } /*
object-assign
(c) Evan Rutledge
@license MIT
*/
        var o = Object.getOwnPropertySymbols,
            a = Object.prototype.hasOwnProperty,
            i = Object.prototype.propertyIsEnumerable;
        e.exports = (function () {
            try {
                if (!Object.assign) return !1;
                var e = new String("abc");
                if (((e[5] = "de"), "5" === Object.getOwnPropertyNames(e)[0])) return !1;
                for (var t = {}, r = 0; r < 10; r++) t["_" + String.fromCharCode(r)] = r;
                if (
                    "0123456789" !==
                    Object.getOwnPropertyNames(t)
                        .map(function (e) {
                            return t[e];
                        })
                        .join("")
                )
                    return !1;
                var n = {};
                return (
                    "abcdefghijklmnopqrst".split("").forEach(function (e) {
                        n[e] = e;
                    }),
                    "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, n)).join("")
                );
            } catch (e) {
                return !1;
            }
        })()
            ? Object.assign
            : function (e, t) {
                  for (var r, l, u = n(e), s = 1; s < arguments.length; s++) {
                      r = Object(arguments[s]);
                      for (var c in r) a.call(r, c) && (u[c] = r[c]);
                      if (o) {
                          l = o(r);
                          for (var p = 0; p < l.length; p++) i.call(r, l[p]) && (u[l[p]] = r[l[p]]);
                      }
                  }
                  return u;
              };
    },
    function (e, t, r) {
        "use strict";
        var n = function (e) {};
        e.exports = function (e, t, r, o, a, i, l, u) {
            if ((n(t), !e)) {
                var s;
                if (void 0 === t) s = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                else {
                    var c = [r, o, a, i, l, u],
                        p = 0;
                    (s = new Error(
                        t.replace(/%s/g, function () {
                            return c[p++];
                        })
                    )).name = "Invariant Violation";
                }
                throw ((s.framesToPop = 1), s);
            }
        };
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                return e.builder.mode;
            }
            function o(e) {
                return e.builder.color;
            }
            function a(e) {
                return e.builder.grid;
            }
            function i(e) {
                return e.builder.brick;
            }
            r.d(t, "d", function () {
                return n;
            }),
                r.d(t, "b", function () {
                    return o;
                }),
                r.d(t, "c", function () {
                    return a;
                }),
                r.d(t, "a", function () {
                    return i;
                }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).default,
                        l = r(1).leaveModule;
                    t &&
                        (t.register(n, "getMode", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        t.register(o, "getColor", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        t.register(a, "getIsGridVisible", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        t.register(i, "getBrickDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        l(e));
                })(),
                (function () {
                    var t = r(1).default,
                        l = r(1).leaveModule;
                    t &&
                        (t.register(n, "getMode", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        t.register(o, "getColor", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        t.register(a, "getIsGridVisible", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        t.register(i, "getBrickDimensions", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/builder.js"),
                        l(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                return e.ui.utilsOpen;
            }
            r.d(t, "a", function () {
                return n;
            }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "getAreUtilsOpen", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/ui.js"), o(e));
                })(),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "getAreUtilsOpen", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/ui.js"), o(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                return e.scene.bricks;
            }
            r.d(t, "a", function () {
                return n;
            }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "getBricks", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/scene.js"), o(e));
                })(),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "getBricks", "/Users/nick/Documents/Programming/repos/brick-builder/app/selectors/scene.js"), o(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t) {
        var r =
            ("undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto)) ||
            ("undefined" != typeof msCrypto && "function" == typeof window.msCrypto.getRandomValues && msCrypto.getRandomValues.bind(msCrypto));
        if (r) {
            var n = new Uint8Array(16);
            e.exports = function () {
                return r(n), n;
            };
        } else {
            var o = new Array(16);
            e.exports = function () {
                for (var e, t = 0; t < 16; t++) 0 == (3 & t) && (e = 4294967296 * Math.random()), (o[t] = (e >>> ((3 & t) << 3)) & 255);
                return o;
            };
        }
    },
    function (e, t) {
        for (var r = [], n = 0; n < 256; ++n) r[n] = (n + 256).toString(16).substr(1);
        e.exports = function (e, t) {
            var n = t || 0,
                o = r;
            return [o[e[n++]], o[e[n++]], o[e[n++]], o[e[n++]], "-", o[e[n++]], o[e[n++]], "-", o[e[n++]], o[e[n++]], "-", o[e[n++]], o[e[n++]], "-", o[e[n++]], o[e[n++]], o[e[n++]], o[e[n++]], o[e[n++]], o[e[n++]]].join("");
        };
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            __webpack_require__.d(__webpack_exports__, "a", function () {
                return Renderer;
            }),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var Renderer = (function (_THREE$WebGLRenderer) {
                function Renderer() {
                    return _classCallCheck(this, Renderer), _possibleConstructorReturn(this, (Renderer.__proto__ || Object.getPrototypeOf(Renderer)).apply(this, arguments));
                }
                return (
                    _inherits(Renderer, _THREE$WebGLRenderer),
                    _createClass(Renderer, [
                        {
                            key: "init",
                            value: function (e, t) {
                                this.setClearColor(16777215),
                                    this.setPixelRatio(1),
                                    this.setSize(e, t),
                                    (this.gammaInput = !0),
                                    (this.gammaOutput = !0),
                                    (this.shadowMap.enabled = !0),
                                    (this.shadowMapSoft = !0),
                                    (this.shadowMap.type = THREE.PCFShadowMap);
                            },
                        },
                        {
                            key: "__reactstandin__regenerateByEval",
                            value: function __reactstandin__regenerateByEval(key, code) {
                                this[key] = eval(code);
                            },
                        },
                    ]),
                    Renderer
                );
            })(THREE.WebGLRenderer);
            !(function () {
                var e = __webpack_require__(1).default,
                    t = __webpack_require__(1).leaveModule;
                e && (e.register(Renderer, "Renderer", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Renderer.js"), t(module));
            })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e && (e.register(Renderer, "Renderer", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Renderer.js"), t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            __webpack_require__.d(__webpack_exports__, "a", function () {
                return Controls;
            }),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var OrbitControls = __webpack_require__(155)(THREE),
                Controls = (function (_OrbitControls) {
                    function Controls() {
                        return _classCallCheck(this, Controls), _possibleConstructorReturn(this, (Controls.__proto__ || Object.getPrototypeOf(Controls)).apply(this, arguments));
                    }
                    return (
                        _inherits(Controls, _OrbitControls),
                        _createClass(Controls, [
                            {
                                key: "init",
                                value: function () {
                                    (this.enableDamping = !0), (this.dampingFactor = 0.15), (this.rotateSpeed = 0.3), (this.maxPolarAngle = Math.PI / 2), (this.minDistance = 200), (this.maxDistance = 6500);
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        Controls
                    );
                })(OrbitControls);
            !(function () {
                var e = __webpack_require__(1).default,
                    t = __webpack_require__(1).leaveModule;
                e &&
                    (e.register(OrbitControls, "OrbitControls", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Controls.js"),
                    e.register(Controls, "Controls", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Controls.js"),
                    t(module));
            })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Controls, "Controls", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Controls.js"),
                        e.register(OrbitControls, "OrbitControls", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Controls.js"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            __webpack_require__.d(__webpack_exports__, "b", function () {
                return Light;
            }),
                __webpack_require__.d(__webpack_exports__, "a", function () {
                    return AmbientLight;
                });
            var _Camera__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(41);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var Light = (function (_THREE$SpotLight) {
                    function Light() {
                        return _classCallCheck(this, Light), _possibleConstructorReturn(this, (Light.__proto__ || Object.getPrototypeOf(Light)).call(this, 16777215));
                    }
                    return (
                        _inherits(Light, _THREE$SpotLight),
                        _createClass(Light, [
                            {
                                key: "init",
                                value: function () {
                                    this.position.set(-1e3, 1500, -500),
                                        (this.intensity = 0.9),
                                        (this.castShadow = !0),
                                        (this.shadow = new THREE.LightShadow(new _Camera__WEBPACK_IMPORTED_MODULE_0__.a(window.innerWidth / -2, window.innerWidth / 2, window.innerHeight / 2, window.innerHeight / -2, 1, 1e4))),
                                        (this.shadow.bias = -22e-7),
                                        (this.shadow.mapSize.width = 4096),
                                        (this.shadow.mapSize.height = 4096),
                                        (this.penumbra = 0.5),
                                        (this.decay = 2);
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        Light
                    );
                })(THREE.SpotLight),
                AmbientLight = (function (e) {
                    function t() {
                        return _classCallCheck(this, t), _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
                    }
                    return _inherits(t, THREE.AmbientLight), t;
                })();
            !(function () {
                var e = __webpack_require__(1).default,
                    t = __webpack_require__(1).leaveModule;
                e &&
                    (e.register(Light, "Light", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Light.js"),
                    e.register(AmbientLight, "AmbientLight", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Light.js"),
                    t(module));
            })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Light, "Light", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Light.js"),
                        e.register(AmbientLight, "AmbientLight", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Light.js"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            __webpack_require__.d(__webpack_exports__, "a", function () {
                return Plane;
            }),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var Plane = (function (_THREE$Mesh) {
                function Plane(e) {
                    var t;
                    _classCallCheck(this, Plane);
                    var r = new THREE.PlaneBufferGeometry(e, e);
                    r.rotateX(-Math.PI / 2);
                    var n = new THREE.ShadowMaterial();
                    return (n.opacity = 0.2), (t = _possibleConstructorReturn(this, (Plane.__proto__ || Object.getPrototypeOf(Plane)).call(this, r, n))), (t.receiveShadow = !0), t;
                }
                return (
                    _inherits(Plane, _THREE$Mesh),
                    _createClass(Plane, [
                        {
                            key: "__reactstandin__regenerateByEval",
                            value: function __reactstandin__regenerateByEval(key, code) {
                                this[key] = eval(code);
                            },
                        },
                    ]),
                    Plane
                );
            })(THREE.Mesh);
            !(function () {
                var e = __webpack_require__(1).default,
                    t = __webpack_require__(1).leaveModule;
                e && (e.register(Plane, "Plane", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Plane.js"), t(module));
            })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e && (e.register(Plane, "Plane", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/core/Plane.js"), t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        (function (t) {
            var r = "object" == typeof t && t && t.Object === Object && t;
            e.exports = r;
        }.call(this, r(47)));
    },
    function (e, t, r) {
        var n = r(161),
            o = r(25);
        e.exports = function (e, t) {
            return e && n(e, t, o);
        };
    },
    function (e, t, r) {
        var n = r(163),
            o = r(80),
            a = r(8),
            i = r(49),
            l = r(81),
            u = r(82),
            s = Object.prototype.hasOwnProperty;
        e.exports = function (e, t) {
            var r = a(e),
                c = !r && o(e),
                p = !r && !c && i(e),
                f = !r && !c && !p && u(e),
                d = r || c || p || f,
                _ = d ? n(e.length, String) : [],
                h = _.length;
            for (var b in e) (!t && !s.call(e, b)) || (d && ("length" == b || (p && ("offset" == b || "parent" == b)) || (f && ("buffer" == b || "byteLength" == b || "byteOffset" == b)) || l(b, h))) || _.push(b);
            return _;
        };
    },
    function (e, t, r) {
        var n = r(164),
            o = r(11),
            a = Object.prototype,
            i = a.hasOwnProperty,
            l = a.propertyIsEnumerable,
            u = n(
                (function () {
                    return arguments;
                })()
            )
                ? n
                : function (e) {
                      return o(e) && i.call(e, "callee") && !l.call(e, "callee");
                  };
        e.exports = u;
    },
    function (e, t) {
        var r = 9007199254740991,
            n = /^(?:0|[1-9]\d*)$/;
        e.exports = function (e, t) {
            var o = typeof e;
            return !!(t = null == t ? r : t) && ("number" == o || ("symbol" != o && n.test(e))) && e > -1 && e % 1 == 0 && e < t;
        };
    },
    function (e, t, r) {
        var n = r(166),
            o = r(51),
            a = r(52),
            i = a && a.isTypedArray,
            l = i ? o(i) : n;
        e.exports = l;
    },
    function (e, t) {
        e.exports = function (e, t) {
            return function (r) {
                return e(t(r));
            };
        };
    },
    function (e, t, r) {
        var n = r(17),
            o = r(12),
            a = "[object AsyncFunction]",
            i = "[object Function]",
            l = "[object GeneratorFunction]",
            u = "[object Proxy]";
        e.exports = function (e) {
            if (!o(e)) return !1;
            var t = n(e);
            return t == i || t == l || t == a || t == u;
        };
    },
    function (e, t, r) {
        var n = r(86);
        e.exports = function (e) {
            return "function" == typeof e ? e : n;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            return e;
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            for (var r = -1, n = null == e ? 0 : e.length, o = Array(n); ++r < n; ) o[r] = t(e[r], r, e);
            return o;
        };
    },
    function (e, t) {
        var r = Function.prototype.toString;
        e.exports = function (e) {
            if (null != e) {
                try {
                    return r.call(e);
                } catch (e) {}
                try {
                    return e + "";
                } catch (e) {}
            }
            return "";
        };
    },
    function (e, t, r) {
        var n = r(200),
            o = r(203),
            a = r(204),
            i = 1,
            l = 2;
        e.exports = function (e, t, r, u, s, c) {
            var p = r & i,
                f = e.length,
                d = t.length;
            if (f != d && !(p && d > f)) return !1;
            var _ = c.get(e);
            if (_ && c.get(t)) return _ == t;
            var h = -1,
                b = !0,
                m = r & l ? new n() : void 0;
            for (c.set(e, t), c.set(t, e); ++h < f; ) {
                var g = e[h],
                    v = t[h];
                if (u) var y = p ? u(v, g, h, t, e, c) : u(g, v, h, e, t, c);
                if (void 0 !== y) {
                    if (y) continue;
                    b = !1;
                    break;
                }
                if (m) {
                    if (
                        !o(t, function (e, t) {
                            if (!a(m, t) && (g === e || s(g, e, r, u, c))) return m.push(t);
                        })
                    ) {
                        b = !1;
                        break;
                    }
                } else if (g !== v && !s(g, v, r, u, c)) {
                    b = !1;
                    break;
                }
            }
            return c.delete(e), c.delete(t), b;
        };
    },
    function (e, t, r) {
        var n = r(9).Uint8Array;
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(92),
            o = r(60),
            a = r(25);
        e.exports = function (e) {
            return n(e, a, o);
        };
    },
    function (e, t, r) {
        var n = r(93),
            o = r(8);
        e.exports = function (e, t, r) {
            var a = t(e);
            return o(e) ? a : n(a, r(e));
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            for (var r = -1, n = t.length, o = e.length; ++r < n; ) e[o + r] = t[r];
            return e;
        };
    },
    function (e, t) {
        e.exports = function () {
            return [];
        };
    },
    function (e, t, r) {
        var n = r(12);
        e.exports = function (e) {
            return e === e && !n(e);
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            return function (r) {
                return null != r && r[e] === t && (void 0 !== t || e in Object(r));
            };
        };
    },
    function (e, t, r) {
        var n = r(98),
            o = r(38);
        e.exports = function (e, t) {
            for (var r = 0, a = (t = n(t, e)).length; null != e && r < a; ) e = e[o(t[r++])];
            return r && r == a ? e : void 0;
        };
    },
    function (e, t, r) {
        var n = r(8),
            o = r(61),
            a = r(217),
            i = r(220);
        e.exports = function (e, t) {
            return n(e) ? e : o(e, t) ? [e] : a(i(e));
        };
    },
    function (e, t, r) {
        var n = r(78),
            o = r(229)(n);
        e.exports = o;
    },
    function (e, t) {
        e.exports = function (e, t) {
            for (var r = -1, n = null == e ? 0 : e.length; ++r < n && !1 !== t(e[r], r, e); );
            return e;
        };
    },
    function (e, t, r) {
        var n = r(102),
            o = r(56),
            a = Object.prototype.hasOwnProperty;
        e.exports = function (e, t, r) {
            var i = e[t];
            (a.call(e, t) && o(i, r) && (void 0 !== r || t in e)) || n(e, t, r);
        };
    },
    function (e, t, r) {
        var n = r(233);
        e.exports = function (e, t, r) {
            "__proto__" == t && n ? n(e, t, { configurable: !0, enumerable: !0, value: r, writable: !0 }) : (e[t] = r);
        };
    },
    function (e, t, r) {
        var n = r(79),
            o = r(236),
            a = r(31);
        e.exports = function (e) {
            return a(e) ? n(e, !0) : o(e);
        };
    },
    function (e, t, r) {
        var n = r(93),
            o = r(54),
            a = r(60),
            i = r(94),
            l = Object.getOwnPropertySymbols
                ? function (e) {
                      for (var t = []; e; ) n(t, a(e)), (e = o(e));
                      return t;
                  }
                : i;
        e.exports = l;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Checkboard = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (function (e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return (t.default = e), t;
            })(r(261)),
            l = (t.Checkboard = function (e) {
                var t = e.white,
                    r = e.grey,
                    n = e.size,
                    l = e.renderers,
                    u = e.borderRadius,
                    s = e.boxShadow,
                    c = (0, a.default)({ default: { grid: { borderRadius: u, boxShadow: s, absolute: "0px 0px 0px 0px", background: "url(" + i.get(t, r, n, l.canvas) + ") center left" } } });
                return o.default.createElement("div", { style: c.grid });
            });
        (l.defaultProps = { size: 8, white: "transparent", grey: "rgba(0,0,0,.08)", renderers: {} }), (t.default = l);
    },
    function (e, t, r) {
        var n = r(12),
            o = r(268),
            a = r(269),
            i = "Expected a function",
            l = Math.max,
            u = Math.min;
        e.exports = function (e, t, r) {
            function s(t) {
                var r = b,
                    n = m;
                return (b = m = void 0), (C = t), (v = e.apply(n, r));
            }
            function c(e) {
                return (C = e), (y = setTimeout(d, t)), k ? s(e) : v;
            }
            function p(e) {
                var r = e - C,
                    n = t - (e - E);
                return P ? u(n, g - r) : n;
            }
            function f(e) {
                var r = e - E,
                    n = e - C;
                return void 0 === E || r >= t || r < 0 || (P && n >= g);
            }
            function d() {
                var e = o();
                if (f(e)) return _(e);
                y = setTimeout(d, p(e));
            }
            function _(e) {
                return (y = void 0), x && b ? s(e) : ((b = m = void 0), v);
            }
            function h() {
                var e = o(),
                    r = f(e);
                if (((b = arguments), (m = this), (E = e), r)) {
                    if (void 0 === y) return c(E);
                    if (P) return (y = setTimeout(d, t)), s(E);
                }
                return void 0 === y && (y = setTimeout(d, t)), v;
            }
            var b,
                m,
                g,
                v,
                y,
                E,
                C = 0,
                k = !1,
                P = !1,
                x = !0;
            if ("function" != typeof e) throw new TypeError(i);
            return (
                (t = a(t) || 0),
                n(r) && ((k = !!r.leading), (g = (P = "maxWait" in r) ? l(a(r.maxWait) || 0, t) : g), (x = "trailing" in r ? !!r.trailing : x)),
                (h.cancel = function () {
                    void 0 !== y && clearTimeout(y), (C = 0), (b = E = m = y = void 0);
                }),
                (h.flush = function () {
                    return void 0 === y ? v : _(o());
                }),
                h
            );
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function a(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function i(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.ColorWrap = void 0);
        var l =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            u = (function () {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                    }
                }
                return function (t, r, n) {
                    return r && e(t.prototype, r), n && e(t, n), t;
                };
            })(),
            s = r(0),
            c = n(s),
            p = n(r(106)),
            f = n(r(13)),
            d = (t.ColorWrap = function (e) {
                var t = (function (t) {
                    function r(e) {
                        o(this, r);
                        var t = a(this, (r.__proto__ || Object.getPrototypeOf(r)).call(this));
                        return (
                            (t.handleChange = function (e, r) {
                                if (f.default.simpleCheckForValidColor(e)) {
                                    var n = f.default.toState(e, e.h || t.state.oldHue);
                                    t.setState(n), t.props.onChangeComplete && t.debounce(t.props.onChangeComplete, n, r), t.props.onChange && t.props.onChange(n, r);
                                }
                            }),
                            (t.handleSwatchHover = function (e, r) {
                                if (f.default.simpleCheckForValidColor(e)) {
                                    var n = f.default.toState(e, e.h || t.state.oldHue);
                                    t.setState(n), t.props.onSwatchHover && t.props.onSwatchHover(n, r);
                                }
                            }),
                            (t.state = l({}, f.default.toState(e.color, 0))),
                            (t.debounce = (0, p.default)(function (e, t, r) {
                                e(t, r);
                            }, 100)),
                            t
                        );
                    }
                    return (
                        i(r, s.PureComponent || s.Component),
                        u(r, [
                            {
                                key: "componentWillReceiveProps",
                                value: function (e) {
                                    this.setState(l({}, f.default.toState(e.color, this.state.oldHue)));
                                },
                            },
                            {
                                key: "render",
                                value: function () {
                                    var t = {};
                                    return this.props.onSwatchHover && (t.onSwatchHover = this.handleSwatchHover), c.default.createElement(e, l({}, this.props, this.state, { onChange: this.handleChange }, t));
                                },
                            },
                        ]),
                        r
                    );
                })();
                return (t.propTypes = l({}, e.propTypes)), (t.defaultProps = l({}, e.defaultProps, { color: { h: 250, s: 0.5, l: 0.2, a: 1 } })), t;
            });
        t.default = d;
    },
    function (e, t, r) {
        "use strict";
        r.r(t),
            r.d(t, "red", function () {
                return n;
            }),
            r.d(t, "pink", function () {
                return o;
            }),
            r.d(t, "purple", function () {
                return a;
            }),
            r.d(t, "deepPurple", function () {
                return i;
            }),
            r.d(t, "indigo", function () {
                return l;
            }),
            r.d(t, "blue", function () {
                return u;
            }),
            r.d(t, "lightBlue", function () {
                return s;
            }),
            r.d(t, "cyan", function () {
                return c;
            }),
            r.d(t, "teal", function () {
                return p;
            }),
            r.d(t, "green", function () {
                return f;
            }),
            r.d(t, "lightGreen", function () {
                return d;
            }),
            r.d(t, "lime", function () {
                return _;
            }),
            r.d(t, "yellow", function () {
                return h;
            }),
            r.d(t, "amber", function () {
                return b;
            }),
            r.d(t, "orange", function () {
                return m;
            }),
            r.d(t, "deepOrange", function () {
                return g;
            }),
            r.d(t, "brown", function () {
                return v;
            }),
            r.d(t, "grey", function () {
                return y;
            }),
            r.d(t, "blueGrey", function () {
                return E;
            }),
            r.d(t, "darkText", function () {
                return C;
            }),
            r.d(t, "lightText", function () {
                return k;
            }),
            r.d(t, "darkIcons", function () {
                return P;
            }),
            r.d(t, "lightIcons", function () {
                return x;
            }),
            r.d(t, "white", function () {
                return w;
            }),
            r.d(t, "black", function () {
                return O;
            });
        var n = {
                50: "#ffebee",
                100: "#ffcdd2",
                200: "#ef9a9a",
                300: "#e57373",
                400: "#ef5350",
                500: "#f44336",
                600: "#e53935",
                700: "#d32f2f",
                800: "#c62828",
                900: "#b71c1c",
                a100: "#ff8a80",
                a200: "#ff5252",
                a400: "#ff1744",
                a700: "#d50000",
            },
            o = {
                50: "#fce4ec",
                100: "#f8bbd0",
                200: "#f48fb1",
                300: "#f06292",
                400: "#ec407a",
                500: "#e91e63",
                600: "#d81b60",
                700: "#c2185b",
                800: "#ad1457",
                900: "#880e4f",
                a100: "#ff80ab",
                a200: "#ff4081",
                a400: "#f50057",
                a700: "#c51162",
            },
            a = {
                50: "#f3e5f5",
                100: "#e1bee7",
                200: "#ce93d8",
                300: "#ba68c8",
                400: "#ab47bc",
                500: "#9c27b0",
                600: "#8e24aa",
                700: "#7b1fa2",
                800: "#6a1b9a",
                900: "#4a148c",
                a100: "#ea80fc",
                a200: "#e040fb",
                a400: "#d500f9",
                a700: "#aa00ff",
            },
            i = {
                50: "#ede7f6",
                100: "#d1c4e9",
                200: "#b39ddb",
                300: "#9575cd",
                400: "#7e57c2",
                500: "#673ab7",
                600: "#5e35b1",
                700: "#512da8",
                800: "#4527a0",
                900: "#311b92",
                a100: "#b388ff",
                a200: "#7c4dff",
                a400: "#651fff",
                a700: "#6200ea",
            },
            l = {
                50: "#e8eaf6",
                100: "#c5cae9",
                200: "#9fa8da",
                300: "#7986cb",
                400: "#5c6bc0",
                500: "#3f51b5",
                600: "#3949ab",
                700: "#303f9f",
                800: "#283593",
                900: "#1a237e",
                a100: "#8c9eff",
                a200: "#536dfe",
                a400: "#3d5afe",
                a700: "#304ffe",
            },
            u = {
                50: "#e3f2fd",
                100: "#bbdefb",
                200: "#90caf9",
                300: "#64b5f6",
                400: "#42a5f5",
                500: "#2196f3",
                600: "#1e88e5",
                700: "#1976d2",
                800: "#1565c0",
                900: "#0d47a1",
                a100: "#82b1ff",
                a200: "#448aff",
                a400: "#2979ff",
                a700: "#2962ff",
            },
            s = {
                50: "#e1f5fe",
                100: "#b3e5fc",
                200: "#81d4fa",
                300: "#4fc3f7",
                400: "#29b6f6",
                500: "#03a9f4",
                600: "#039be5",
                700: "#0288d1",
                800: "#0277bd",
                900: "#01579b",
                a100: "#80d8ff",
                a200: "#40c4ff",
                a400: "#00b0ff",
                a700: "#0091ea",
            },
            c = {
                50: "#e0f7fa",
                100: "#b2ebf2",
                200: "#80deea",
                300: "#4dd0e1",
                400: "#26c6da",
                500: "#00bcd4",
                600: "#00acc1",
                700: "#0097a7",
                800: "#00838f",
                900: "#006064",
                a100: "#84ffff",
                a200: "#18ffff",
                a400: "#00e5ff",
                a700: "#00b8d4",
            },
            p = {
                50: "#e0f2f1",
                100: "#b2dfdb",
                200: "#80cbc4",
                300: "#4db6ac",
                400: "#26a69a",
                500: "#009688",
                600: "#00897b",
                700: "#00796b",
                800: "#00695c",
                900: "#004d40",
                a100: "#a7ffeb",
                a200: "#64ffda",
                a400: "#1de9b6",
                a700: "#00bfa5",
            },
            f = {
                50: "#e8f5e9",
                100: "#c8e6c9",
                200: "#a5d6a7",
                300: "#81c784",
                400: "#66bb6a",
                500: "#4caf50",
                600: "#43a047",
                700: "#388e3c",
                800: "#2e7d32",
                900: "#1b5e20",
                a100: "#b9f6ca",
                a200: "#69f0ae",
                a400: "#00e676",
                a700: "#00c853",
            },
            d = {
                50: "#f1f8e9",
                100: "#dcedc8",
                200: "#c5e1a5",
                300: "#aed581",
                400: "#9ccc65",
                500: "#8bc34a",
                600: "#7cb342",
                700: "#689f38",
                800: "#558b2f",
                900: "#33691e",
                a100: "#ccff90",
                a200: "#b2ff59",
                a400: "#76ff03",
                a700: "#64dd17",
            },
            _ = {
                50: "#f9fbe7",
                100: "#f0f4c3",
                200: "#e6ee9c",
                300: "#dce775",
                400: "#d4e157",
                500: "#cddc39",
                600: "#c0ca33",
                700: "#afb42b",
                800: "#9e9d24",
                900: "#827717",
                a100: "#f4ff81",
                a200: "#eeff41",
                a400: "#c6ff00",
                a700: "#aeea00",
            },
            h = {
                50: "#fffde7",
                100: "#fff9c4",
                200: "#fff59d",
                300: "#fff176",
                400: "#ffee58",
                500: "#ffeb3b",
                600: "#fdd835",
                700: "#fbc02d",
                800: "#f9a825",
                900: "#f57f17",
                a100: "#ffff8d",
                a200: "#ffff00",
                a400: "#ffea00",
                a700: "#ffd600",
            },
            b = {
                50: "#fff8e1",
                100: "#ffecb3",
                200: "#ffe082",
                300: "#ffd54f",
                400: "#ffca28",
                500: "#ffc107",
                600: "#ffb300",
                700: "#ffa000",
                800: "#ff8f00",
                900: "#ff6f00",
                a100: "#ffe57f",
                a200: "#ffd740",
                a400: "#ffc400",
                a700: "#ffab00",
            },
            m = {
                50: "#fff3e0",
                100: "#ffe0b2",
                200: "#ffcc80",
                300: "#ffb74d",
                400: "#ffa726",
                500: "#ff9800",
                600: "#fb8c00",
                700: "#f57c00",
                800: "#ef6c00",
                900: "#e65100",
                a100: "#ffd180",
                a200: "#ffab40",
                a400: "#ff9100",
                a700: "#ff6d00",
            },
            g = {
                50: "#fbe9e7",
                100: "#ffccbc",
                200: "#ffab91",
                300: "#ff8a65",
                400: "#ff7043",
                500: "#ff5722",
                600: "#f4511e",
                700: "#e64a19",
                800: "#d84315",
                900: "#bf360c",
                a100: "#ff9e80",
                a200: "#ff6e40",
                a400: "#ff3d00",
                a700: "#dd2c00",
            },
            v = { 50: "#efebe9", 100: "#d7ccc8", 200: "#bcaaa4", 300: "#a1887f", 400: "#8d6e63", 500: "#795548", 600: "#6d4c41", 700: "#5d4037", 800: "#4e342e", 900: "#3e2723" },
            y = { 50: "#fafafa", 100: "#f5f5f5", 200: "#eeeeee", 300: "#e0e0e0", 400: "#bdbdbd", 500: "#9e9e9e", 600: "#757575", 700: "#616161", 800: "#424242", 900: "#212121" },
            E = { 50: "#eceff1", 100: "#cfd8dc", 200: "#b0bec5", 300: "#90a4ae", 400: "#78909c", 500: "#607d8b", 600: "#546e7a", 700: "#455a64", 800: "#37474f", 900: "#263238" },
            C = { primary: "rgba(0, 0, 0, 0.87)", secondary: "rgba(0, 0, 0, 0.54)", disabled: "rgba(0, 0, 0, 0.38)", dividers: "rgba(0, 0, 0, 0.12)" },
            k = { primary: "rgba(255, 255, 255, 1)", secondary: "rgba(255, 255, 255, 0.7)", disabled: "rgba(255, 255, 255, 0.5)", dividers: "rgba(255, 255, 255, 0.12)" },
            P = { active: "rgba(0, 0, 0, 0.54)", inactive: "rgba(0, 0, 0, 0.38)" },
            x = { active: "rgba(255, 255, 255, 1)", inactive: "rgba(255, 255, 255, 0.5)" },
            w = "#ffffff",
            O = "#000000";
        t.default = {
            red: n,
            pink: o,
            purple: a,
            deepPurple: i,
            indigo: l,
            blue: u,
            lightBlue: s,
            cyan: c,
            teal: p,
            green: f,
            lightGreen: d,
            lime: _,
            yellow: h,
            amber: b,
            orange: m,
            deepOrange: g,
            brown: v,
            grey: y,
            blueGrey: E,
            darkText: C,
            lightText: k,
            darkIcons: P,
            lightIcons: x,
            white: w,
            black: O,
        };
    },
    function (e, t, r) {
        "use strict";
        var n = { childContextTypes: !0, contextTypes: !0, defaultProps: !0, displayName: !0, getDefaultProps: !0, mixins: !0, propTypes: !0, type: !0 },
            o = { name: !0, length: !0, prototype: !0, caller: !0, callee: !0, arguments: !0, arity: !0 },
            a = Object.getOwnPropertySymbols,
            i = (Object.prototype.hasOwnProperty, Object.prototype.propertyIsEnumerable),
            l = Object.getPrototypeOf,
            u = l && l(Object),
            s = Object.getOwnPropertyNames;
        e.exports = function e(t, r, c) {
            if ("string" != typeof r) {
                if (u) {
                    var p = l(r);
                    p && p !== u && e(t, p, c);
                }
                var f = s(r);
                a && (f = f.concat(a(r)));
                for (var d = 0; d < f.length; ++d) {
                    var _ = f[d];
                    if (!(n[_] || o[_] || (c && c[_])) && (i.call(r, _) || "function" == typeof r[_]))
                        try {
                            t[_] = r[_];
                        } catch (e) {}
                }
                return t;
            }
            return t;
        };
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            var r = "object" == typeof e && e && e.Object === Object && e;
            t.a = r;
        }.call(this, r(47)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44),
                redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15),
                selectors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(20),
                actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(10),
                components_engine_Scene__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(112),
                components_Topbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(117),
                components_Help__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(122),
                components_Sidebar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(123),
                styles_containers_builder__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(333),
                styles_containers_builder__WEBPACK_IMPORTED_MODULE_9___default = __webpack_require__.n(styles_containers_builder__WEBPACK_IMPORTED_MODULE_9__);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var Builder = (function (_React$Component) {
                    function Builder() {
                        return _classCallCheck(this, Builder), _possibleConstructorReturn(this, (Builder.__proto__ || Object.getPrototypeOf(Builder)).apply(this, arguments));
                    }
                    return (
                        _inherits(Builder, _React$Component),
                        _createClass(Builder, [
                            {
                                key: "render",
                                value: function () {
                                    var e = this.props,
                                        t = e.mode,
                                        r = e.setMode,
                                        n = e.color,
                                        o = e.setColor,
                                        a = e.gridVisible,
                                        i = e.toggleGrid,
                                        l = e.dimensions,
                                        u = e.setBrick,
                                        s = e.utilsOpen,
                                        c = e.toggleUtils,
                                        p = e.removeBrick,
                                        f = e.addBrick,
                                        d = e.bricks,
                                        _ = e.updateBrick,
                                        h = e.resetScene,
                                        b = e.setScene;
                                    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        { className: styles_containers_builder__WEBPACK_IMPORTED_MODULE_9___default.a.builder },
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            components_Topbar__WEBPACK_IMPORTED_MODULE_6__.a,
                                            { onClickSetMode: r, onClickSetColor: o, onClickToggleGrid: i, mode: t, color: n, grid: a, brickSize: l, onClickSetBrick: u, utilsOpen: s, onClickToggleUtils: c },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Sidebar__WEBPACK_IMPORTED_MODULE_8__.a, { utilsOpen: s, resetScene: h, objects: d, importScene: b })
                                        ),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_engine_Scene__WEBPACK_IMPORTED_MODULE_5__.a, {
                                            brickColor: n,
                                            objects: d,
                                            mode: t,
                                            grid: a,
                                            dimensions: l,
                                            removeObject: p,
                                            addObject: f,
                                            updateObject: _,
                                        }),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Help__WEBPACK_IMPORTED_MODULE_7__.a, { inversed: s })
                                    );
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        Builder
                    );
                })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component),
                mapStateToProps = function (e) {
                    return {
                        mode: Object(selectors__WEBPACK_IMPORTED_MODULE_3__.f)(e),
                        color: Object(selectors__WEBPACK_IMPORTED_MODULE_3__.d)(e),
                        gridVisible: Object(selectors__WEBPACK_IMPORTED_MODULE_3__.e)(e),
                        dimensions: Object(selectors__WEBPACK_IMPORTED_MODULE_3__.b)(e),
                        utilsOpen: Object(selectors__WEBPACK_IMPORTED_MODULE_3__.a)(e),
                        bricks: Object(selectors__WEBPACK_IMPORTED_MODULE_3__.c)(e),
                    };
                },
                mapDispatchToProps = {
                    setMode: actions__WEBPACK_IMPORTED_MODULE_4__.f,
                    setColor: actions__WEBPACK_IMPORTED_MODULE_4__.e,
                    toggleGrid: actions__WEBPACK_IMPORTED_MODULE_4__.h,
                    setBrick: actions__WEBPACK_IMPORTED_MODULE_4__.d,
                    toggleUtils: actions__WEBPACK_IMPORTED_MODULE_4__.i,
                    removeBrick: actions__WEBPACK_IMPORTED_MODULE_4__.b,
                    addBrick: actions__WEBPACK_IMPORTED_MODULE_4__.a,
                    updateBrick: actions__WEBPACK_IMPORTED_MODULE_4__.j,
                    resetScene: actions__WEBPACK_IMPORTED_MODULE_4__.c,
                    setScene: actions__WEBPACK_IMPORTED_MODULE_4__.g,
                },
                _default = Object(redux__WEBPACK_IMPORTED_MODULE_2__.c)(Object(react_redux__WEBPACK_IMPORTED_MODULE_1__.b)(mapStateToProps, mapDispatchToProps))(Builder),
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Builder, "Builder", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        e.register(mapStateToProps, "mapStateToProps", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        e.register(mapDispatchToProps, "mapDispatchToProps", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Builder, "Builder", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        e.register(mapStateToProps, "mapStateToProps", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        e.register(mapDispatchToProps, "mapDispatchToProps", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/containers/Builder.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _toConsumableArray(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = new Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r;
                }
                return Array.from(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                pubsub_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26),
                pubsub_js__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(pubsub_js__WEBPACK_IMPORTED_MODULE_1__),
                if_only__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27),
                if_only__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(if_only__WEBPACK_IMPORTED_MODULE_2__),
                utils_threejs_detector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64),
                utils_threejs_detector__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(utils_threejs_detector__WEBPACK_IMPORTED_MODULE_3__),
                components_engine_Monitor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(113),
                components_engine_Brick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(28),
                components_Message__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65),
                components_engine_Helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(116),
                components_engine_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(21),
                utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7),
                utils_constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3),
                styles_components_scene__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(317),
                styles_components_scene__WEBPACK_IMPORTED_MODULE_11___default = __webpack_require__.n(styles_components_scene__WEBPACK_IMPORTED_MODULE_11__);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var Scene = (function (_React$Component) {
                    function Scene(e) {
                        var t;
                        return (
                            _classCallCheck(this, Scene),
                            (t = _possibleConstructorReturn(this, (Scene.__proto__ || Object.getPrototypeOf(Scene)).call(this, e))),
                            Object.defineProperty(t, "state", { configurable: !0, enumerable: !0, writable: !0, value: { drag: !1, isShiftDown: !1, isDDown: !1, isRDown: !1, rotation: 0, coreObjects: [] } }),
                            (t._start = t._start.bind(t)),
                            (t._stop = t._stop.bind(t)),
                            (t._animate = t._animate.bind(t)),
                            t
                        );
                    }
                    return (
                        _inherits(Scene, _React$Component),
                        _createClass(Scene, [
                            {
                                key: "componentDidMount",
                                value: function () {
                                    utils_threejs_detector__WEBPACK_IMPORTED_MODULE_3___default.a.webgl || utils_threejs_detector__WEBPACK_IMPORTED_MODULE_3___default.a.addGetWebGLMessage(),
                                        this._initCore(),
                                        this._initUtils(),
                                        this._initEnv(),
                                        this._setEventListeners(),
                                        this._start();
                                },
                            },
                            {
                                key: "componentDidUpdate",
                                value: function (e) {
                                    var t = this.props,
                                        r = t.mode,
                                        n = t.grid,
                                        o = t.dimensions,
                                        a = t.objects;
                                    r !== e.mode && "paint" === r ? (this.rollOverBrick.visible = !1) : r !== e.mode && "build" === r && (this.rollOverBrick.visible = !0),
                                        n !== e.grid && !0 === n ? (this.grid.visible = !0) : n !== e.grid && !0 !== n ? (this.grid.visible = !1) : (e.dimensions.x === o.x && e.dimensions.z === o.z) || this.rollOverBrick.setShape(o),
                                        a.length !== e.objects.length && this._setObjectsFromState();
                                },
                            },
                            {
                                key: "_initCore",
                                value: function () {
                                    var e = new THREE.Scene();
                                    this.scene = e;
                                    var t = new components_engine_core__WEBPACK_IMPORTED_MODULE_8__.f({ antialias: !0 });
                                    t.init(window.innerWidth, window.innerHeight), (this.renderer = t);
                                    var r = new components_engine_core__WEBPACK_IMPORTED_MODULE_8__.d(45, window.innerWidth / window.innerHeight, 1, 1e4);
                                    r.init(), (this.camera = r);
                                    var n = new components_engine_core__WEBPACK_IMPORTED_MODULE_8__.b(this.camera, this.renderer.domElement);
                                    n.init(), (this.controls = n), this.mount.appendChild(this.renderer.domElement);
                                },
                            },
                            {
                                key: "_initEnv",
                                value: function () {
                                    var e = new components_engine_core__WEBPACK_IMPORTED_MODULE_8__.c(16777215, 2);
                                    e.init(), this.scene.add(e);
                                    var t = new components_engine_core__WEBPACK_IMPORTED_MODULE_8__.a(6316128);
                                    this.scene.add(t);
                                    var r = new THREE.PointLight(16773360, 0.6, 100, 0);
                                    r.position.set(-1e3, 1500, 500), this.scene.add(r);
                                    var n = new components_engine_core__WEBPACK_IMPORTED_MODULE_8__.e(3e3);
                                    (this.plane = n), this.scene.add(n);
                                    var o = new THREE.GridHelper(1500, 60, new THREE.Color(12566463), new THREE.Color(14606046));
                                    (this.grid = o), this.scene.add(o), this.setState({ coreObjects: [e, t, r, n, o, this.rollOverBrick] });
                                },
                            },
                            {
                                key: "_initUtils",
                                value: function () {
                                    var e = this.props,
                                        t = e.brickColor,
                                        r = e.dimensions,
                                        n = new components_engine_Helpers__WEBPACK_IMPORTED_MODULE_7__.a(t, r);
                                    this.scene.add(n), (this.rollOverBrick = n);
                                    var o = new THREE.Raycaster();
                                    this.raycaster = o;
                                    var a = new THREE.Vector2();
                                    this.mouse = a;
                                },
                            },
                            {
                                key: "_setObjectsFromState",
                                value: function () {
                                    var e = this.props.objects,
                                        t = this.state.coreObjects;
                                    this.scene.children = [].concat(_toConsumableArray(e), _toConsumableArray(t));
                                },
                            },
                            {
                                key: "_setEventListeners",
                                value: function () {
                                    var e = this;
                                    document.addEventListener(
                                        "mousemove",
                                        function (t) {
                                            return e._onMouseMove(t, e);
                                        },
                                        !1
                                    ),
                                        document.addEventListener(
                                            "mousedown",
                                            function (t) {
                                                return e._onMouseDown(t);
                                            },
                                            !1
                                        ),
                                        document.addEventListener(
                                            "mouseup",
                                            function (t) {
                                                return e._onMouseUp(t, e);
                                            },
                                            !1
                                        ),
                                        document.addEventListener(
                                            "keydown",
                                            function (t) {
                                                return e._onKeyDown(t, e);
                                            },
                                            !1
                                        ),
                                        document.addEventListener(
                                            "keyup",
                                            function (t) {
                                                return e._onKeyUp(t, e);
                                            },
                                            !1
                                        ),
                                        window.addEventListener(
                                            "resize",
                                            function (t) {
                                                return e._onWindowResize(t, e);
                                            },
                                            !1
                                        );
                                },
                            },
                            {
                                key: "_onWindowResize",
                                value: function (e, t) {
                                    (t.camera.aspect = window.innerWidth / window.innerHeight), t.camera.updateProjectionMatrix(), t.renderer.setSize(window.innerWidth, window.innerHeight);
                                },
                            },
                            {
                                key: "_onMouseMove",
                                value: function (e, t) {
                                    var r = this.state,
                                        n = r.isDDown,
                                        o = r.isRDown,
                                        a = this.props,
                                        i = a.mode,
                                        l = a.dimensions,
                                        u = a.objects;
                                    e.preventDefault();
                                    this.setState({ drag: !0 });
                                    var s = Object(utils__WEBPACK_IMPORTED_MODULE_9__.d)(l),
                                        c = (s.width, s.height),
                                        p = l.x % 2 == 0,
                                        f = l.z % 2 == 0;
                                    t.mouse.set((e.clientX / window.innerWidth) * 2 - 1, (-e.clientY / window.innerHeight) * 2 + 1), t.raycaster.setFromCamera(t.mouse, t.camera);
                                    var d = t.raycaster.intersectObjects([].concat(_toConsumableArray(u), [this.plane]), !0);
                                    if (d.length > 0) {
                                        var _ = d[0];
                                        n ||
                                            (t.rollOverBrick.position.copy(_.point).add(_.face.normal),
                                            t.rollOverBrick.position
                                                .divide(new THREE.Vector3(utils_constants__WEBPACK_IMPORTED_MODULE_10__.a, c, utils_constants__WEBPACK_IMPORTED_MODULE_10__.a))
                                                .floor()
                                                .multiply(new THREE.Vector3(utils_constants__WEBPACK_IMPORTED_MODULE_10__.a, c, utils_constants__WEBPACK_IMPORTED_MODULE_10__.a))
                                                .add(
                                                    new THREE.Vector3(
                                                        p ? utils_constants__WEBPACK_IMPORTED_MODULE_10__.a : utils_constants__WEBPACK_IMPORTED_MODULE_10__.a / 2,
                                                        c / 2,
                                                        f ? utils_constants__WEBPACK_IMPORTED_MODULE_10__.a : utils_constants__WEBPACK_IMPORTED_MODULE_10__.a / 2
                                                    )
                                                )),
                                            _.object instanceof components_engine_Brick__WEBPACK_IMPORTED_MODULE_5__.a && (n || o || "paint" === i) ? this.setState({ brickHover: !0 }) : this.setState({ brickHover: !1 });
                                    }
                                },
                            },
                            {
                                key: "_onMouseDown",
                                value: function (e) {
                                    this.setState({ drag: !1 });
                                },
                            },
                            {
                                key: "_onMouseUp",
                                value: function (e, t) {
                                    var r = this.props,
                                        n = r.mode,
                                        o = r.objects,
                                        a = this.state,
                                        i = a.drag,
                                        l = a.isDDown;
                                    a.isRDown;
                                    if ("canvas" === e.target.localName && (e.preventDefault(), !i)) {
                                        t.mouse.set((e.clientX / window.innerWidth) * 2 - 1, (-e.clientY / window.innerHeight) * 2 + 1), t.raycaster.setFromCamera(t.mouse, t.camera);
                                        var u = t.raycaster.intersectObjects([].concat(_toConsumableArray(o), [this.plane]));
                                        if (u.length > 0) {
                                            var s = u[0];
                                            "build" === n ? (l ? this._deleteCube(s) : this._createCube(s, t.rollOverBrick)) : "paint" === n && this._paintCube(s);
                                        }
                                    }
                                },
                            },
                            {
                                key: "_createCube",
                                value: function (e, t) {
                                    this.state.rotation;
                                    for (
                                        var r = this.props,
                                            n = r.brickColor,
                                            o = r.dimensions,
                                            a = r.objects,
                                            i = r.addObject,
                                            l = !0,
                                            u = Object(utils__WEBPACK_IMPORTED_MODULE_9__.d)(o),
                                            s = u.width,
                                            c = u.depth,
                                            p = a,
                                            f = new THREE.Box3().setFromObject(this.rollOverBrick),
                                            d = 0;
                                        d < p.length;
                                        d++
                                    ) {
                                        var _ = new THREE.Box3().setFromObject(p[d]);
                                        if (f.intersectsBox(_)) {
                                            var h = Math.abs(_.max.x - f.max.x),
                                                b = Math.abs(_.max.z - f.max.z);
                                            if (_.max.y - 9 > f.min.y && h !== s && b !== c) {
                                                l = !1;
                                                break;
                                            }
                                        }
                                    }
                                    if (l) {
                                        var m = t.translation,
                                            g = t.rotation;
                                        i(new components_engine_Brick__WEBPACK_IMPORTED_MODULE_5__.a(e, n, o, g.y, m));
                                    }
                                },
                            },
                            {
                                key: "_deleteCube",
                                value: function (e) {
                                    var t = this.props.removeObject;
                                    e.object !== this.plane && (e.object.geometry.dispose(), t(e.object.customId));
                                },
                            },
                            {
                                key: "_paintCube",
                                value: function (e) {
                                    var t = this.props,
                                        r = t.brickColor,
                                        n = t.updateObject;
                                    e.object !== this.plane && (e.object.updateColor(r), n(e.object));
                                },
                            },
                            {
                                key: "_onKeyDown",
                                value: function (e, t) {
                                    switch (e.keyCode) {
                                        case 16:
                                            t.setState({ isShiftDown: !0 });
                                            break;
                                        case 68:
                                            t.setState({ isDDown: !0 }), (t.rollOverBrick.visible = !1);
                                            break;
                                        case 82:
                                            t.rollOverBrick.rotate(Math.PI / 2), t.setState({ isRDown: !0, rotation: t.rollOverBrick.rotation.y });
                                    }
                                },
                            },
                            {
                                key: "_onKeyUp",
                                value: function (e, t) {
                                    var r = this.props.mode;
                                    switch (e.keyCode) {
                                        case 16:
                                            t.setState({ isShiftDown: !1 });
                                            break;
                                        case 68:
                                            t.setState({ isDDown: !1 }), (t.rollOverBrick.visible = "build" === r);
                                            break;
                                        case 82:
                                            t.setState({ isRDown: !1 });
                                    }
                                },
                            },
                            {
                                key: "_start",
                                value: function () {
                                    this.frameId || (this.frameId = requestAnimationFrame(this._animate));
                                },
                            },
                            {
                                key: "_stop",
                                value: function () {
                                    cancelAnimationFrame(this.frameId);
                                },
                            },
                            {
                                key: "_animate",
                                value: function () {
                                    this.controls.update(), pubsub_js__WEBPACK_IMPORTED_MODULE_1___default.a.publish("monitor"), this._renderScene(), (this.frameId = window.requestAnimationFrame(this._animate));
                                },
                            },
                            {
                                key: "_renderScene",
                                value: function () {
                                    this.renderer.render(this.scene, this.camera);
                                },
                            },
                            {
                                key: "render",
                                value: function () {
                                    var e = this,
                                        t = this.state,
                                        r = t.brickHover,
                                        n = t.isShiftDown,
                                        o = t.isDDown,
                                        a = t.isRDown,
                                        i = this.props,
                                        l = i.mode,
                                        u = i.shifted;
                                    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        null,
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
                                            className: u ? styles_components_scene__WEBPACK_IMPORTED_MODULE_11___default.a.shifted : styles_components_scene__WEBPACK_IMPORTED_MODULE_11___default.a.scene,
                                            style: { cursor: n ? "move" : r ? "pointer" : "default" },
                                            ref: function (t) {
                                                e.mount = t;
                                            },
                                        }),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            if_only__WEBPACK_IMPORTED_MODULE_2___default.a,
                                            { cond: o && "build" === l },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                components_Message__WEBPACK_IMPORTED_MODULE_6__.a,
                                                null,
                                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-trash-a" }),
                                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Deleting bricks")
                                            )
                                        ),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            if_only__WEBPACK_IMPORTED_MODULE_2___default.a,
                                            { cond: a && "build" === l },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                components_Message__WEBPACK_IMPORTED_MODULE_6__.a,
                                                null,
                                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-refresh" }),
                                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Rotating bricks")
                                            )
                                        ),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_engine_Monitor__WEBPACK_IMPORTED_MODULE_4__.a, null)
                                    );
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        Scene
                    );
                })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component),
                _default = Scene,
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Scene, "Scene", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Scene.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Scene.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Scene, "Scene", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Scene.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Scene.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                pubsub_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26),
                pubsub_js__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(pubsub_js__WEBPACK_IMPORTED_MODULE_1__);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var Monitor = (function (_React$Component) {
                    function Monitor() {
                        return _classCallCheck(this, Monitor), _possibleConstructorReturn(this, (Monitor.__proto__ || Object.getPrototypeOf(Monitor)).apply(this, arguments));
                    }
                    return (
                        _inherits(Monitor, _React$Component),
                        _createClass(Monitor, [
                            {
                                key: "componentWillMount",
                                value: function () {
                                    var e = this,
                                        t = new Stats();
                                    (t.domElement.style.position = "absolute"),
                                        (t.domElement.style.bottom = "-35px"),
                                        (t.domElement.style.zIndex = 100),
                                        (this.stats = t),
                                        (this.updateSubscriber = pubsub_js__WEBPACK_IMPORTED_MODULE_1___default.a.subscribe("monitor", function () {
                                            return e._update(e);
                                        }));
                                },
                            },
                            {
                                key: "componentWillUnmount",
                                value: function () {
                                    pubsub_js__WEBPACK_IMPORTED_MODULE_1___default.a.unsubscribe(this.updateSubscriber);
                                },
                            },
                            {
                                key: "_update",
                                value: function (e) {
                                    e.stats.update();
                                },
                            },
                            {
                                key: "render",
                                value: function () {
                                    var e = this.stats.domElement;
                                    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
                                        ref: function (t) {
                                            t && t.appendChild(e);
                                        },
                                    });
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        Monitor
                    );
                })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component),
                _default = Monitor,
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Monitor, "Monitor", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Monitor.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Monitor.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Monitor, "Monitor", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Monitor.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Monitor.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        var n = r(152),
            o = r(153),
            a = o;
        (a.v1 = n), (a.v4 = o), (e.exports = a);
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                for (var t = new THREE.Geometry(), r = 0; r < e.length; r++) e[r].updateMatrix(), t.merge(e[r].geometry, e[r].matrix);
                return t;
            }
            function o(e, t) {
                return (
                    !(Math.abs(e.position.x - t.position.x) > (e.geometry.parameters.width + t.geometry.parameters.width) / 2) &&
                    !(Math.abs(e.position.y - t.position.y) > (e.geometry.parameters.height + t.geometry.parameters.height) / 2) &&
                    !(Math.abs(e.position.z - t.position.z) > (e.geometry.parameters.depth + t.geometry.parameters.depth) / 2)
                );
            }
            function a(e) {
                return e * (Math.PI / 180);
            }
            function i(e) {
                return 360 - (e / Math.PI) * 180;
            }
            r.d(t, "a", function () {
                return n;
            }),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).default,
                        l = r(1).leaveModule;
                    t &&
                        (t.register(n, "mergeMeshes", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        t.register(o, "collisonXYZ", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        t.register(a, "degToRad", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        t.register(i, "radToDeg", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        l(e));
                })(),
                (function () {
                    var t = r(1).default,
                        l = r(1).leaveModule;
                    t &&
                        (t.register(n, "mergeMeshes", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        t.register(o, "collisonXYZ", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        t.register(a, "degToRad", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        t.register(i, "radToDeg", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/index.js"),
                        l(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            __webpack_require__.d(__webpack_exports__, "a", function () {
                return RollOverBrick;
            });
            var utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7),
                utils_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var RollOverBrick = (function (_THREE$Mesh) {
                function RollOverBrick(e, t) {
                    var r;
                    _classCallCheck(this, RollOverBrick);
                    var n = Object(utils__WEBPACK_IMPORTED_MODULE_0__.d)(t),
                        o = n.width,
                        a = n.height,
                        i = n.depth,
                        l = new THREE.BoxGeometry(o, a, i),
                        u = new THREE.MeshBasicMaterial({ color: 530237, opacity: 0.5, transparent: !0 });
                    return (r = _possibleConstructorReturn(this, (RollOverBrick.__proto__ || Object.getPrototypeOf(RollOverBrick)).call(this, l, u))), (r.dimensions = t), (r.rotated = null), (r.translation = 0), r;
                }
                return (
                    _inherits(RollOverBrick, _THREE$Mesh),
                    _createClass(RollOverBrick, [
                        {
                            key: "setShape",
                            value: function (e) {
                                var t = Object(utils__WEBPACK_IMPORTED_MODULE_0__.d)(e),
                                    r = t.width,
                                    n = t.height,
                                    o = t.depth;
                                (this.geometry = new THREE.BoxGeometry(r, n, o)), (this.dimensions = e), (this.translation = 0), this.rotated && this.rotateY(-this.rotated), (this.rotated = null), console.log("set shape, reset");
                            },
                        },
                        {
                            key: "rotate",
                            value: function (e) {
                                this.rotated
                                    ? (((this.dimensions.z % 2 != 0 && this.dimensions.x % 2 == 0) || (this.dimensions.x % 2 != 0 && this.dimensions.z % 2 == 0)) &&
                                          (this.geometry.translate(utils_constants__WEBPACK_IMPORTED_MODULE_1__.a / 2, 0, utils_constants__WEBPACK_IMPORTED_MODULE_1__.a / 2), (this.translation = 0)),
                                      this.rotateY(-e),
                                      (this.rotated = null))
                                    : (((this.dimensions.z % 2 != 0 && this.dimensions.x % 2 == 0) || (this.dimensions.x % 2 != 0 && this.dimensions.z % 2 == 0)) &&
                                          (this.geometry.translate(-utils_constants__WEBPACK_IMPORTED_MODULE_1__.a / 2, 0, -utils_constants__WEBPACK_IMPORTED_MODULE_1__.a / 2),
                                          (this.translation = -utils_constants__WEBPACK_IMPORTED_MODULE_1__.a / 2)),
                                      this.rotateY(e),
                                      (this.rotated = e));
                            },
                        },
                        {
                            key: "__reactstandin__regenerateByEval",
                            value: function __reactstandin__regenerateByEval(key, code) {
                                this[key] = eval(code);
                            },
                        },
                    ]),
                    RollOverBrick
                );
            })(THREE.Mesh);
            !(function () {
                var e = __webpack_require__(1).default,
                    t = __webpack_require__(1).leaveModule;
                e && (e.register(RollOverBrick, "RollOverBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Helpers.js"), t(module));
            })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e && (e.register(RollOverBrick, "RollOverBrick", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/engine/Helpers.js"), t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            var n = r(0),
                o = r.n(n),
                a = r(30),
                i = r(118),
                l = r(120),
                u = r(325),
                s = r.n(u);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var c = function (e) {
                    var t = e.mode,
                        r = e.onClickSetMode,
                        n = e.color,
                        u = e.onClickSetColor,
                        c = e.grid,
                        p = e.onClickToggleGrid,
                        f = e.brickSize,
                        d = e.onClickSetBrick,
                        _ = e.utilsOpen,
                        h = e.onClickToggleUtils,
                        b = e.children;
                    return o.a.createElement(
                        "div",
                        { className: s.a.topbar },
                        o.a.createElement(
                            "div",
                            { className: s.a.section },
                            o.a.createElement("div", { className: s.a.title }, "Mode"),
                            o.a.createElement(a.a, {
                                active: "build" === t,
                                onClick: function () {
                                    return r("build");
                                },
                                icon: "hammer",
                                text: "Build",
                            }),
                            o.a.createElement(a.a, {
                                active: "paint" === t,
                                onClick: function () {
                                    return r("paint");
                                },
                                icon: "paintbrush",
                                text: "Paint",
                            })
                        ),
                        o.a.createElement("div", { className: s.a.section }, o.a.createElement("div", { className: s.a.title }, "Color"), o.a.createElement(i.a, { background: n, handleSetColor: u })),
                        o.a.createElement("div", { className: s.a.section }, o.a.createElement("div", { className: s.a.title }, "Brick"), o.a.createElement(l.a, { selectedSize: f, handleSetBrick: d })),
                        o.a.createElement("div", { className: s.a.section }, o.a.createElement("div", { className: s.a.title }, "Scene"), o.a.createElement(a.a, { active: c, onClick: p, icon: "grid", text: "Grid" })),
                        o.a.createElement("div", { className: s.a.rightSection }, o.a.createElement(a.a, { active: _, onClick: h, icon: "navicon-round", text: "Utils" })),
                        b
                    );
                },
                p = c,
                f = p;
            (t.a = f),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(c, "Topbar", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Topbar.jsx"),
                        t.register(p, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Topbar.jsx"),
                        n(e));
                })(),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(c, "Topbar", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Topbar.jsx"),
                        t.register(f, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Topbar.jsx"),
                        n(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                react_color__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(119),
                react_color__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(react_color__WEBPACK_IMPORTED_MODULE_1__),
                components_Icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(43),
                utils_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3),
                styles_components_color_picker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(321),
                styles_components_color_picker__WEBPACK_IMPORTED_MODULE_4___default = __webpack_require__.n(styles_components_color_picker__WEBPACK_IMPORTED_MODULE_4__);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var ColorPicker = (function (_React$Component) {
                    function ColorPicker(e) {
                        var t;
                        return (
                            _classCallCheck(this, ColorPicker),
                            (t = _possibleConstructorReturn(this, (ColorPicker.__proto__ || Object.getPrototypeOf(ColorPicker)).call(this, e))),
                            Object.defineProperty(t, "state", { configurable: !0, enumerable: !0, writable: !0, value: { open: !1 } }),
                            (t._handleChangeColor = t._handleChangeColor.bind(t)),
                            (t._togglePicker = t._togglePicker.bind(t)),
                            (t._handleClickOutside = t._handleClickOutside.bind(t)),
                            t
                        );
                    }
                    return (
                        _inherits(ColorPicker, _React$Component),
                        _createClass(ColorPicker, [
                            {
                                key: "componentDidMount",
                                value: function () {
                                    var e = this.props.background;
                                    document.addEventListener("mousedown", this._handleClickOutside), this.setState({ background: e });
                                },
                            },
                            {
                                key: "componentWillUnmount",
                                value: function () {
                                    document.removeEventListener("mousedown", this._handleClickOutside);
                                },
                            },
                            {
                                key: "_handleChangeColor",
                                value: function (e) {
                                    (0, this.props.handleSetColor)(e.hex), this._togglePicker();
                                },
                            },
                            {
                                key: "_handleClickOutside",
                                value: function () {
                                    var e = this.props.background;
                                    this.picker && !this.picker.contains(event.target) && this.setState({ open: !1, background: e });
                                },
                            },
                            {
                                key: "_togglePicker",
                                value: function () {
                                    var e = this.props.background;
                                    this.setState({ open: !this.state.open, background: e });
                                },
                            },
                            {
                                key: "render",
                                value: function () {
                                    var e = this,
                                        t = this.state,
                                        r = t.background,
                                        n = t.open;
                                    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        { className: styles_components_color_picker__WEBPACK_IMPORTED_MODULE_4___default.a.colorPicker },
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            "div",
                                            { className: styles_components_color_picker__WEBPACK_IMPORTED_MODULE_4___default.a.brick, onClick: this._togglePicker },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(components_Icons__WEBPACK_IMPORTED_MODULE_2__.SimpleBrick, { color: r })
                                        ),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            "div",
                                            {
                                                className: n ? styles_components_color_picker__WEBPACK_IMPORTED_MODULE_4___default.a.visible : styles_components_color_picker__WEBPACK_IMPORTED_MODULE_4___default.a.picker,
                                                ref: function (t) {
                                                    return (e.picker = t);
                                                },
                                            },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_color__WEBPACK_IMPORTED_MODULE_1__.GithubPicker, {
                                                color: r,
                                                colors: utils_constants__WEBPACK_IMPORTED_MODULE_3__.c,
                                                onChangeComplete: this._handleChangeColor,
                                                onSwatchHover: function (t) {
                                                    return e.setState({ background: t.hex });
                                                },
                                            })
                                        )
                                    );
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        ColorPicker
                    );
                })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component),
                _default = ColorPicker,
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(ColorPicker, "ColorPicker", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/ColorPicker.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/ColorPicker.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(ColorPicker, "ColorPicker", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/ColorPicker.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/ColorPicker.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.CustomPicker = t.TwitterPicker = t.SwatchesPicker = t.SliderPicker = t.SketchPicker = t.PhotoshopPicker = t.MaterialPicker = t.HuePicker = t.GithubPicker = t.CompactPicker = t.ChromePicker = t.default = t.CirclePicker = t.BlockPicker = t.AlphaPicker = void 0);
        var o = r(156);
        Object.defineProperty(t, "AlphaPicker", {
            enumerable: !0,
            get: function () {
                return n(o).default;
            },
        });
        var a = r(277);
        Object.defineProperty(t, "BlockPicker", {
            enumerable: !0,
            get: function () {
                return n(a).default;
            },
        });
        var i = r(279);
        Object.defineProperty(t, "CirclePicker", {
            enumerable: !0,
            get: function () {
                return n(i).default;
            },
        });
        var l = r(281);
        Object.defineProperty(t, "ChromePicker", {
            enumerable: !0,
            get: function () {
                return n(l).default;
            },
        });
        var u = r(285);
        Object.defineProperty(t, "CompactPicker", {
            enumerable: !0,
            get: function () {
                return n(u).default;
            },
        });
        var s = r(288);
        Object.defineProperty(t, "GithubPicker", {
            enumerable: !0,
            get: function () {
                return n(s).default;
            },
        });
        var c = r(290);
        Object.defineProperty(t, "HuePicker", {
            enumerable: !0,
            get: function () {
                return n(c).default;
            },
        });
        var p = r(292);
        Object.defineProperty(t, "MaterialPicker", {
            enumerable: !0,
            get: function () {
                return n(p).default;
            },
        });
        var f = r(293);
        Object.defineProperty(t, "PhotoshopPicker", {
            enumerable: !0,
            get: function () {
                return n(f).default;
            },
        });
        var d = r(299);
        Object.defineProperty(t, "SketchPicker", {
            enumerable: !0,
            get: function () {
                return n(d).default;
            },
        });
        var _ = r(302);
        Object.defineProperty(t, "SliderPicker", {
            enumerable: !0,
            get: function () {
                return n(_).default;
            },
        });
        var h = r(306);
        Object.defineProperty(t, "SwatchesPicker", {
            enumerable: !0,
            get: function () {
                return n(h).default;
            },
        });
        var b = r(309);
        Object.defineProperty(t, "TwitterPicker", {
            enumerable: !0,
            get: function () {
                return n(b).default;
            },
        });
        var m = r(107);
        Object.defineProperty(t, "CustomPicker", {
            enumerable: !0,
            get: function () {
                return n(m).default;
            },
        });
        var g = n(l);
        t.default = g.default;
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                if_only__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27),
                if_only__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(if_only__WEBPACK_IMPORTED_MODULE_1__),
                lodash_isEqual__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(121),
                lodash_isEqual__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_2__),
                utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7),
                utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3),
                styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(323),
                styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default = __webpack_require__.n(styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5__);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var BrickPicker = (function (_React$Component) {
                    function BrickPicker(e) {
                        var t;
                        return (
                            _classCallCheck(this, BrickPicker),
                            (t = _possibleConstructorReturn(this, (BrickPicker.__proto__ || Object.getPrototypeOf(BrickPicker)).call(this, e))),
                            Object.defineProperty(t, "state", { configurable: !0, enumerable: !0, writable: !0, value: { open: !1 } }),
                            (t._togglePicker = t._togglePicker.bind(t)),
                            (t._handleClickOutside = t._handleClickOutside.bind(t)),
                            t
                        );
                    }
                    return (
                        _inherits(BrickPicker, _React$Component),
                        _createClass(BrickPicker, [
                            {
                                key: "componentDidMount",
                                value: function () {
                                    document.addEventListener("mousedown", this._handleClickOutside);
                                },
                            },
                            {
                                key: "componentWillUnmount",
                                value: function () {
                                    document.removeEventListener("mousedown", this._handleClickOutside);
                                },
                            },
                            {
                                key: "render",
                                value: function () {
                                    var e = this,
                                        t = this.props,
                                        r = t.selectedSize,
                                        n = t.handleSetBrick,
                                        o = this.state.open;
                                    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        { className: styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.brickPicker },
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            "div",
                                            { className: styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.brick, onClick: this._togglePicker },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                "div",
                                                { className: styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.brickIcon },
                                                Object(utils__WEBPACK_IMPORTED_MODULE_3__.c)(r)
                                            )
                                        ),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            if_only__WEBPACK_IMPORTED_MODULE_1___default.a,
                                            { cond: o },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                "div",
                                                {
                                                    className: styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.picker,
                                                    ref: function (t) {
                                                        return (e.picker = t);
                                                    },
                                                },
                                                utils_constants__WEBPACK_IMPORTED_MODULE_4__.b.map(function (e, t) {
                                                    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                        "div",
                                                        { key: t, className: styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.brickExample },
                                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                            "div",
                                                            {
                                                                className: lodash_isEqual__WEBPACK_IMPORTED_MODULE_2___default()(r, e)
                                                                    ? styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.selected
                                                                    : styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.brickThumb,
                                                                onClick: function () {
                                                                    return n(e);
                                                                },
                                                            },
                                                            Object(utils__WEBPACK_IMPORTED_MODULE_3__.c)(e)
                                                        ),
                                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                            "div",
                                                            { className: styles_components_brick_picker__WEBPACK_IMPORTED_MODULE_5___default.a.label },
                                                            Object(utils__WEBPACK_IMPORTED_MODULE_3__.b)(e)
                                                        )
                                                    );
                                                })
                                            )
                                        )
                                    );
                                },
                            },
                            {
                                key: "_togglePicker",
                                value: function () {
                                    this.setState({ open: !this.state.open });
                                },
                            },
                            {
                                key: "_handleClickOutside",
                                value: function () {
                                    this.picker && !this.picker.contains(event.target) && this.setState({ open: !1 });
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        BrickPicker
                    );
                })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component),
                _default = BrickPicker,
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(BrickPicker, "BrickPicker", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/BrickPicker.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/BrickPicker.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(BrickPicker, "BrickPicker", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/BrickPicker.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/BrickPicker.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        var n = r(59);
        e.exports = function (e, t) {
            return n(e, t);
        };
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(42),
                react_dom__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__),
                styles_components_help__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(327),
                styles_components_help__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(styles_components_help__WEBPACK_IMPORTED_MODULE_2__);
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var HelpModal = function (e) {
                    var t = e.open,
                        r = e.toggleClose;
                    return Object(react_dom__WEBPACK_IMPORTED_MODULE_1__.createPortal)(
                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                            "div",
                            { className: t ? styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.modalWrapper : styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.closedModal },
                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                "div",
                                { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.modal },
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                    "div",
                                    { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.close, onClick: r },
                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-close" })
                                ),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h1", { style: { textAlign: "center" } }, "GR8BRIK 3D"),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h2", { style: { textAlign: "center" } }, "Release 3-7-24"),
					  react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h5", { style: { textAlign: "center" } }, "Updates aren't avalable for this system"),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h3", null, "What is this?"),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, "Gr8brik is a block building browser game written in JavaScript, W3CSS and JSC3D. You can import and export models from the menu."),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h2", { style: { textAlign: "center" } }, "Available commands"),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                    "div",
                                    { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.section },
                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.icon },
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-hammer" })
                                    ),
                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        { style: { flex: 1 } },
                                        "In model mode you can place bricks with a ",
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", null, "LEFT"),
                                        " click. Choose between different sizes in the menu bar. ",
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null),
                                        " If you press ",
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", null, "D"),
                                        " at the same time you delete bricks. ",
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("br", null),
                                        "If you press ",
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", null, "R"),
                                        " you can rotate bricks."
                                    )
                                ),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                    "div",
                                    { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.section },
                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.icon },
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-paintbrush" })
                                    ),
                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", { style: { flex: 1 } }, "In PAINT mode you set the chosen color (on the menu bar) to existing bricks.")
                                ),
                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                    "div",
                                    { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.github },
                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-social-itch" }),
                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", { href: "http://evanrutledge226.itch.io/gr8brik-3d", target: "_blank" }, "View on itch.io")
                                )
                            )
                        ),
                        document.body
                    );
                },
                Help = (function (_React$Component) {
                    function Help(e) {
                        var t;
                        return (
                            _classCallCheck(this, Help),
                            (t = _possibleConstructorReturn(this, (Help.__proto__ || Object.getPrototypeOf(Help)).call(this, e))),
                            Object.defineProperty(t, "state", { configurable: !0, enumerable: !0, writable: !0, value: { open: !1 } }),
                            (t._toggleHelp = t._toggleHelp.bind(t)),
                            (t._handleClickEscape = t._handleClickEscape.bind(t)),
                            t
                        );
                    }
                    return (
                        _inherits(Help, _React$Component),
                        _createClass(Help, [
                            {
                                key: "componentDidMount",
                                value: function () {
                                    document.addEventListener("keydown", this._handleClickEscape, !1);
                                },
                            },
                            {
                                key: "componentWillUnmount",
                                value: function () {
                                    document.removeEventListener("keydown", this._handleClickEscape, !1);
                                },
                            },
                            {
                                key: "render",
                                value: function () {
                                    var e = this.state.open,
                                        t = this.props.inversed;
                                    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                        "div",
                                        { className: styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.help },
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            "div",
                                            { className: t ? styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.inversed : styles_components_help__WEBPACK_IMPORTED_MODULE_2___default.a.text, onClick: this._toggleHelp },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-information-circled" }),
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Help")
                                        ),
                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(HelpModal, { open: e, toggleClose: this._toggleHelp })
                                    );
                                },
                            },
                            {
                                key: "_toggleHelp",
                                value: function () {
                                    this.setState({ open: !this.state.open });
                                },
                            },
                            {
                                key: "_handleClickEscape",
                                value: function (e) {
                                    27 === e.keyCode && this.setState({ open: !1 });
                                },
                            },
                            {
                                key: "__reactstandin__regenerateByEval",
                                value: function __reactstandin__regenerateByEval(key, code) {
                                    this[key] = eval(code);
                                },
                            },
                        ]),
                        Help
                    );
                })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component),
                _default = Help,
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(HelpModal, "HelpModal", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Help.jsx"),
                        e.register(Help, "Help", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Help.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Help.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(HelpModal, "HelpModal", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Help.jsx"),
                        e.register(Help, "Help", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Help.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Help.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            function _applyDecoratedDescriptor(e, t, r, n, o) {
                var a = {};
                return (
                    Object.keys(n).forEach(function (e) {
                        a[e] = n[e];
                    }),
                    (a.enumerable = !!a.enumerable),
                    (a.configurable = !!a.configurable),
                    ("value" in a || a.initializer) && (a.writable = !0),
                    (a = r
                        .slice()
                        .reverse()
                        .reduce(function (r, n) {
                            return n(e, t, r) || r;
                        }, a)),
                    o && void 0 !== a.initializer && ((a.value = a.initializer ? a.initializer.call(o) : void 0), (a.initializer = void 0)),
                    void 0 === a.initializer && (Object.defineProperty(e, t, a), (a = null)),
                    a
                );
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                file_saver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(124),
                file_saver__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_1__),
                autobind_decorator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(29),
                autobind_decorator__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(autobind_decorator__WEBPACK_IMPORTED_MODULE_2__),
                _FileUploader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(125),
                components_engine_Brick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(28),
                _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(331),
                _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default = __webpack_require__.n(_styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5__),
                _class;
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var Sidebar =
                    ((_class = (function (_React$Component) {
                        function Sidebar() {
                            return _classCallCheck(this, Sidebar), _possibleConstructorReturn(this, (Sidebar.__proto__ || Object.getPrototypeOf(Sidebar)).apply(this, arguments));
                        }
                        return (
                            _inherits(Sidebar, _React$Component),
                            _createClass(Sidebar, [
                                {
                                    key: "render",
                                    value: function () {
                                        var e = this.props,
                                            t = e.utilsOpen,
                                            r = e.resetScene;
                                        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            "div",
                                            { className: t ? _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.visible : _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.sidebar },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                "div",
                                                { className: _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.content },
                                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                    "div",
                                                    { className: _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.row, onClick: r },
                                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                        "div",
                                                        { className: _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.text },
                                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-trash-a" }),
                                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Reset scene")
                                                    )
                                                ),
                                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                    "div",
                                                    { className: _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.row, onClick: this._exportFile },
                                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                        "div",
                                                        { className: _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.text },
                                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-log-out" }),
                                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Export scene")
                                                    )
                                                ),
                                                react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                    "div",
                                                    { className: _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.row },
                                                    react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                        _FileUploader__WEBPACK_IMPORTED_MODULE_3__.a,
                                                        { onFinish: this._importFile },
                                                        react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                                            "div",
                                                            { className: _styles_components_sidebar__WEBPACK_IMPORTED_MODULE_5___default.a.text },
                                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("i", { className: "ion-log-in" }),
                                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Import scene")
                                                        )
                                                    )
                                                )
                                            )
                                        );
                                    },
                                },
                                {
                                    key: "_exportFile",
                                    value: function () {
                                        var e = this.props.objects.map(function (e) {
                                                return { intersect: e._intersect, color: e._color, dimensions: e._dimensions, rotation: e._rotation, translation: e._translation };
                                            }),
                                            t = new Blob([JSON.stringify(e)], { type: "application/json", name: "scene.json" });
                                        Object(file_saver__WEBPACK_IMPORTED_MODULE_1__.saveAs)(t, "scene.json");
                                    },
                                },
                                {
                                    key: "_importFile",
                                    value: function (e) {
                                        (0, this.props.importScene)(
                                            e.map(function (e) {
                                                return new components_engine_Brick__WEBPACK_IMPORTED_MODULE_4__.a(e.intersect, e.color, e.dimensions, e.rotation, e.translation);
                                            })
                                        );
                                    },
                                },
                                {
                                    key: "__reactstandin__regenerateByEval",
                                    value: function __reactstandin__regenerateByEval(key, code) {
                                        this[key] = eval(code);
                                    },
                                },
                            ]),
                            Sidebar
                        );
                    })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component)),
                    _applyDecoratedDescriptor(_class.prototype, "_exportFile", [autobind_decorator__WEBPACK_IMPORTED_MODULE_2___default.a], Object.getOwnPropertyDescriptor(_class.prototype, "_exportFile"), _class.prototype),
                    _applyDecoratedDescriptor(_class.prototype, "_importFile", [autobind_decorator__WEBPACK_IMPORTED_MODULE_2___default.a], Object.getOwnPropertyDescriptor(_class.prototype, "_importFile"), _class.prototype),
                    _class),
                _default = Sidebar,
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Sidebar, "Sidebar", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Sidebar.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Sidebar.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(Sidebar, "Sidebar", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Sidebar.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/Sidebar.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        var n,
            o =
                o ||
                (function (e) {
                    "use strict";
                    if (!(void 0 === e || ("undefined" != typeof navigator && /MSIE [1-9]\./.test(navigator.userAgent)))) {
                        var t = function () {
                                return e.URL || e.webkitURL || e;
                            },
                            r = e.document.createElementNS("http://www.w3.org/1999/xhtml", "a"),
                            n = "download" in r,
                            o = function (e) {
                                var t = new MouseEvent("click");
                                e.dispatchEvent(t);
                            },
                            a = /constructor/i.test(e.HTMLElement) || e.safari,
                            i = /CriOS\/[\d]+/.test(navigator.userAgent),
                            l = function (t) {
                                (e.setImmediate || e.setTimeout)(function () {
                                    throw t;
                                }, 0);
                            },
                            u = function (e) {
                                setTimeout(function () {
                                    "string" == typeof e ? t().revokeObjectURL(e) : e.remove();
                                }, 4e4);
                            },
                            s = function (e, t, r) {
                                for (var n = (t = [].concat(t)).length; n--; ) {
                                    var o = e["on" + t[n]];
                                    if ("function" == typeof o)
                                        try {
                                            o.call(e, r || e);
                                        } catch (e) {
                                            l(e);
                                        }
                                }
                            },
                            c = function (e) {
                                return /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(e.type) ? new Blob([String.fromCharCode(65279), e], { type: e.type }) : e;
                            },
                            p = function (l, p, f) {
                                f || (l = c(l));
                                var d,
                                    _ = this,
                                    h = "application/octet-stream" === l.type,
                                    b = function () {
                                        s(_, "writestart progress write writeend".split(" "));
                                    };
                                if (((_.readyState = _.INIT), n))
                                    return (
                                        (d = t().createObjectURL(l)),
                                        void setTimeout(function () {
                                            (r.href = d), (r.download = p), o(r), b(), u(d), (_.readyState = _.DONE);
                                        })
                                    );
                                !(function () {
                                    if ((i || (h && a)) && e.FileReader) {
                                        var r = new FileReader();
                                        return (
                                            (r.onloadend = function () {
                                                var t = i ? r.result : r.result.replace(/^data:[^;]*;/, "data:attachment/file;");
                                                e.open(t, "_blank") || (e.location.href = t), (t = void 0), (_.readyState = _.DONE), b();
                                            }),
                                            r.readAsDataURL(l),
                                            void (_.readyState = _.INIT)
                                        );
                                    }
                                    d || (d = t().createObjectURL(l)), h ? (e.location.href = d) : e.open(d, "_blank") || (e.location.href = d), (_.readyState = _.DONE), b(), u(d);
                                })();
                            },
                            f = p.prototype;
                        return "undefined" != typeof navigator && navigator.msSaveOrOpenBlob
                            ? function (e, t, r) {
                                  return (t = t || e.name || "download"), r || (e = c(e)), navigator.msSaveOrOpenBlob(e, t);
                              }
                            : ((f.abort = function () {}),
                              (f.readyState = f.INIT = 0),
                              (f.WRITING = 1),
                              (f.DONE = 2),
                              (f.error = f.onwritestart = f.onprogress = f.onwrite = f.onabort = f.onerror = f.onwriteend = null),
                              function (e, t, r) {
                                  return new p(e, t || e.name || "download", r);
                              });
                    }
                })(("undefined" != typeof self && self) || ("undefined" != typeof window && window) || this.content);
        e.exports
            ? (e.exports.saveAs = o)
            : null !== r(310) &&
              null !== r(311) &&
              void 0 !==
                  (n = function () {
                      return o;
                  }.call(t, r, t, e)) &&
              (e.exports = n);
    },
    function (module, __webpack_exports__, __webpack_require__) {
        "use strict";
        (function (module) {
            function _typeof(e) {
                return (_typeof =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (e) {
                              return typeof e;
                          }
                        : function (e) {
                              return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                          })(e);
            }
            function _classCallCheck(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function _defineProperties(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                }
            }
            function _createClass(e, t, r) {
                return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e;
            }
            function _possibleConstructorReturn(e, t) {
                if (t && ("object" === _typeof(t) || "function" == typeof t)) return t;
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function _inherits(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            }
            function _applyDecoratedDescriptor(e, t, r, n, o) {
                var a = {};
                return (
                    Object.keys(n).forEach(function (e) {
                        a[e] = n[e];
                    }),
                    (a.enumerable = !!a.enumerable),
                    (a.configurable = !!a.configurable),
                    ("value" in a || a.initializer) && (a.writable = !0),
                    (a = r
                        .slice()
                        .reverse()
                        .reduce(function (r, n) {
                            return n(e, t, r) || r;
                        }, a)),
                    o && void 0 !== a.initializer && ((a.value = a.initializer ? a.initializer.call(o) : void 0), (a.initializer = void 0)),
                    void 0 === a.initializer && (Object.defineProperty(e, t, a), (a = null)),
                    a
                );
            }
            var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0),
                react__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__),
                autobind_decorator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29),
                autobind_decorator__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(autobind_decorator__WEBPACK_IMPORTED_MODULE_1__),
                _styles_components_file_uploader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(329),
                _styles_components_file_uploader__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(_styles_components_file_uploader__WEBPACK_IMPORTED_MODULE_2__),
                _class;
            !(function () {
                var e = __webpack_require__(1).enterModule;
                e && e(module);
            })(),
                (function () {
                    var e = __webpack_require__(1).enterModule;
                    e && e(module);
                })();
            var FileUploader =
                    ((_class = (function (_React$Component) {
                        function FileUploader() {
                            var e, t, r;
                            _classCallCheck(this, FileUploader);
                            for (var n = arguments.length, o = new Array(n), a = 0; a < n; a++) o[a] = arguments[a];
                            return _possibleConstructorReturn(
                                r,
                                ((t = r = _possibleConstructorReturn(this, (e = FileUploader.__proto__ || Object.getPrototypeOf(FileUploader)).call.apply(e, [this].concat(o)))),
                                Object.defineProperty(r, "state", { configurable: !0, enumerable: !0, writable: !0, value: {} }),
                                t)
                            );
                        }
                        return (
                            _inherits(FileUploader, _React$Component),
                            _createClass(FileUploader, [
                                {
                                    key: "render",
                                    value: function () {
                                        var e = this,
                                            t = this.props.children;
                                        return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(
                                            "div",
                                            { className: _styles_components_file_uploader__WEBPACK_IMPORTED_MODULE_2___default.a.wrapper },
                                            react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", {
                                                key: "input",
                                                className: _styles_components_file_uploader__WEBPACK_IMPORTED_MODULE_2___default.a.input,
                                                type: "file",
                                                onChange: function (t) {
                                                    return e._handleFileChange(t);
                                                },
                                            }),
                                            t
                                        );
                                    },
                                },
                                {
                                    key: "_handleFileChange",
                                    value: function (e) {
                                        e.preventDefault();
                                        var t = this.props.onFinish,
                                            r = new FileReader(),
                                            n = e.target.files[0];
                                        (r.onloadend = function () {
                                            var e = r.result,
                                                n = JSON.parse(e);
                                            console.log("done reading"), t(n);
                                        }),
                                            r.readAsText(n),
                                            console.log("end of code");
                                    },
                                },
                                {
                                    key: "__reactstandin__regenerateByEval",
                                    value: function __reactstandin__regenerateByEval(key, code) {
                                        this[key] = eval(code);
                                    },
                                },
                            ]),
                            FileUploader
                        );
                    })(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component)),
                    _applyDecoratedDescriptor(_class.prototype, "_handleFileChange", [autobind_decorator__WEBPACK_IMPORTED_MODULE_1___default.a], Object.getOwnPropertyDescriptor(_class.prototype, "_handleFileChange"), _class.prototype),
                    _class),
                _default = FileUploader,
                _default2 = _default;
            (__webpack_exports__.a = _default2),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(FileUploader, "FileUploader", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/FileUploader.jsx"),
                        e.register(_default, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/FileUploader.jsx"),
                        t(module));
                })(),
                (function () {
                    var e = __webpack_require__(1).default,
                        t = __webpack_require__(1).leaveModule;
                    e &&
                        (e.register(FileUploader, "FileUploader", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/FileUploader.jsx"),
                        e.register(_default2, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/components/FileUploader.jsx"),
                        t(module));
                })();
        }.call(this, __webpack_require__(4)(module)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                return Object(o.d)(
                    a.a,
                    e,
                    (window.window.__REDUX_DEVTOOLS_EXTENSION__,
                    function (e) {
                        return e;
                    })
                );
            }
            r.d(t, "a", function () {
                return n;
            });
            var o = r(15),
                a = r(127);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "setupStore", "/Users/nick/Documents/Programming/repos/brick-builder/app/store.js"), o(e));
                })(),
                (function () {
                    var t = r(1).default,
                        o = r(1).leaveModule;
                    t && (t.register(n, "setupStore", "/Users/nick/Documents/Programming/repos/brick-builder/app/store.js"), o(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            var n = r(15),
                o = r(128),
                a = r(129),
                i = r(130);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var l = Object(n.b)({ builder: o.a, ui: a.a, scene: i.a }),
                u = l;
            (t.a = u),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t && (t.register(l, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/index.js"), n(e));
                })(),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t && (t.register(u, "default", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/index.js"), n(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n() {
                return (n =
                    Object.assign ||
                    function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = arguments[t];
                            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                        }
                        return e;
                    }).apply(this, arguments);
            }
            function o() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : l,
                    t = arguments[1];
                switch (t.type) {
                    case a.c:
                        return n({}, e, { mode: t.payload.mode });
                    case a.b:
                        return n({}, e, { color: t.payload.color });
                    case a.d:
                        return n({}, e, { grid: !e.grid });
                    case a.a:
                        return n({}, e, { brick: t.payload.brick });
                    default:
                        return e;
                }
            }
            r.d(t, "a", function () {
                return o;
            });
            var a = r(19),
                i = r(3);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var l = { mode: "build", grid: !0, color: i.c[0], brick: i.b[0] };
            !(function () {
                var t = r(1).default,
                    n = r(1).leaveModule;
                t &&
                    (t.register(l, "initialState", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/builder.js"),
                    t.register(o, "builder", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/builder.js"),
                    n(e));
            })(),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(o, "builder", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/builder.js"),
                        t.register(l, "initialState", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/builder.js"),
                        n(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n() {
                return (n =
                    Object.assign ||
                    function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = arguments[t];
                            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                        }
                        return e;
                    }).apply(this, arguments);
            }
            function o() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : i;
                switch (arguments[1].type) {
                    case a.a:
                        return n({}, e, { utilsOpen: !e.utilsOpen });
                    default:
                        return e;
                }
            }
            r.d(t, "a", function () {
                return o;
            });
            var a = r(40);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var i = { utilsOpen: !1 };
            !(function () {
                var t = r(1).default,
                    n = r(1).leaveModule;
                t && (t.register(i, "initialState", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/ui.js"), t.register(o, "ui", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/ui.js"), n(e));
            })(),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t && (t.register(o, "ui", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/ui.js"), t.register(i, "initialState", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/ui.js"), n(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        "use strict";
        (function (e) {
            function n(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, r = new Array(e.length); t < e.length; t++) r[t] = e[t];
                    return r;
                }
                return Array.from(e);
            }
            function o() {
                return (o =
                    Object.assign ||
                    function (e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = arguments[t];
                            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                        }
                        return e;
                    }).apply(this, arguments);
            }
            function a() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : l,
                    t = arguments[1];
                switch (t.type) {
                    case i.a:
                        var r = t.payload.brick;
                        return o({}, e, { bricks: [].concat(n(e.bricks), [r]) });
                    case i.b:
                        var a = t.payload.id;
                        return o({}, e, {
                            bricks: e.bricks.filter(function (e) {
                                return e.customId !== a;
                            }),
                        });
                    case i.e:
                        var u = t.payload.brick,
                            s = e.bricks.filter(function (e) {
                                return e.customId !== u.customId;
                            });
                        return o({}, e, { bricks: [].concat(n(s), [u]) });
                    case i.c:
                        return l;
                    case i.d:
                        return { bricks: t.payload.bricks };
                    default:
                        return e;
                }
            }
            r.d(t, "a", function () {
                return a;
            });
            var i = r(16);
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })();
            var l = { bricks: [] };
            !(function () {
                var t = r(1).default,
                    n = r(1).leaveModule;
                t && (t.register(l, "initialState", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/scene.js"), t.register(a, "scene", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/scene.js"), n(e));
            })(),
                (function () {
                    var t = r(1).default,
                        n = r(1).leaveModule;
                    t &&
                        (t.register(a, "scene", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/scene.js"),
                        t.register(l, "initialState", "/Users/nick/Documents/Programming/repos/brick-builder/app/reducer/scene.js"),
                        n(e));
                })();
        }.call(this, r(4)(e)));
    },
    function (e, t, r) {
        e.exports = r(132);
    },
    function (e, t, r) {
        "use strict";
        r.r(t),
            function (e) {
                function t(e) {
                    e();
                }
                var n = r(0),
                    o = r.n(n),
                    a = r(42),
                    i = r.n(a),
                    l = r(44),
                    u = r(1),
                    s = r(111),
                    c = r(126);
                r(335);
                !(function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                    (function () {
                        var t = r(1).enterModule;
                        t && t(e);
                    })();
                var p = Object(c.a)();
                t(function () {
                    i.a.render(o.a.createElement(u.AppContainer, null, o.a.createElement(l.a, { store: p }, o.a.createElement(s.a, null))), document.getElementById("root"));
                }),
                    (function () {
                        var n = r(1).default,
                            o = r(1).leaveModule;
                        n && (n.register(t, "enableHMR", "/Users/nick/Documents/Programming/repos/brick-builder/app/app.js"), n.register(p, "store", "/Users/nick/Documents/Programming/repos/brick-builder/app/app.js"), o(e));
                    })(),
                    (function () {
                        var n = r(1).default,
                            o = r(1).leaveModule;
                        n && (n.register(t, "enableHMR", "/Users/nick/Documents/Programming/repos/brick-builder/app/app.js"), n.register(p, "store", "/Users/nick/Documents/Programming/repos/brick-builder/app/app.js"), o(e));
                    })();
            }.call(this, r(4)(e));
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        var n = (function (e) {
                return e && "object" == typeof e && "default" in e ? e.default : e;
            })(r(0)),
            o = function (e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            },
            a = function (e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
            },
            i = function (e, t) {
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
            },
            l = (function (e) {
                function t() {
                    return o(this, t), i(this, e.apply(this, arguments));
                }
                return (
                    a(t, e),
                    (t.prototype.render = function () {
                        return n.Children.only(this.props.children);
                    }),
                    t
                );
            })(n.Component);
        (t.AppContainer = l),
            (t.hot = function () {
                return function (e) {
                    return e;
                };
            }),
            (t.areComponentsEqual = function (e, t) {
                return e === t;
            }),
            (t.setConfig = function () {}),
            (t.cold = function (e) {
                return e;
            }),
            (t.configureComponent = function () {});
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            for (var t = arguments.length - 1, r = "Minified React error #" + e + "; visit http://facebook.github.io/react/docs/error-decoder.html?invariant=" + e, n = 0; n < t; n++) r += "&args[]=" + encodeURIComponent(arguments[n + 1]);
            throw ((t = Error(r + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.")), (t.name = "Invariant Violation"), (t.framesToPop = 1), t);
        }
        function o(e, t, r) {
            (this.props = e), (this.context = t), (this.refs = g), (this.updater = r || y);
        }
        function a(e, t, r) {
            (this.props = e), (this.context = t), (this.refs = g), (this.updater = r || y);
        }
        function i() {}
        function l(e, t, r) {
            (this.props = e), (this.context = t), (this.refs = g), (this.updater = r || y);
        }
        function u(e, t, r, n, o, a, i) {
            return { $$typeof: w, type: e, key: t, ref: r, props: i, _owner: a };
        }
        function s(e) {
            var t = { "=": "=0", ":": "=2" };
            return (
                "$" +
                ("" + e).replace(/[=:]/g, function (e) {
                    return t[e];
                })
            );
        }
        function c(e, t, r, n) {
            if (S.length) {
                var o = S.pop();
                return (o.result = e), (o.keyPrefix = t), (o.func = r), (o.context = n), (o.count = 0), o;
            }
            return { result: e, keyPrefix: t, func: r, context: n, count: 0 };
        }
        function p(e) {
            (e.result = null), (e.keyPrefix = null), (e.func = null), (e.context = null), (e.count = 0), 10 > S.length && S.push(e);
        }
        function f(e, t, r, o) {
            var a = typeof e;
            if ((("undefined" !== a && "boolean" !== a) || (e = null), null === e || "string" === a || "number" === a || ("object" === a && e.$$typeof === D))) return r(o, e, "" === t ? "." + d(e, 0) : t), 1;
            var i = 0;
            if (((t = "" === t ? "." : t + ":"), Array.isArray(e)))
                for (var l = 0; l < e.length; l++) {
                    var u = t + d((a = e[l]), l);
                    i += f(a, u, r, o);
                }
            else if ("function" == typeof (u = (M && e[M]) || e["@@iterator"])) for (e = u.call(e), l = 0; !(a = e.next()).done; ) (a = a.value), (u = t + d(a, l++)), (i += f(a, u, r, o));
            else "object" === a && ((r = "" + e), n("31", "[object Object]" === r ? "object with keys {" + Object.keys(e).join(", ") + "}" : r, ""));
            return i;
        }
        function d(e, t) {
            return "object" == typeof e && null !== e && null != e.key ? s(e.key) : t.toString(36);
        }
        function _(e, t) {
            e.func.call(e.context, t, e.count++);
        }
        function h(e, t, r) {
            var n = e.result,
                o = e.keyPrefix;
            (e = e.func.call(e.context, t, e.count++)),
                Array.isArray(e) ? b(e, n, r, v.thatReturnsArgument) : null != e && (u.isValidElement(e) && (e = u.cloneAndReplaceKey(e, o + (!e.key || (t && t.key === e.key) ? "" : ("" + e.key).replace(T, "$&/") + "/") + r)), n.push(e));
        }
        function b(e, t, r, n, o) {
            var a = "";
            null != r && (a = ("" + r).replace(T, "$&/") + "/"), (t = c(t, a, n, o)), null == e || f(e, "", h, t), p(t);
        }
        var m = r(66),
            g = r(135);
        r(136);
        var v = r(137),
            y = {
                isMounted: function () {
                    return !1;
                },
                enqueueForceUpdate: function () {},
                enqueueReplaceState: function () {},
                enqueueSetState: function () {},
            };
        (o.prototype.isReactComponent = {}),
            (o.prototype.setState = function (e, t) {
                "object" != typeof e && "function" != typeof e && null != e && n("85"), this.updater.enqueueSetState(this, e, t, "setState");
            }),
            (o.prototype.forceUpdate = function (e) {
                this.updater.enqueueForceUpdate(this, e, "forceUpdate");
            }),
            (i.prototype = o.prototype);
        var E = (a.prototype = new i());
        (E.constructor = a), m(E, o.prototype), (E.isPureReactComponent = !0);
        var C = (l.prototype = new i());
        (C.constructor = l),
            m(C, o.prototype),
            (C.unstable_isAsyncReactComponent = !0),
            (C.render = function () {
                return this.props.children;
            });
        var k = { Component: o, PureComponent: a, AsyncComponent: l },
            P = { current: null },
            x = Object.prototype.hasOwnProperty,
            w = ("function" == typeof Symbol && Symbol.for && Symbol.for("react.element")) || 60103,
            O = { key: !0, ref: !0, __self: !0, __source: !0 };
        (u.createElement = function (e, t, r) {
            var n,
                o = {},
                a = null,
                i = null,
                l = null,
                s = null;
            if (null != t)
                for (n in (void 0 !== t.ref && (i = t.ref), void 0 !== t.key && (a = "" + t.key), (l = void 0 === t.__self ? null : t.__self), (s = void 0 === t.__source ? null : t.__source), t))
                    x.call(t, n) && !O.hasOwnProperty(n) && (o[n] = t[n]);
            var c = arguments.length - 2;
            if (1 === c) o.children = r;
            else if (1 < c) {
                for (var p = Array(c), f = 0; f < c; f++) p[f] = arguments[f + 2];
                o.children = p;
            }
            if (e && e.defaultProps) for (n in (c = e.defaultProps)) void 0 === o[n] && (o[n] = c[n]);
            return u(e, a, i, l, s, P.current, o);
        }),
            (u.createFactory = function (e) {
                var t = u.createElement.bind(null, e);
                return (t.type = e), t;
            }),
            (u.cloneAndReplaceKey = function (e, t) {
                return u(e.type, t, e.ref, e._self, e._source, e._owner, e.props);
            }),
            (u.cloneElement = function (e, t, r) {
                var n = m({}, e.props),
                    o = e.key,
                    a = e.ref,
                    i = e._self,
                    l = e._source,
                    s = e._owner;
                if (null != t) {
                    if ((void 0 !== t.ref && ((a = t.ref), (s = P.current)), void 0 !== t.key && (o = "" + t.key), e.type && e.type.defaultProps)) var c = e.type.defaultProps;
                    for (p in t) x.call(t, p) && !O.hasOwnProperty(p) && (n[p] = void 0 === t[p] && void 0 !== c ? c[p] : t[p]);
                }
                var p = arguments.length - 2;
                if (1 === p) n.children = r;
                else if (1 < p) {
                    c = Array(p);
                    for (var f = 0; f < p; f++) c[f] = arguments[f + 2];
                    n.children = c;
                }
                return u(e.type, o, a, i, l, s, n);
            }),
            (u.isValidElement = function (e) {
                return "object" == typeof e && null !== e && e.$$typeof === w;
            });
        var M = "function" == typeof Symbol && Symbol.iterator,
            D = ("function" == typeof Symbol && Symbol.for && Symbol.for("react.element")) || 60103,
            T = /\/+/g,
            S = [],
            R = {
                forEach: function (e, t, r) {
                    if (null == e) return e;
                    (t = c(null, null, t, r)), null == e || f(e, "", _, t), p(t);
                },
                map: function (e, t, r) {
                    if (null == e) return e;
                    var n = [];
                    return b(e, n, null, t, r), n;
                },
                count: function (e) {
                    return null == e ? 0 : f(e, "", v.thatReturnsNull, null);
                },
                toArray: function (e) {
                    var t = [];
                    return b(e, t, null, v.thatReturnsArgument), t;
                },
            };
        e.exports = {
            Children: {
                map: R.map,
                forEach: R.forEach,
                count: R.count,
                toArray: R.toArray,
                only: function (e) {
                    return u.isValidElement(e) || n("143"), e;
                },
            },
            Component: k.Component,
            PureComponent: k.PureComponent,
            unstable_AsyncComponent: k.AsyncComponent,
            createElement: u.createElement,
            cloneElement: u.cloneElement,
            isValidElement: u.isValidElement,
            createFactory: u.createFactory,
            version: "16.0.0",
            __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: { ReactCurrentOwner: P, assign: m },
        };
    },
    function (e, t, r) {
        "use strict";
        var n = {};
        e.exports = n;
    },
    function (e, t, r) {
        "use strict";
        var n = function (e) {};
        e.exports = function (e, t, r, o, a, i, l, u) {
            if ((n(t), !e)) {
                var s;
                if (void 0 === t) s = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                else {
                    var c = [r, o, a, i, l, u],
                        p = 0;
                    (s = new Error(
                        t.replace(/%s/g, function () {
                            return c[p++];
                        })
                    )).name = "Invariant Violation";
                }
                throw ((s.framesToPop = 1), s);
            }
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return function () {
                return e;
            };
        }
        var o = function () {};
        (o.thatReturns = n),
            (o.thatReturnsFalse = n(!1)),
            (o.thatReturnsTrue = n(!0)),
            (o.thatReturnsNull = n(null)),
            (o.thatReturnsThis = function () {
                return this;
            }),
            (o.thatReturnsArgument = function (e) {
                return e;
            }),
            (e.exports = o);
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            for (var t = arguments.length - 1, r = "Minified React error #" + e + "; visit http://facebook.github.io/react/docs/error-decoder.html?invariant=" + e, n = 0; n < t; n++) r += "&args[]=" + encodeURIComponent(arguments[n + 1]);
            throw ((t = Error(r + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.")), (t.name = "Invariant Violation"), (t.framesToPop = 1), t);
        }
        function o(e) {
            switch (e) {
                case "svg":
                    return "http://www.w3.org/2000/svg";
                case "math":
                    return "http://www.w3.org/1998/Math/MathML";
                default:
                    return "http://www.w3.org/1999/xhtml";
            }
        }
        function a() {
            if (Mt)
                for (var e in Dt) {
                    var t = Dt[e],
                        r = Mt.indexOf(e);
                    if ((-1 < r || n("96", e), !Tt.plugins[r])) {
                        t.extractEvents || n("97", e), (Tt.plugins[r] = t), (r = t.eventTypes);
                        for (var o in r) {
                            var a = void 0,
                                l = r[o],
                                u = t,
                                s = o;
                            Tt.eventNameDispatchConfigs.hasOwnProperty(s) && n("99", s), (Tt.eventNameDispatchConfigs[s] = l);
                            var c = l.phasedRegistrationNames;
                            if (c) {
                                for (a in c) c.hasOwnProperty(a) && i(c[a], u, s);
                                a = !0;
                            } else l.registrationName ? (i(l.registrationName, u, s), (a = !0)) : (a = !1);
                            a || n("98", o, e);
                        }
                    }
                }
        }
        function i(e, t, r) {
            Tt.registrationNameModules[e] && n("100", e), (Tt.registrationNameModules[e] = t), (Tt.registrationNameDependencies[e] = t.eventTypes[r].dependencies);
        }
        function l(e, t) {
            return (e & t) === t;
        }
        function u(e) {
            for (var t; (t = e._renderedComponent); ) e = t;
            return e;
        }
        function s(e, t) {
            ((e = u(e))._hostNode = t), (t[qt] = e);
        }
        function c(e, t) {
            if (!(e._flags & Kt.hasCachedChildNodes)) {
                var r = e._renderedChildren;
                t = t.firstChild;
                var o;
                e: for (o in r)
                    if (r.hasOwnProperty(o)) {
                        var a = r[o],
                            i = u(a)._domID;
                        if (0 !== i) {
                            for (; null !== t; t = t.nextSibling) {
                                var l = t,
                                    c = i;
                                if ((l.nodeType === Nt && l.getAttribute(Ht) === "" + c) || (l.nodeType === Wt && l.nodeValue === " react-text: " + c + " ") || (l.nodeType === Wt && l.nodeValue === " react-empty: " + c + " ")) {
                                    s(a, t);
                                    continue e;
                                }
                            }
                            n("32", i);
                        }
                    }
                e._flags |= Kt.hasCachedChildNodes;
            }
        }
        function p(e) {
            if (e[qt]) return e[qt];
            for (var t = []; !e[qt]; ) {
                if ((t.push(e), !e.parentNode)) return null;
                e = e.parentNode;
            }
            var r = e[qt];
            if (r.tag === Lt || r.tag === Ft) return r;
            for (; e && (r = e[qt]); e = t.pop()) {
                var n = r;
                t.length && c(r, e);
            }
            return n;
        }
        function f(e) {
            if ("function" == typeof e.getName) return e.getName();
            if ("number" == typeof e.tag) {
                if ("string" == typeof (e = e.type)) return e;
                if ("function" == typeof e) return e.displayName || e.name;
            }
            return null;
        }
        function d(e) {
            var t = e;
            if (e.alternate) for (; t.return; ) t = t.return;
            else {
                if ((t.effectTag & rr) !== tr) return 1;
                for (; t.return; ) if (((t = t.return).effectTag & rr) !== tr) return 1;
            }
            return t.tag === Qt ? 2 : 3;
        }
        function _(e) {
            2 !== d(e) && n("188");
        }
        function h(e) {
            var t = e.alternate;
            if (!t) return 3 === (t = d(e)) && n("188"), 1 === t ? null : e;
            for (var r = e, o = t; ; ) {
                var a = r.return,
                    i = a ? a.alternate : null;
                if (!a || !i) break;
                if (a.child === i.child) {
                    for (var l = a.child; l; ) {
                        if (l === r) return _(a), e;
                        if (l === o) return _(a), t;
                        l = l.sibling;
                    }
                    n("188");
                }
                if (r.return !== o.return) (r = a), (o = i);
                else {
                    l = !1;
                    for (var u = a.child; u; ) {
                        if (u === r) {
                            (l = !0), (r = a), (o = i);
                            break;
                        }
                        if (u === o) {
                            (l = !0), (o = a), (r = i);
                            break;
                        }
                        u = u.sibling;
                    }
                    if (!l) {
                        for (u = i.child; u; ) {
                            if (u === r) {
                                (l = !0), (r = i), (o = a);
                                break;
                            }
                            if (u === o) {
                                (l = !0), (o = i), (r = a);
                                break;
                            }
                            u = u.sibling;
                        }
                        l || n("189");
                    }
                }
                r.alternate !== o && n("190");
            }
            return r.tag !== Qt && n("188"), r.stateNode.current === r ? e : t;
        }
        function b(e, t, r, n, o, a, i, l, u) {
            (or._hasCaughtError = !1), (or._caughtError = null);
            var s = Array.prototype.slice.call(arguments, 3);
            try {
                t.apply(r, s);
            } catch (e) {
                (or._caughtError = e), (or._hasCaughtError = !0);
            }
        }
        function m() {
            if (or._hasRethrowError) {
                var e = or._rethrowError;
                throw ((or._rethrowError = null), (or._hasRethrowError = !1), e);
            }
        }
        function g(e, t, r, n) {
            (t = e.type || "unknown-event"), (e.currentTarget = ir.getNodeFromInstance(n)), ar.invokeGuardedCallbackAndCatchFirstError(t, r, void 0, e), (e.currentTarget = null);
        }
        function v(e) {
            if ((e = lr.getInstanceFromNode(e)))
                if ("number" == typeof e.tag) {
                    (ur && "function" == typeof ur.restoreControlledState) || n("194");
                    var t = lr.getFiberCurrentPropsFromNode(e.stateNode);
                    ur.restoreControlledState(e.stateNode, e.type, t);
                } else "function" != typeof e.restoreControlledState && n("195"), e.restoreControlledState();
        }
        function y(e, t, r, n, o, a) {
            return e(t, r, n, o, a);
        }
        function E(e, t) {
            return e(t);
        }
        function C(e, t) {
            return E(e, t);
        }
        function k(e) {
            return (e = e.target || e.srcElement || window).correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === _r ? e.parentNode : e;
        }
        function P(e) {
            var t = e.targetInst;
            do {
                if (!t) {
                    e.ancestors.push(t);
                    break;
                }
                var r = t;
                if ("number" == typeof r.tag) {
                    for (; r.return; ) r = r.return;
                    r = r.tag !== hr ? null : r.stateNode.containerInfo;
                } else {
                    for (; r._hostParent; ) r = r._hostParent;
                    r = Vt.getNodeFromInstance(r).parentNode;
                }
                if (!r) break;
                e.ancestors.push(t), (t = Vt.getClosestInstanceFromNode(r));
            } while (t);
            for (r = 0; r < e.ancestors.length; r++) (t = e.ancestors[r]), mr._handleTopLevel(e.topLevelType, t, e.nativeEvent, k(e.nativeEvent));
        }
        function x(e, t) {
            return null == t && n("30"), null == e ? t : Array.isArray(e) ? (Array.isArray(t) ? (e.push.apply(e, t), e) : (e.push(t), e)) : Array.isArray(t) ? [e].concat(t) : [e, t];
        }
        function w(e, t, r) {
            Array.isArray(e) ? e.forEach(t, r) : e && t.call(r, e);
        }
        function O(e, t) {
            e && (lr.executeDispatchesInOrder(e, t), e.isPersistent() || e.constructor.release(e));
        }
        function M(e) {
            return O(e, !0);
        }
        function D(e) {
            return O(e, !1);
        }
        function T(e, t, r) {
            switch (e) {
                case "onClick":
                case "onClickCapture":
                case "onDoubleClick":
                case "onDoubleClickCapture":
                case "onMouseDown":
                case "onMouseDownCapture":
                case "onMouseMove":
                case "onMouseMoveCapture":
                case "onMouseUp":
                case "onMouseUpCapture":
                    return !(!r.disabled || ("button" !== t && "input" !== t && "select" !== t && "textarea" !== t));
                default:
                    return !1;
            }
        }
        function S(e, t) {
            if (!bt.canUseDOM || (t && !("addEventListener" in document))) return !1;
            var r = (t = "on" + e) in document;
            return r || ((r = document.createElement("div")).setAttribute(t, "return;"), (r = "function" == typeof r[t])), !r && wt && "wheel" === e && (r = document.implementation.hasFeature("Events.wheel", "3.0")), r;
        }
        function R(e, t) {
            var r = {};
            return (r[e.toLowerCase()] = t.toLowerCase()), (r["Webkit" + e] = "webkit" + t), (r["Moz" + e] = "moz" + t), (r["ms" + e] = "MS" + t), (r["O" + e] = "o" + t.toLowerCase()), r;
        }
        function j(e) {
            if (Cr[e]) return Cr[e];
            if (!Er[e]) return e;
            var t,
                r = Er[e];
            for (t in r) if (r.hasOwnProperty(t) && t in kr) return (Cr[e] = r[t]);
            return "";
        }
        function B(e) {
            return Object.prototype.hasOwnProperty.call(e, Or) || ((e[Or] = wr++), (xr[e[Or]] = {})), xr[e[Or]];
        }
        function A(e) {
            return !!Fr.hasOwnProperty(e) || (!Lr.hasOwnProperty(e) && (Ir.test(e) ? (Fr[e] = !0) : ((Lr[e] = !0), !1)));
        }
        function U() {
            return null;
        }
        function I(e) {
            var t = "";
            return (
                ht.Children.forEach(e, function (e) {
                    null == e || ("string" != typeof e && "number" != typeof e) || (t += e);
                }),
                t
            );
        }
        function L(e, t, r) {
            if (((e = e.options), t)) {
                t = {};
                for (var n = 0; n < r.length; n++) t["$" + r[n]] = !0;
                for (r = 0; r < e.length; r++) (n = t.hasOwnProperty("$" + e[r].value)), e[r].selected !== n && (e[r].selected = n);
            } else {
                for (r = "" + r, t = null, n = 0; n < e.length; n++) {
                    if (e[n].value === r) return void (e[n].selected = !0);
                    null !== t || e[n].disabled || (t = e[n]);
                }
                null !== t && (t.selected = !0);
            }
        }
        function F(e, t) {
            t &&
                (Zr[e] && (null != t.children || null != t.dangerouslySetInnerHTML) && n("137", e, ""),
                null != t.dangerouslySetInnerHTML && (null != t.children && n("60"), ("object" == typeof t.dangerouslySetInnerHTML && "__html" in t.dangerouslySetInnerHTML) || n("61")),
                null != t.style && "object" != typeof t.style && n("62", ""));
        }
        function N(e) {
            var t = e.type;
            return (e = e.nodeName) && "input" === e.toLowerCase() && ("checkbox" === t || "radio" === t);
        }
        function W(e) {
            var t = N(e) ? "checked" : "value",
                r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
                n = "" + e[t];
            if (!e.hasOwnProperty(t) && "function" == typeof r.get && "function" == typeof r.set)
                return (
                    Object.defineProperty(e, t, {
                        enumerable: r.enumerable,
                        configurable: !0,
                        get: function () {
                            return r.get.call(this);
                        },
                        set: function (e) {
                            (n = "" + e), r.set.call(this, e);
                        },
                    }),
                    {
                        getValue: function () {
                            return n;
                        },
                        setValue: function (e) {
                            n = "" + e;
                        },
                        stopTracking: function () {
                            (e._valueTracker = null), delete e[t];
                        },
                    }
                );
        }
        function H(e, t) {
            if (-1 === e.indexOf("-")) return "string" == typeof t.is;
            switch (e) {
                case "annotation-xml":
                case "color-profile":
                case "font-face":
                case "font-face-src":
                case "font-face-uri":
                case "font-face-format":
                case "font-face-name":
                case "missing-glyph":
                    return !1;
                default:
                    return !0;
            }
        }
        function K(e, t) {
            if (t) {
                var r = e.firstChild;
                if (r && r === e.lastChild && r.nodeType === rn) return void (r.nodeValue = t);
            }
            e.textContent = t;
        }
        function z(e, t) {
            ln(t, e.nodeType === on || e.nodeType === an ? e : e.ownerDocument);
        }
        function q(e, t) {
            return (e !== Rn && e !== Sn) || (t !== Rn && t !== Sn) ? (e === Tn && t !== Tn ? -255 : e !== Tn && t === Tn ? 255 : e - t) : 0;
        }
        function G() {
            return { first: null, last: null, hasForceUpdate: !1, callbackList: null };
        }
        function V(e, t, r, n) {
            null !== r ? (r.next = t) : ((t.next = e.first), (e.first = t)), null !== n ? (t.next = n) : (e.last = t);
        }
        function Y(e, t) {
            t = t.priorityLevel;
            var r = null;
            if (null !== e.last && 0 >= q(e.last.priorityLevel, t)) r = e.last;
            else for (e = e.first; null !== e && 0 >= q(e.priorityLevel, t); ) (r = e), (e = e.next);
            return r;
        }
        function $(e, t) {
            var r = e.alternate,
                n = e.updateQueue;
            null === n && (n = e.updateQueue = G()), null !== r ? null === (e = r.updateQueue) && (e = r.updateQueue = G()) : (e = null);
            var o = (An = n);
            r = Un = e !== n ? e : null;
            var a = Y(o, t),
                i = null !== a ? a.next : o.first;
            return null === r
                ? (V(o, t, a, i), null)
                : ((n = Y(r, t)),
                  (e = null !== n ? n.next : r.first),
                  V(o, t, a, i),
                  (i === e && null !== i) || (a === n && null !== a)
                      ? (null === n && (r.first = t), null === e && (r.last = null), null)
                      : ((t = { priorityLevel: t.priorityLevel, partialState: t.partialState, callback: t.callback, isReplace: t.isReplace, isForced: t.isForced, isTopLevelUnmount: t.isTopLevelUnmount, next: null }), V(r, t, n, e), t));
        }
        function X(e, t, r, n) {
            return "function" == typeof (e = e.partialState) ? e.call(t, r, n) : e;
        }
        function Z(e, t, r) {
            ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = t), (e.__reactInternalMemoizedMaskedChildContext = r);
        }
        function Q(e) {
            return e.tag === Hn && null != e.type.childContextTypes;
        }
        function J(e, t) {
            var r = e.stateNode,
                o = e.type.childContextTypes;
            if ("function" != typeof r.getChildContext) return t;
            r = r.getChildContext();
            for (var a in r) a in o || n("108", f(e) || "Unknown", a);
            return mt({}, t, r);
        }
        function ee(e, t, r) {
            (this.tag = e),
                (this.key = t),
                (this.stateNode = this.type = null),
                (this.sibling = this.child = this.return = null),
                (this.index = 0),
                (this.memoizedState = this.updateQueue = this.memoizedProps = this.pendingProps = this.ref = null),
                (this.internalContextTag = r),
                (this.effectTag = so),
                (this.lastEffect = this.firstEffect = this.nextEffect = null),
                (this.pendingWorkPriority = lo),
                (this.alternate = null);
        }
        function te(e, t, r) {
            var o = void 0;
            return (
                "function" == typeof e
                    ? ((o = e.prototype && e.prototype.isReactComponent ? new ee(Jn, t, r) : new ee(Qn, t, r)), (o.type = e))
                    : "string" == typeof e
                    ? ((o = new ee(to, t, r)), (o.type = e))
                    : "object" == typeof e && null !== e && "number" == typeof e.tag
                    ? (o = e)
                    : n("130", null == e ? e : typeof e, ""),
                o
            );
        }
        function re(e) {
            return null === e || void 0 === e ? null : "function" == typeof (e = (Wo && e[Wo]) || e["@@iterator"]) ? e : null;
        }
        function ne(e, t) {
            var r = t.ref;
            if (null !== r && "function" != typeof r) {
                if (t._owner) {
                    var o = void 0;
                    (t = t._owner) && ("number" == typeof t.tag ? (t.tag !== Ro && n("110"), (o = t.stateNode)) : (o = t.getPublicInstance())), o || n("147", r);
                    var a = "" + r;
                    return null !== e && null !== e.ref && e.ref._stringRef === a
                        ? e.ref
                        : ((e = function (e) {
                              var t = o.refs === yt ? (o.refs = {}) : o.refs;
                              null === e ? delete t[a] : (t[a] = e);
                          }),
                          (e._stringRef = a),
                          e);
                }
                "string" != typeof r && n("148"), t._owner || n("149", r);
            }
            return r;
        }
        function oe(e, t) {
            "textarea" !== e.type && n("31", "[object Object]" === Object.prototype.toString.call(t) ? "object with keys {" + Object.keys(t).join(", ") + "}" : t, "");
        }
        function ae(e, t) {
            function r(r, n) {
                if (t) {
                    if (!e) {
                        if (null === n.alternate) return;
                        n = n.alternate;
                    }
                    var o = r.lastEffect;
                    null !== o ? ((o.nextEffect = n), (r.lastEffect = n)) : (r.firstEffect = r.lastEffect = n), (n.nextEffect = null), (n.effectTag = No);
                }
            }
            function o(e, n) {
                if (!t) return null;
                for (; null !== n; ) r(e, n), (n = n.sibling);
                return null;
            }
            function a(e, t) {
                for (e = new Map(); null !== t; ) null !== t.key ? e.set(t.key, t) : e.set(t.index, t), (t = t.sibling);
                return e;
            }
            function i(t, r) {
                return e ? ((t = ko(t, r)), (t.index = 0), (t.sibling = null), t) : ((t.pendingWorkPriority = r), (t.effectTag = Lo), (t.index = 0), (t.sibling = null), t);
            }
            function l(e, r, n) {
                return (e.index = n), t ? (null !== (n = e.alternate) ? ((n = n.index) < r ? ((e.effectTag = Fo), r) : n) : ((e.effectTag = Fo), r)) : r;
            }
            function u(e) {
                return t && null === e.alternate && (e.effectTag = Fo), e;
            }
            function s(e, t, r, n) {
                return null === t || t.tag !== jo ? ((r = wo(r, e.internalContextTag, n)), (r.return = e), r) : ((t = i(t, n)), (t.pendingProps = r), (t.return = e), t);
            }
            function c(e, t, r, n) {
                return null === t || t.type !== r.type ? ((n = Po(r, e.internalContextTag, n)), (n.ref = ne(t, r)), (n.return = e), n) : ((n = i(t, n)), (n.ref = ne(t, r)), (n.pendingProps = r.props), (n.return = e), n);
            }
            function p(e, t, r, n) {
                return null === t || t.tag !== Ao ? ((r = Oo(r, e.internalContextTag, n)), (r.return = e), r) : ((t = i(t, n)), (t.pendingProps = r), (t.return = e), t);
            }
            function f(e, t, r, n) {
                return null === t || t.tag !== Uo ? ((t = Mo(r, e.internalContextTag, n)), (t.type = r.value), (t.return = e), t) : ((t = i(t, n)), (t.type = r.value), (t.return = e), t);
            }
            function d(e, t, r, n) {
                return null === t || t.tag !== Bo || t.stateNode.containerInfo !== r.containerInfo || t.stateNode.implementation !== r.implementation
                    ? ((r = Do(r, e.internalContextTag, n)), (r.return = e), r)
                    : ((t = i(t, n)), (t.pendingProps = r.children || []), (t.return = e), t);
            }
            function _(e, t, r, n) {
                return null === t || t.tag !== Io ? ((r = xo(r, e.internalContextTag, n)), (r.return = e), r) : ((t = i(t, n)), (t.pendingProps = r), (t.return = e), t);
            }
            function h(e, t, r) {
                if ("string" == typeof t || "number" == typeof t) return (t = wo("" + t, e.internalContextTag, r)), (t.return = e), t;
                if ("object" == typeof t && null !== t) {
                    switch (t.$$typeof) {
                        case Ho:
                            return (r = Po(t, e.internalContextTag, r)), (r.ref = ne(null, t)), (r.return = e), r;
                        case yo:
                            return (t = Oo(t, e.internalContextTag, r)), (t.return = e), t;
                        case Eo:
                            return (r = Mo(t, e.internalContextTag, r)), (r.type = t.value), (r.return = e), r;
                        case Co:
                            return (t = Do(t, e.internalContextTag, r)), (t.return = e), t;
                    }
                    if (To(t) || re(t)) return (t = xo(t, e.internalContextTag, r)), (t.return = e), t;
                    oe(e, t);
                }
                return null;
            }
            function b(e, t, r, n) {
                var o = null !== t ? t.key : null;
                if ("string" == typeof r || "number" == typeof r) return null !== o ? null : s(e, t, "" + r, n);
                if ("object" == typeof r && null !== r) {
                    switch (r.$$typeof) {
                        case Ho:
                            return r.key === o ? c(e, t, r, n) : null;
                        case yo:
                            return r.key === o ? p(e, t, r, n) : null;
                        case Eo:
                            return null === o ? f(e, t, r, n) : null;
                        case Co:
                            return r.key === o ? d(e, t, r, n) : null;
                    }
                    if (To(r) || re(r)) return null !== o ? null : _(e, t, r, n);
                    oe(e, r);
                }
                return null;
            }
            function m(e, t, r, n, o) {
                if ("string" == typeof n || "number" == typeof n) return (e = e.get(r) || null), s(t, e, "" + n, o);
                if ("object" == typeof n && null !== n) {
                    switch (n.$$typeof) {
                        case Ho:
                            return (e = e.get(null === n.key ? r : n.key) || null), c(t, e, n, o);
                        case yo:
                            return (e = e.get(null === n.key ? r : n.key) || null), p(t, e, n, o);
                        case Eo:
                            return (e = e.get(r) || null), f(t, e, n, o);
                        case Co:
                            return (e = e.get(null === n.key ? r : n.key) || null), d(t, e, n, o);
                    }
                    if (To(n) || re(n)) return (e = e.get(r) || null), _(t, e, n, o);
                    oe(t, n);
                }
                return null;
            }
            function g(e, n, i, u) {
                for (var s = null, c = null, p = n, f = (n = 0), d = null; null !== p && f < i.length; f++) {
                    p.index > f ? ((d = p), (p = null)) : (d = p.sibling);
                    var _ = b(e, p, i[f], u);
                    if (null === _) {
                        null === p && (p = d);
                        break;
                    }
                    t && p && null === _.alternate && r(e, p), (n = l(_, n, f)), null === c ? (s = _) : (c.sibling = _), (c = _), (p = d);
                }
                if (f === i.length) return o(e, p), s;
                if (null === p) {
                    for (; f < i.length; f++) (p = h(e, i[f], u)) && ((n = l(p, n, f)), null === c ? (s = p) : (c.sibling = p), (c = p));
                    return s;
                }
                for (p = a(e, p); f < i.length; f++) (d = m(p, e, f, i[f], u)) && (t && null !== d.alternate && p.delete(null === d.key ? f : d.key), (n = l(d, n, f)), null === c ? (s = d) : (c.sibling = d), (c = d));
                return (
                    t &&
                        p.forEach(function (t) {
                            return r(e, t);
                        }),
                    s
                );
            }
            function v(e, i, u, s) {
                var c = re(u);
                "function" != typeof c && n("150"), null == (u = c.call(u)) && n("151");
                for (var p = (c = null), f = i, d = (i = 0), _ = null, g = u.next(); null !== f && !g.done; d++, g = u.next()) {
                    f.index > d ? ((_ = f), (f = null)) : (_ = f.sibling);
                    var v = b(e, f, g.value, s);
                    if (null === v) {
                        f || (f = _);
                        break;
                    }
                    t && f && null === v.alternate && r(e, f), (i = l(v, i, d)), null === p ? (c = v) : (p.sibling = v), (p = v), (f = _);
                }
                if (g.done) return o(e, f), c;
                if (null === f) {
                    for (; !g.done; d++, g = u.next()) null !== (g = h(e, g.value, s)) && ((i = l(g, i, d)), null === p ? (c = g) : (p.sibling = g), (p = g));
                    return c;
                }
                for (f = a(e, f); !g.done; d++, g = u.next()) null !== (g = m(f, e, d, g.value, s)) && (t && null !== g.alternate && f.delete(null === g.key ? d : g.key), (i = l(g, i, d)), null === p ? (c = g) : (p.sibling = g), (p = g));
                return (
                    t &&
                        f.forEach(function (t) {
                            return r(e, t);
                        }),
                    c
                );
            }
            return function (e, t, a, l) {
                var s = "object" == typeof a && null !== a;
                if (s)
                    switch (a.$$typeof) {
                        case Ho:
                            e: {
                                var c = a.key;
                                for (s = t; null !== s; ) {
                                    if (s.key === c) {
                                        if (s.type === a.type) {
                                            o(e, s.sibling), ((t = i(s, l)).ref = ne(s, a)), (t.pendingProps = a.props), (t.return = e), (e = t);
                                            break e;
                                        }
                                        o(e, s);
                                        break;
                                    }
                                    r(e, s), (s = s.sibling);
                                }
                                ((l = Po(a, e.internalContextTag, l)).ref = ne(t, a)), (l.return = e), (e = l);
                            }
                            return u(e);
                        case yo:
                            e: {
                                for (s = a.key; null !== t; ) {
                                    if (t.key === s) {
                                        if (t.tag === Ao) {
                                            o(e, t.sibling), ((t = i(t, l)).pendingProps = a), (t.return = e), (e = t);
                                            break e;
                                        }
                                        o(e, t);
                                        break;
                                    }
                                    r(e, t), (t = t.sibling);
                                }
                                ((a = Oo(a, e.internalContextTag, l)).return = e), (e = a);
                            }
                            return u(e);
                        case Eo:
                            e: {
                                if (null !== t) {
                                    if (t.tag === Uo) {
                                        o(e, t.sibling), ((t = i(t, l)).type = a.value), (t.return = e), (e = t);
                                        break e;
                                    }
                                    o(e, t);
                                }
                                ((t = Mo(a, e.internalContextTag, l)).type = a.value), (t.return = e), (e = t);
                            }
                            return u(e);
                        case Co:
                            e: {
                                for (s = a.key; null !== t; ) {
                                    if (t.key === s) {
                                        if (t.tag === Bo && t.stateNode.containerInfo === a.containerInfo && t.stateNode.implementation === a.implementation) {
                                            o(e, t.sibling), ((t = i(t, l)).pendingProps = a.children || []), (t.return = e), (e = t);
                                            break e;
                                        }
                                        o(e, t);
                                        break;
                                    }
                                    r(e, t), (t = t.sibling);
                                }
                                ((a = Do(a, e.internalContextTag, l)).return = e), (e = a);
                            }
                            return u(e);
                    }
                if ("string" == typeof a || "number" == typeof a)
                    return (a = "" + a), null !== t && t.tag === jo ? (o(e, t.sibling), (t = i(t, l)), (t.pendingProps = a), (t.return = e), (e = t)) : (o(e, t), (a = wo(a, e.internalContextTag, l)), (a.return = e), (e = a)), u(e);
                if (To(a)) return g(e, t, a, l);
                if (re(a)) return v(e, t, a, l);
                if ((s && oe(e, a), void 0 === a))
                    switch (e.tag) {
                        case Ro:
                        case So:
                            n("152", (a = e.type).displayName || a.name || "Component");
                    }
                return o(e, t);
            };
        }
        function ie(e, t, r, o) {
            function a(e, t) {
                (t.updater = i), (e.stateNode = t), Yt.set(t, e);
            }
            var i = {
                isMounted: ta,
                enqueueSetState: function (r, n, o) {
                    r = Yt.get(r);
                    var a = t(r, !1);
                    Xo(r, n, void 0 === o ? null : o, a), e(r, a);
                },
                enqueueReplaceState: function (r, n, o) {
                    r = Yt.get(r);
                    var a = t(r, !1);
                    Zo(r, n, void 0 === o ? null : o, a), e(r, a);
                },
                enqueueForceUpdate: function (r, n) {
                    r = Yt.get(r);
                    var o = t(r, !1);
                    Qo(r, void 0 === n ? null : n, o), e(r, o);
                },
            };
            return {
                adoptClassInstance: a,
                constructClassInstance: function (e, t) {
                    var r = e.type,
                        n = Yo(e),
                        o = $o(e),
                        i = o ? Vo(e, n) : yt;
                    return (t = new r(t, i)), a(e, t), o && Go(e, n, i), t;
                },
                mountClassInstance: function (e, t) {
                    var r = e.alternate,
                        o = e.stateNode,
                        a = o.state || null,
                        l = e.pendingProps;
                    l || n("158");
                    var u = Yo(e);
                    (o.props = l),
                        (o.state = a),
                        (o.refs = yt),
                        (o.context = Vo(e, u)),
                        On.enableAsyncSubtreeAPI && null != e.type && null != e.type.prototype && !0 === e.type.prototype.unstable_isAsyncReactComponent && (e.internalContextTag |= qo),
                        "function" == typeof o.componentWillMount && ((u = o.state), o.componentWillMount(), u !== o.state && i.enqueueReplaceState(o, o.state, null), null !== (u = e.updateQueue) && (o.state = Jo(r, e, u, o, a, l, t))),
                        "function" == typeof o.componentDidMount && (e.effectTag |= zo);
                },
                updateClassInstance: function (e, t, a) {
                    var l = t.stateNode;
                    (l.props = t.memoizedProps), (l.state = t.memoizedState);
                    var u = t.memoizedProps,
                        s = t.pendingProps;
                    s || (null == (s = u) && n("159"));
                    var c = l.context,
                        p = Yo(t);
                    if (
                        ((p = Vo(t, p)),
                        "function" != typeof l.componentWillReceiveProps || (u === s && c === p) || ((c = l.state), l.componentWillReceiveProps(s, p), l.state !== c && i.enqueueReplaceState(l, l.state, null)),
                        (c = t.memoizedState),
                        (a = null !== t.updateQueue ? Jo(e, t, t.updateQueue, l, c, s, a) : c),
                        !(u !== s || c !== a || ea() || (null !== t.updateQueue && t.updateQueue.hasForceUpdate)))
                    )
                        return "function" != typeof l.componentDidUpdate || (u === e.memoizedProps && c === e.memoizedState) || (t.effectTag |= zo), !1;
                    var f = s;
                    if (null === u || (null !== t.updateQueue && t.updateQueue.hasForceUpdate)) f = !0;
                    else {
                        var d = t.stateNode,
                            _ = t.type;
                        f = "function" == typeof d.shouldComponentUpdate ? d.shouldComponentUpdate(f, a, p) : !_.prototype || !_.prototype.isPureReactComponent || !Et(u, f) || !Et(c, a);
                    }
                    return (
                        f
                            ? ("function" == typeof l.componentWillUpdate && l.componentWillUpdate(s, a, p), "function" == typeof l.componentDidUpdate && (t.effectTag |= zo))
                            : ("function" != typeof l.componentDidUpdate || (u === e.memoizedProps && c === e.memoizedState) || (t.effectTag |= zo), r(t, s), o(t, a)),
                        (l.props = s),
                        (l.state = a),
                        (l.context = p),
                        f
                    );
                },
            };
        }
        function le(e, t, r, o, a) {
            function i(e, t, r) {
                l(e, t, r, t.pendingWorkPriority);
            }
            function l(e, t, r, n) {
                t.child = null === e ? ra(t, t.child, r, n) : e.child === t.child ? na(t, t.child, r, n) : oa(t, t.child, r, n);
            }
            function u(e, t) {
                var r = t.ref;
                null === r || (e && e.ref === r) || (t.effectTag |= Ta);
            }
            function s(e, t, r, n) {
                if ((u(e, t), !r)) return n && fa(t, !1), p(e, t);
                (r = t.stateNode), (Sa.current = t);
                var o = r.render();
                return (t.effectTag |= wa), i(e, t, o), (t.memoizedState = r.state), (t.memoizedProps = r.props), n && fa(t, !0), t.child;
            }
            function c(e) {
                var t = e.stateNode;
                t.pendingContext ? pa(e, t.pendingContext, t.pendingContext !== t.context) : t.context && pa(e, t.context, !1), m(e, t.containerInfo);
            }
            function p(e, t) {
                return aa(e, t), t.child;
            }
            function f(e, t) {
                switch (t.tag) {
                    case ba:
                        c(t);
                        break;
                    case ha:
                        ca(t);
                        break;
                    case va:
                        m(t, t.stateNode.containerInfo);
                }
                return null;
            }
            var d = e.shouldSetTextContent,
                _ = e.useSyncScheduling,
                h = e.shouldDeprioritizeSubtree,
                b = t.pushHostContext,
                m = t.pushHostContainer,
                g = r.enterHydrationState,
                v = r.resetHydrationState,
                y = r.tryToClaimNextHydratableInstance,
                E = (e = ie(
                    o,
                    a,
                    function (e, t) {
                        e.memoizedProps = t;
                    },
                    function (e, t) {
                        e.memoizedState = t;
                    }
                )).adoptClassInstance,
                C = e.constructClassInstance,
                k = e.mountClassInstance,
                P = e.updateClassInstance;
            return {
                beginWork: function (e, t, r) {
                    if (t.pendingWorkPriority === Pa || t.pendingWorkPriority > r) return f(0, t);
                    switch (t.tag) {
                        case da:
                            null !== e && n("155");
                            var o = t.type,
                                a = t.pendingProps,
                                l = ua(t);
                            return (
                                (l = la(t, l)),
                                (o = o(a, l)),
                                (t.effectTag |= wa),
                                "object" == typeof o && null !== o && "function" == typeof o.render ? ((t.tag = ha), (a = ca(t)), E(t, o), k(t, r), (t = s(e, t, !0, a))) : ((t.tag = _a), i(e, t, o), (t.memoizedProps = a), (t = t.child)),
                                t
                            );
                        case _a:
                            e: {
                                if (((a = t.type), (r = t.pendingProps), (o = t.memoizedProps), sa())) null === r && (r = o);
                                else if (null === r || o === r) {
                                    t = p(e, t);
                                    break e;
                                }
                                (o = ua(t)), (a = a(r, (o = la(t, o)))), (t.effectTag |= wa), i(e, t, a), (t.memoizedProps = r), (t = t.child);
                            }
                            return t;
                        case ha:
                            return (a = ca(t)), (o = void 0), null === e ? (t.stateNode ? n("153") : (C(t, t.pendingProps), k(t, r), (o = !0))) : (o = P(e, t, r)), s(e, t, o, a);
                        case ba:
                            return (
                                c(t),
                                null !== (o = t.updateQueue)
                                    ? ((a = t.memoizedState),
                                      (o = ia(e, t, o, null, a, null, r)),
                                      a === o
                                          ? (v(), (t = p(e, t)))
                                          : ((a = o.element), (null !== e && null !== e.child) || !g(t) ? (v(), i(e, t, a)) : ((t.effectTag |= Oa), (t.child = ra(t, t.child, a, r))), (t.memoizedState = o), (t = t.child)))
                                    : (v(), (t = p(e, t))),
                                t
                            );
                        case ma:
                            b(t), null === e && y(t), (a = t.type);
                            var x = t.memoizedProps;
                            return (
                                null === (o = t.pendingProps) && null === (o = x) && n("154"),
                                (l = null !== e ? e.memoizedProps : null),
                                sa() || (null !== o && x !== o)
                                    ? ((x = o.children),
                                      d(a, o) ? (x = null) : l && d(a, l) && (t.effectTag |= Ma),
                                      u(e, t),
                                      r !== xa && !_ && h(a, o) ? ((t.pendingWorkPriority = xa), (t = null)) : (i(e, t, x), (t.memoizedProps = o), (t = t.child)))
                                    : (t = p(e, t)),
                                t
                            );
                        case ga:
                            return null === e && y(t), null === (e = t.pendingProps) && (e = t.memoizedProps), (t.memoizedProps = e), null;
                        case Ea:
                            t.tag = ya;
                        case ya:
                            return (
                                (r = t.pendingProps),
                                sa() ? null === r && null === (r = e && e.memoizedProps) && n("154") : (null !== r && t.memoizedProps !== r) || (r = t.memoizedProps),
                                (a = r.children),
                                (o = t.pendingWorkPriority),
                                (t.stateNode = null === e ? ra(t, t.stateNode, a, o) : e.child === t.child ? na(t, t.stateNode, a, o) : oa(t, t.stateNode, a, o)),
                                (t.memoizedProps = r),
                                t.stateNode
                            );
                        case Ca:
                            return null;
                        case va:
                            e: {
                                if ((m(t, t.stateNode.containerInfo), (r = t.pendingWorkPriority), (a = t.pendingProps), sa())) null === a && null == (a = e && e.memoizedProps) && n("154");
                                else if (null === a || t.memoizedProps === a) {
                                    t = p(e, t);
                                    break e;
                                }
                                null === e ? (t.child = oa(t, t.child, a, r)) : i(e, t, a), (t.memoizedProps = a), (t = t.child);
                            }
                            return t;
                        case ka:
                            e: {
                                if (((r = t.pendingProps), sa())) null === r && (r = t.memoizedProps);
                                else if (null === r || t.memoizedProps === r) {
                                    t = p(e, t);
                                    break e;
                                }
                                i(e, t, r), (t.memoizedProps = r), (t = t.child);
                            }
                            return t;
                        default:
                            n("156");
                    }
                },
                beginFailedWork: function (e, t, r) {
                    switch (t.tag) {
                        case ha:
                            ca(t);
                            break;
                        case ba:
                            c(t);
                            break;
                        default:
                            n("157");
                    }
                    return (
                        (t.effectTag |= Da),
                        null === e ? (t.child = null) : t.child !== e.child && (t.child = e.child),
                        t.pendingWorkPriority === Pa || t.pendingWorkPriority > r
                            ? f(0, t)
                            : ((t.firstEffect = null), (t.lastEffect = null), l(e, t, null, r), t.tag === ha && ((e = t.stateNode), (t.memoizedProps = e.props), (t.memoizedState = e.state)), t.child)
                    );
                },
            };
        }
        function ue(e, t, r) {
            var o = e.createInstance,
                a = e.createTextInstance,
                i = e.appendInitialChild,
                l = e.finalizeInitialChildren,
                u = e.prepareUpdate,
                s = t.getRootHostContainer,
                c = t.popHostContext,
                p = t.getHostContext,
                f = t.popHostContainer,
                d = r.prepareToHydrateHostInstance,
                _ = r.prepareToHydrateHostTextInstance,
                h = r.popHydrationState;
            return {
                completeWork: function (e, t, r) {
                    var b = t.pendingProps;
                    switch ((null === b ? (b = t.memoizedProps) : (t.pendingWorkPriority === $a && r !== $a) || (t.pendingProps = null), t.tag)) {
                        case Ua:
                            return null;
                        case Ia:
                            return ja(t), null;
                        case La:
                            return f(t), Ba(t), (b = t.stateNode).pendingContext && ((b.context = b.pendingContext), (b.pendingContext = null)), (null !== e && null !== e.child) || (h(t), (t.effectTag &= ~Ga)), null;
                        case Fa:
                            c(t), (r = s());
                            var m = t.type;
                            if (null !== e && null != t.stateNode) {
                                var g = e.memoizedProps,
                                    v = t.stateNode,
                                    y = p();
                                (b = u(v, m, g, b, r, y)), (t.updateQueue = b) && (t.effectTag |= Ya), e.ref !== t.ref && (t.effectTag |= Va);
                            } else {
                                if (!b) return null === t.stateNode && n("166"), null;
                                if (((e = p()), h(t))) d(t, r, e) && (t.effectTag |= Ya);
                                else {
                                    e = o(m, b, r, e, t);
                                    e: for (g = t.child; null !== g; ) {
                                        if (g.tag === Fa || g.tag === Na) i(e, g.stateNode);
                                        else if (g.tag !== Wa && null !== g.child) {
                                            g = g.child;
                                            continue;
                                        }
                                        if (g === t) break e;
                                        for (; null === g.sibling; ) {
                                            if (null === g.return || g.return === t) break e;
                                            g = g.return;
                                        }
                                        g = g.sibling;
                                    }
                                    l(e, m, b, r) && (t.effectTag |= Ya), (t.stateNode = e);
                                }
                                null !== t.ref && (t.effectTag |= Va);
                            }
                            return null;
                        case Na:
                            if (e && null != t.stateNode) e.memoizedProps !== b && (t.effectTag |= Ya);
                            else {
                                if ("string" != typeof b) return null === t.stateNode && n("166"), null;
                                (e = s()), (r = p()), h(t) ? _(t) && (t.effectTag |= Ya) : (t.stateNode = a(b, e, r, t));
                            }
                            return null;
                        case Ha:
                            (b = t.memoizedProps) || n("165"), (t.tag = Ka), (r = []);
                            e: for ((m = t.stateNode) && (m.return = t); null !== m; ) {
                                if (m.tag === Fa || m.tag === Na || m.tag === Wa) n("164");
                                else if (m.tag === za) r.push(m.type);
                                else if (null !== m.child) {
                                    (m.child.return = m), (m = m.child);
                                    continue;
                                }
                                for (; null === m.sibling; ) {
                                    if (null === m.return || m.return === t) break e;
                                    m = m.return;
                                }
                                (m.sibling.return = m.return), (m = m.sibling);
                            }
                            return (m = b.handler), (b = m(b.props, r)), (t.child = Ra(t, null !== e ? e.child : null, b, t.pendingWorkPriority)), t.child;
                        case Ka:
                            return (t.tag = Ha), null;
                        case za:
                        case qa:
                            return null;
                        case Wa:
                            return (t.effectTag |= Ya), f(t), null;
                        case Aa:
                            n("167");
                        default:
                            n("156");
                    }
                },
            };
        }
        function se(e) {
            return function (t) {
                try {
                    return e(t);
                } catch (e) {}
            };
        }
        function ce(e, t) {
            function r(e) {
                var r = e.ref;
                if (null !== r)
                    try {
                        r(null);
                    } catch (r) {
                        t(e, r);
                    }
            }
            function o(e) {
                return e.tag === ti || e.tag === ei || e.tag === ni;
            }
            function a(e) {
                for (var t = e; ; )
                    if ((l(t), null !== t.child && t.tag !== ni)) (t.child.return = t), (t = t.child);
                    else {
                        if (t === e) break;
                        for (; null === t.sibling; ) {
                            if (null === t.return || t.return === e) return;
                            t = t.return;
                        }
                        (t.sibling.return = t.return), (t = t.sibling);
                    }
            }
            function i(e) {
                for (var t = e, r = !1, o = void 0, i = void 0; ; ) {
                    if (!r) {
                        r = t.return;
                        e: for (;;) {
                            switch ((null === r && n("160"), r.tag)) {
                                case ti:
                                    (o = r.stateNode), (i = !1);
                                    break e;
                                case ei:
                                case ni:
                                    (o = r.stateNode.containerInfo), (i = !0);
                                    break e;
                            }
                            r = r.return;
                        }
                        r = !0;
                    }
                    if (t.tag === ti || t.tag === ri) a(t), i ? m(o, t.stateNode) : b(o, t.stateNode);
                    else if ((t.tag === ni ? (o = t.stateNode.containerInfo) : l(t), null !== t.child)) {
                        (t.child.return = t), (t = t.child);
                        continue;
                    }
                    if (t === e) break;
                    for (; null === t.sibling; ) {
                        if (null === t.return || t.return === e) return;
                        (t = t.return).tag === ni && (r = !1);
                    }
                    (t.sibling.return = t.return), (t = t.sibling);
                }
            }
            function l(e) {
                switch (("function" == typeof ii && ii(e), e.tag)) {
                    case Ja:
                        r(e);
                        var n = e.stateNode;
                        if ("function" == typeof n.componentWillUnmount)
                            try {
                                (n.props = e.memoizedProps), (n.state = e.memoizedState), n.componentWillUnmount();
                            } catch (r) {
                                t(e, r);
                            }
                        break;
                    case ti:
                        r(e);
                        break;
                    case oi:
                        a(e.stateNode);
                        break;
                    case ni:
                        i(e);
                }
            }
            var u = e.commitMount,
                s = e.commitUpdate,
                c = e.resetTextContent,
                p = e.commitTextUpdate,
                f = e.appendChild,
                d = e.appendChildToContainer,
                _ = e.insertBefore,
                h = e.insertInContainerBefore,
                b = e.removeChild,
                m = e.removeChildFromContainer,
                g = e.getPublicInstance;
            return {
                commitPlacement: function (e) {
                    e: {
                        for (var t = e.return; null !== t; ) {
                            if (o(t)) {
                                var r = t;
                                break e;
                            }
                            t = t.return;
                        }
                        n("160"), (r = void 0);
                    }
                    var a = (t = void 0);
                    switch (r.tag) {
                        case ti:
                            (t = r.stateNode), (a = !1);
                            break;
                        case ei:
                        case ni:
                            (t = r.stateNode.containerInfo), (a = !0);
                            break;
                        default:
                            n("161");
                    }
                    r.effectTag & ci && (c(t), (r.effectTag &= ~ci));
                    e: t: for (r = e; ; ) {
                        for (; null === r.sibling; ) {
                            if (null === r.return || o(r.return)) {
                                r = null;
                                break e;
                            }
                            r = r.return;
                        }
                        for (r.sibling.return = r.return, r = r.sibling; r.tag !== ti && r.tag !== ri; ) {
                            if (r.effectTag & li) continue t;
                            if (null === r.child || r.tag === ni) continue t;
                            (r.child.return = r), (r = r.child);
                        }
                        if (!(r.effectTag & li)) {
                            r = r.stateNode;
                            break e;
                        }
                    }
                    for (var i = e; ; ) {
                        if (i.tag === ti || i.tag === ri) r ? (a ? h(t, i.stateNode, r) : _(t, i.stateNode, r)) : a ? d(t, i.stateNode) : f(t, i.stateNode);
                        else if (i.tag !== ni && null !== i.child) {
                            (i.child.return = i), (i = i.child);
                            continue;
                        }
                        if (i === e) break;
                        for (; null === i.sibling; ) {
                            if (null === i.return || i.return === e) return;
                            i = i.return;
                        }
                        (i.sibling.return = i.return), (i = i.sibling);
                    }
                },
                commitDeletion: function (e) {
                    i(e), (e.return = null), (e.child = null), e.alternate && ((e.alternate.child = null), (e.alternate.return = null));
                },
                commitWork: function (e, t) {
                    switch (t.tag) {
                        case Ja:
                            break;
                        case ti:
                            var r = t.stateNode;
                            if (null != r) {
                                var o = t.memoizedProps;
                                e = null !== e ? e.memoizedProps : o;
                                var a = t.type,
                                    i = t.updateQueue;
                                (t.updateQueue = null), null !== i && s(r, i, a, e, o, t);
                            }
                            break;
                        case ri:
                            null === t.stateNode && n("162"), (r = t.memoizedProps), p(t.stateNode, null !== e ? e.memoizedProps : r, r);
                            break;
                        case ei:
                        case ni:
                            break;
                        default:
                            n("163");
                    }
                },
                commitLifeCycles: function (e, t) {
                    switch (t.tag) {
                        case Ja:
                            var r = t.stateNode;
                            if (t.effectTag & ui)
                                if (null === e) (r.props = t.memoizedProps), (r.state = t.memoizedState), r.componentDidMount();
                                else {
                                    var o = e.memoizedProps;
                                    (e = e.memoizedState), (r.props = t.memoizedProps), (r.state = t.memoizedState), r.componentDidUpdate(o, e);
                                }
                            t.effectTag & si && null !== t.updateQueue && ai(t, t.updateQueue, r);
                            break;
                        case ei:
                            null !== (e = t.updateQueue) && ai(t, e, t.child && t.child.stateNode);
                            break;
                        case ti:
                            (r = t.stateNode), null === e && t.effectTag & ui && u(r, t.type, t.memoizedProps, t);
                            break;
                        case ri:
                        case ni:
                            break;
                        default:
                            n("163");
                    }
                },
                commitAttachRef: function (e) {
                    var t = e.ref;
                    if (null !== t) {
                        var r = e.stateNode;
                        switch (e.tag) {
                            case ti:
                                t(g(r));
                                break;
                            default:
                                t(r);
                        }
                    }
                },
                commitDetachRef: function (e) {
                    null !== (e = e.ref) && e(null);
                },
            };
        }
        function pe(e) {
            function t(e) {
                return e === _i && n("174"), e;
            }
            var r = e.getChildHostContext,
                o = e.getRootHostContext,
                a = pi(_i),
                i = pi(_i),
                l = pi(_i);
            return {
                getHostContext: function () {
                    return t(a.current);
                },
                getRootHostContainer: function () {
                    return t(l.current);
                },
                popHostContainer: function (e) {
                    fi(a, e), fi(i, e), fi(l, e);
                },
                popHostContext: function (e) {
                    i.current === e && (fi(a, e), fi(i, e));
                },
                pushHostContainer: function (e, t) {
                    di(l, t, e), (t = o(t)), di(i, e, e), di(a, t, e);
                },
                pushHostContext: function (e) {
                    var n = t(l.current),
                        o = t(a.current);
                    o !== (n = r(o, e.type, n)) && (di(i, e, e), di(a, n, e));
                },
                resetHostContainer: function () {
                    (a.current = _i), (l.current = _i);
                },
            };
        }
        function fe(e) {
            function t(e, t) {
                var r = yi();
                (r.stateNode = t), (r.return = e), (r.effectTag = gi), null !== e.lastEffect ? ((e.lastEffect.nextEffect = r), (e.lastEffect = r)) : (e.firstEffect = e.lastEffect = r);
            }
            function r(e, t) {
                switch (e.tag) {
                    case hi:
                        return i(t, e.type, e.pendingProps);
                    case bi:
                        return l(t, e.pendingProps);
                    default:
                        return !1;
                }
            }
            function o(e) {
                for (e = e.return; null !== e && e.tag !== hi && e.tag !== mi; ) e = e.return;
                _ = e;
            }
            var a = e.shouldSetTextContent,
                i = e.canHydrateInstance,
                l = e.canHydrateTextInstance,
                u = e.getNextHydratableSibling,
                s = e.getFirstHydratableChild,
                c = e.hydrateInstance,
                p = e.hydrateTextInstance,
                f = e.didNotHydrateInstance,
                d = e.didNotFindHydratableInstance;
            if (((e = e.didNotFindHydratableTextInstance), !(i && l && u && s && c && p && f && d && e)))
                return {
                    enterHydrationState: function () {
                        return !1;
                    },
                    resetHydrationState: function () {},
                    tryToClaimNextHydratableInstance: function () {},
                    prepareToHydrateHostInstance: function () {
                        n("175");
                    },
                    prepareToHydrateHostTextInstance: function () {
                        n("176");
                    },
                    popHydrationState: function () {
                        return !1;
                    },
                };
            var _ = null,
                h = null,
                b = !1;
            return {
                enterHydrationState: function (e) {
                    return (h = s(e.stateNode.containerInfo)), (_ = e), (b = !0);
                },
                resetHydrationState: function () {
                    (h = _ = null), (b = !1);
                },
                tryToClaimNextHydratableInstance: function (e) {
                    if (b) {
                        var n = h;
                        if (n) {
                            if (!r(e, n)) {
                                if (!(n = u(n)) || !r(e, n)) return (e.effectTag |= vi), (b = !1), void (_ = e);
                                t(_, h);
                            }
                            (e.stateNode = n), (_ = e), (h = s(n));
                        } else (e.effectTag |= vi), (b = !1), (_ = e);
                    }
                },
                prepareToHydrateHostInstance: function (e, t, r) {
                    return (t = c(e.stateNode, e.type, e.memoizedProps, t, r, e)), (e.updateQueue = t), null !== t;
                },
                prepareToHydrateHostTextInstance: function (e) {
                    return p(e.stateNode, e.memoizedProps, e);
                },
                popHydrationState: function (e) {
                    if (e !== _) return !1;
                    if (!b) return o(e), (b = !0), !1;
                    var r = e.type;
                    if (e.tag !== hi || ("head" !== r && "body" !== r && !a(r, e.memoizedProps))) for (r = h; r; ) t(e, r), (r = u(r));
                    return o(e), (h = _ ? u(e.stateNode) : null), !0;
                },
            };
        }
        function de(e) {
            function t() {
                for (; null !== G && G.current.pendingWorkPriority === Oi; ) {
                    G.isScheduled = !1;
                    var e = G.nextScheduledRoot;
                    if (((G.nextScheduledRoot = null), G === V)) return (V = G = null), (K = Oi), null;
                    G = e;
                }
                e = G;
                for (var t = null, r = Oi; null !== e; ) e.current.pendingWorkPriority !== Oi && (r === Oi || r > e.current.pendingWorkPriority) && ((r = e.current.pendingWorkPriority), (t = e)), (e = e.nextScheduledRoot);
                null !== t ? ((K = r), Ci(), Yi(), C(), (H = Pi(t.current, r)), t !== oe && ((ne = 0), (oe = t))) : ((K = Oi), (oe = H = null));
            }
            function r(r) {
                (ee = !0), (q = null);
                var o = r.stateNode;
                if ((o.current === r && n("177"), (K !== Mi && K !== Di) || ne++, (ki.current = null), r.effectTag > Bi))
                    if (null !== r.lastEffect) {
                        r.lastEffect.nextEffect = r;
                        var a = r.firstEffect;
                    } else a = r;
                else a = r.firstEffect;
                for (A(), z = a; null !== z; ) {
                    var i = !1,
                        l = void 0;
                    try {
                        for (; null !== z; ) {
                            var u = z.effectTag;
                            if ((u & Fi && e.resetTextContent(z.stateNode), u & Hi)) {
                                var s = z.alternate;
                                null !== s && R(s);
                            }
                            switch (u & ~(Ni | Wi | Fi | Hi | Bi)) {
                                case Ai:
                                    O(z), (z.effectTag &= ~Ai);
                                    break;
                                case Ii:
                                    O(z), (z.effectTag &= ~Ai), D(z.alternate, z);
                                    break;
                                case Ui:
                                    D(z.alternate, z);
                                    break;
                                case Li:
                                    (te = !0), M(z), (te = !1);
                            }
                            z = z.nextEffect;
                        }
                    } catch (e) {
                        (i = !0), (l = e);
                    }
                    i && (null === z && n("178"), p(z, l), null !== z && (z = z.nextEffect));
                }
                for (U(), o.current = r, z = a; null !== z; ) {
                    (o = !1), (a = void 0);
                    try {
                        for (; null !== z; ) {
                            var c = z.effectTag;
                            if ((c & (Ui | Ni) && T(z.alternate, z), c & Hi && S(z), c & Wi))
                                switch (((i = z), (l = void 0), null !== $ && ((l = $.get(i)), $.delete(i), null == l && null !== i.alternate && ((i = i.alternate), (l = $.get(i)), $.delete(i))), null == l && n("184"), i.tag)) {
                                    case Gi:
                                        i.stateNode.componentDidCatch(l.error, { componentStack: l.componentStack });
                                        break;
                                    case Ki:
                                        null === Q && (Q = l.error);
                                        break;
                                    default:
                                        n("157");
                                }
                            var f = z.nextEffect;
                            (z.nextEffect = null), (z = f);
                        }
                    } catch (e) {
                        (o = !0), (a = e);
                    }
                    o && (null === z && n("178"), p(z, a), null !== z && (z = z.nextEffect));
                }
                (ee = !1), "function" == typeof wi && wi(r.stateNode), Z && (Z.forEach(m), (Z = null)), t();
            }
            function o(e) {
                for (;;) {
                    var t = w(e.alternate, e, K),
                        r = e.return,
                        n = e.sibling,
                        o = e;
                    if (!(o.pendingWorkPriority !== Oi && o.pendingWorkPriority > K)) {
                        for (var a = Vi(o), i = o.child; null !== i; ) (a = xi(a, i.pendingWorkPriority)), (i = i.sibling);
                        o.pendingWorkPriority = a;
                    }
                    if (null !== t) return t;
                    if (
                        (null !== r &&
                            (null === r.firstEffect && (r.firstEffect = e.firstEffect),
                            null !== e.lastEffect && (null !== r.lastEffect && (r.lastEffect.nextEffect = e.firstEffect), (r.lastEffect = e.lastEffect)),
                            e.effectTag > Bi && (null !== r.lastEffect ? (r.lastEffect.nextEffect = e) : (r.firstEffect = e), (r.lastEffect = e))),
                        null !== n)
                    )
                        return n;
                    if (null === r) {
                        q = e;
                        break;
                    }
                    e = r;
                }
                return null;
            }
            function a(e) {
                var t = P(e.alternate, e, K);
                return null === t && (t = o(e)), (ki.current = null), t;
            }
            function i(e) {
                var t = x(e.alternate, e, K);
                return null === t && (t = o(e)), (ki.current = null), t;
            }
            function l(e) {
                c(Ri, e);
            }
            function u() {
                if (null !== $ && 0 < $.size && K === Di)
                    for (; null !== H; ) {
                        var e = H;
                        if (null === (H = null !== $ && ($.has(e) || (null !== e.alternate && $.has(e.alternate))) ? i(H) : a(H)) && (null === q && n("179"), (I = Di), r(q), (I = K), null === $ || 0 === $.size || K !== Di)) break;
                    }
            }
            function s(e, o) {
                if ((null !== q ? ((I = Di), r(q), u()) : null === H && t(), !(K === Oi || K > e))) {
                    I = K;
                    e: for (;;) {
                        if (K <= Di) for (; null !== H && !(null === (H = a(H)) && (null === q && n("179"), (I = Di), r(q), (I = K), u(), K === Oi || K > e || K > Di)); );
                        else if (null !== o)
                            for (; null !== H && !F; )
                                if (1 < o.timeRemaining()) {
                                    if (null === (H = a(H)))
                                        if ((null === q && n("179"), 1 < o.timeRemaining())) {
                                            if (((I = Di), r(q), (I = K), u(), K === Oi || K > e || K < Ti)) break;
                                        } else F = !0;
                                } else F = !0;
                        switch (K) {
                            case Mi:
                            case Di:
                                if (K <= e) continue e;
                                break e;
                            case Ti:
                            case Si:
                            case Ri:
                                if (null === o) break e;
                                if (!F && K <= e) continue e;
                                break e;
                            case Oi:
                                break e;
                            default:
                                n("181");
                        }
                    }
                }
            }
            function c(e, t) {
                L && n("182"), (L = !0);
                var r = I,
                    o = !1,
                    a = null;
                try {
                    s(e, t);
                } catch (e) {
                    (o = !0), (a = e);
                }
                for (; o; ) {
                    if (J) {
                        Q = a;
                        break;
                    }
                    var u = H;
                    if (null === u) J = !0;
                    else {
                        var c = p(u, a);
                        if ((null === c && n("183"), !J)) {
                            try {
                                (o = c), (a = e), (c = t);
                                for (var f = o; null !== u; ) {
                                    switch (u.tag) {
                                        case Gi:
                                            Ei(u);
                                            break;
                                        case zi:
                                            E(u);
                                            break;
                                        case Ki:
                                            y(u);
                                            break;
                                        case qi:
                                            y(u);
                                    }
                                    if (u === f || u.alternate === f) break;
                                    u = u.return;
                                }
                                (H = i(o)), s(a, c);
                            } catch (e) {
                                (o = !0), (a = e);
                                continue;
                            }
                            break;
                        }
                    }
                }
                if (((I = r), null !== t && (Y = !1), K > Di && !Y && (j(l), (Y = !0)), (e = Q), (J = F = L = !1), (oe = X = $ = Q = null), (ne = 0), null !== e)) throw e;
            }
            function p(e, t) {
                var r = (ki.current = null),
                    n = !1,
                    o = !1,
                    a = null;
                if (e.tag === Ki) (r = e), d(e) && (J = !0);
                else
                    for (var i = e.return; null !== i && null === r; ) {
                        if ((i.tag === Gi ? "function" == typeof i.stateNode.componentDidCatch && ((n = !0), (a = f(i)), (r = i), (o = !0)) : i.tag === Ki && (r = i), d(i))) {
                            if (te || (null !== Z && (Z.has(i) || (null !== i.alternate && Z.has(i.alternate))))) return null;
                            (r = null), (o = !1);
                        }
                        i = i.return;
                    }
                if (null !== r) {
                    null === X && (X = new Set()), X.add(r);
                    var l = "";
                    i = e;
                    do {
                        e: switch (i.tag) {
                            case fo:
                            case _o:
                            case ho:
                            case bo:
                                var u = i._debugOwner,
                                    s = i._debugSource,
                                    c = f(i),
                                    p = null;
                                u && (p = f(u)), (u = s), (c = "\n    in " + (c || "Unknown") + (u ? " (at " + u.fileName.replace(/^.*[\\\/]/, "") + ":" + u.lineNumber + ")" : p ? " (created by " + p + ")" : ""));
                                break e;
                            default:
                                c = "";
                        }
                        (l += c), (i = i.return);
                    } while (i);
                    (i = l), (e = f(e)), null === $ && ($ = new Map()), (t = { componentName: e, componentStack: i, error: t, errorBoundary: n ? r.stateNode : null, errorBoundaryFound: n, errorBoundaryName: a, willRetry: o }), $.set(r, t);
                    try {
                        console.error(t.error);
                    } catch (e) {
                        console.error(e);
                    }
                    return ee ? (null === Z && (Z = new Set()), Z.add(r)) : m(r), r;
                }
                return null === Q && (Q = t), null;
            }
            function d(e) {
                return null !== X && (X.has(e) || (null !== e.alternate && X.has(e.alternate)));
            }
            function _(e, t) {
                return h(e, t, !1);
            }
            function h(e, t) {
                ne > re && ((J = !0), n("185")), !L && t <= K && (H = null);
                for (var r = !0; null !== e && r; ) {
                    if (
                        ((r = !1),
                        (e.pendingWorkPriority === Oi || e.pendingWorkPriority > t) && ((r = !0), (e.pendingWorkPriority = t)),
                        null !== e.alternate && (e.alternate.pendingWorkPriority === Oi || e.alternate.pendingWorkPriority > t) && ((r = !0), (e.alternate.pendingWorkPriority = t)),
                        null === e.return)
                    ) {
                        if (e.tag !== Ki) break;
                        var o = e.stateNode;
                        if ((t === Oi || o.isScheduled || ((o.isScheduled = !0), V ? (V.nextScheduledRoot = o) : (G = o), (V = o)), !L))
                            switch (t) {
                                case Mi:
                                    W ? c(Mi, null) : c(Di, null);
                                    break;
                                case Di:
                                    N || n("186");
                                    break;
                                default:
                                    Y || (j(l), (Y = !0));
                            }
                    }
                    e = e.return;
                }
            }
            function b(e, t) {
                var r = I;
                return r === Oi && (r = !B || e.internalContextTag & ji || t ? Si : Mi), r === Mi && (L || N) ? Di : r;
            }
            function m(e) {
                h(e, Di, !0);
            }
            var g = pe(e),
                v = fe(e),
                y = g.popHostContainer,
                E = g.popHostContext,
                C = g.resetHostContainer,
                k = le(e, g, v, _, b),
                P = k.beginWork,
                x = k.beginFailedWork,
                w = ue(e, g, v).completeWork,
                O = (g = ce(e, p)).commitPlacement,
                M = g.commitDeletion,
                D = g.commitWork,
                T = g.commitLifeCycles,
                S = g.commitAttachRef,
                R = g.commitDetachRef,
                j = e.scheduleDeferredCallback,
                B = e.useSyncScheduling,
                A = e.prepareForCommit,
                U = e.resetAfterCommit,
                I = Oi,
                L = !1,
                F = !1,
                N = !1,
                W = !1,
                H = null,
                K = Oi,
                z = null,
                q = null,
                G = null,
                V = null,
                Y = !1,
                $ = null,
                X = null,
                Z = null,
                Q = null,
                J = !1,
                ee = !1,
                te = !1,
                re = 1e3,
                ne = 0,
                oe = null;
            return {
                scheduleUpdate: _,
                getPriorityContext: b,
                batchedUpdates: function (e, t) {
                    var r = N;
                    N = !0;
                    try {
                        return e(t);
                    } finally {
                        (N = r), L || N || c(Di, null);
                    }
                },
                unbatchedUpdates: function (e) {
                    var t = W,
                        r = N;
                    (W = N), (N = !1);
                    try {
                        return e();
                    } finally {
                        (N = r), (W = t);
                    }
                },
                flushSync: function (e) {
                    var t = N,
                        r = I;
                    (N = !0), (I = Mi);
                    try {
                        return e();
                    } finally {
                        (N = t), (I = r), L && n("187"), c(Di, null);
                    }
                },
                deferredUpdates: function (e) {
                    var t = I;
                    I = Si;
                    try {
                        return e();
                    } finally {
                        I = t;
                    }
                },
            };
        }
        function _e() {
            n("196");
        }
        function he(e) {
            return e ? ("number" == typeof (e = Yt.get(e)).tag ? _e(e) : e._processChildContext(e._context)) : yt;
        }
        function be(e) {
            for (; e && e.firstChild; ) e = e.firstChild;
            return e;
        }
        function me(e, t) {
            var r = be(e);
            e = 0;
            for (var n; r; ) {
                if (r.nodeType === rl) {
                    if (((n = e + r.textContent.length), e <= t && n >= t)) return { node: r, offset: t - e };
                    e = n;
                }
                e: {
                    for (; r; ) {
                        if (r.nextSibling) {
                            r = r.nextSibling;
                            break e;
                        }
                        r = r.parentNode;
                    }
                    r = void 0;
                }
                r = be(r);
            }
        }
        function ge() {
            return !nl && bt.canUseDOM && (nl = "textContent" in document.documentElement ? "textContent" : "innerText"), nl;
        }
        function ve() {
            n("211");
        }
        function ye() {
            n("212");
        }
        function Ee(e) {
            if (null == e) return null;
            if (e.nodeType === ul) return e;
            var t = Yt.get(e);
            if (t) return "number" == typeof t.tag ? ve(t) : ye(t);
            "function" == typeof e.render ? n("188") : n("213", Object.keys(e));
        }
        function Ce(e) {
            if (void 0 !== e._hostParent) return e._hostParent;
            if ("number" == typeof e.tag) {
                do {
                    e = e.return;
                } while (e && e.tag !== sl);
                if (e) return e;
            }
            return null;
        }
        function ke(e, t) {
            for (var r = 0, n = e; n; n = Ce(n)) r++;
            n = 0;
            for (var o = t; o; o = Ce(o)) n++;
            for (; 0 < r - n; ) (e = Ce(e)), r--;
            for (; 0 < n - r; ) (t = Ce(t)), n--;
            for (; r--; ) {
                if (e === t || e === t.alternate) return e;
                (e = Ce(e)), (t = Ce(t));
            }
            return null;
        }
        function Pe(e, t, r) {
            (t = pl(e, r.dispatchConfig.phasedRegistrationNames[t])) && ((r._dispatchListeners = x(r._dispatchListeners, t)), (r._dispatchInstances = x(r._dispatchInstances, e)));
        }
        function xe(e) {
            e && e.dispatchConfig.phasedRegistrationNames && cl.traverseTwoPhase(e._targetInst, Pe, e);
        }
        function we(e) {
            if (e && e.dispatchConfig.phasedRegistrationNames) {
                var t = e._targetInst;
                (t = t ? cl.getParentInstance(t) : null), cl.traverseTwoPhase(t, Pe, e);
            }
        }
        function Oe(e, t, r) {
            e && r && r.dispatchConfig.registrationName && (t = pl(e, r.dispatchConfig.registrationName)) && ((r._dispatchListeners = x(r._dispatchListeners, t)), (r._dispatchInstances = x(r._dispatchInstances, e)));
        }
        function Me(e) {
            e && e.dispatchConfig.registrationName && Oe(e._targetInst, null, e);
        }
        function De(e, t, r, n) {
            (this.dispatchConfig = e), (this._targetInst = t), (this.nativeEvent = r), (e = this.constructor.Interface);
            for (var o in e) e.hasOwnProperty(o) && ((t = e[o]) ? (this[o] = t(r)) : "target" === o ? (this.target = n) : (this[o] = r[o]));
            return (this.isDefaultPrevented = (null != r.defaultPrevented ? r.defaultPrevented : !1 === r.returnValue) ? vt.thatReturnsTrue : vt.thatReturnsFalse), (this.isPropagationStopped = vt.thatReturnsFalse), this;
        }
        function Te(e, t, r, n) {
            if (this.eventPool.length) {
                var o = this.eventPool.pop();
                return this.call(o, e, t, r, n), o;
            }
            return new this(e, t, r, n);
        }
        function Se(e) {
            e instanceof this || n("223"), e.destructor(), 10 > this.eventPool.length && this.eventPool.push(e);
        }
        function Re(e) {
            (e.eventPool = []), (e.getPooled = Te), (e.release = Se);
        }
        function je(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function Be(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function Ae(e, t) {
            switch (e) {
                case "topKeyUp":
                    return -1 !== gl.indexOf(t.keyCode);
                case "topKeyDown":
                    return 229 !== t.keyCode;
                case "topKeyPress":
                case "topMouseDown":
                case "topBlur":
                    return !0;
                default:
                    return !1;
            }
        }
        function Ue(e) {
            return "object" == typeof (e = e.detail) && "data" in e ? e.data : null;
        }
        function Ie(e, t) {
            switch (e) {
                case "topCompositionEnd":
                    return Ue(t);
                case "topKeyPress":
                    return 32 !== t.which ? null : ((Ol = !0), xl);
                case "topTextInput":
                    return (e = t.data) === xl && Ol ? null : e;
                default:
                    return null;
            }
        }
        function Le(e, t) {
            if (Ml) return "topCompositionEnd" === e || (!vl && Ae(e, t)) ? ((e = hl.getData()), hl.reset(), (Ml = !1), e) : null;
            switch (e) {
                case "topPaste":
                    return null;
                case "topKeyPress":
                    if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
                        if (t.char && 1 < t.char.length) return t.char;
                        if (t.which) return String.fromCharCode(t.which);
                    }
                    return null;
                case "topCompositionEnd":
                    return Pl ? null : t.data;
                default:
                    return null;
            }
        }
        function Fe(e) {
            var t = e && e.nodeName && e.nodeName.toLowerCase();
            return "input" === t ? !!Tl[e.type] : "textarea" === t;
        }
        function Ne(e, t, r) {
            return (e = De.getPooled(Sl.change, e, t, r)), (e.type = "change"), pr.enqueueStateRestore(r), fl.accumulateTwoPhaseDispatches(e), e;
        }
        function We(e) {
            yr.enqueueEvents(e), yr.processEventQueue(!1);
        }
        function He(e) {
            var t = Vt.getNodeFromInstance(e);
            if (Qr.updateValueIfChanged(t)) return e;
        }
        function Ke(e, t) {
            if ("topChange" === e) return t;
        }
        function ze() {
            Rl && (Rl.detachEvent("onpropertychange", qe), (jl = Rl = null));
        }
        function qe(e) {
            "value" === e.propertyName && He(jl) && ((e = Ne(jl, e, k(e))), dr.batchedUpdates(We, e));
        }
        function Ge(e, t, r) {
            "topFocus" === e ? (ze(), (Rl = t), (jl = r), Rl.attachEvent("onpropertychange", qe)) : "topBlur" === e && ze();
        }
        function Ve(e) {
            if ("topSelectionChange" === e || "topKeyUp" === e || "topKeyDown" === e) return He(jl);
        }
        function Ye(e, t) {
            if ("topClick" === e) return He(t);
        }
        function $e(e, t) {
            if ("topInput" === e || "topChange" === e) return He(t);
        }
        function Xe(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function Ze(e) {
            var t = this.nativeEvent;
            return t.getModifierState ? t.getModifierState(e) : !!(e = Ul[e]) && !!t[e];
        }
        function Qe() {
            return Ze;
        }
        function Je(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function et(e, t) {
            if (ql || null == Hl || Hl !== Pt()) return null;
            var r = Hl;
            return (
                "selectionStart" in r && ll.hasSelectionCapabilities(r)
                    ? (r = { start: r.selectionStart, end: r.selectionEnd })
                    : window.getSelection
                    ? ((r = window.getSelection()), (r = { anchorNode: r.anchorNode, anchorOffset: r.anchorOffset, focusNode: r.focusNode, focusOffset: r.focusOffset }))
                    : (r = void 0),
                zl && Et(zl, r) ? null : ((zl = r), (e = De.getPooled(Wl.select, Kl, e, t)), (e.type = "select"), (e.target = Hl), fl.accumulateTwoPhaseDispatches(e), e)
            );
        }
        function tt(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function rt(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function nt(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function ot(e) {
            var t = e.keyCode;
            return "charCode" in e ? 0 === (e = e.charCode) && 13 === t && (e = 13) : (e = t), 32 <= e || 13 === e ? e : 0;
        }
        function at(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function it(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function lt(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function ut(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function st(e, t, r, n) {
            return De.call(this, e, t, r, n);
        }
        function ct(e) {
            return e[1].toUpperCase();
        }
        function pt(e) {
            return !(!e || (e.nodeType !== cu && e.nodeType !== du && e.nodeType !== _u && (e.nodeType !== fu || " react-mount-point-unstable " !== e.nodeValue)));
        }
        function ft(e) {
            return !(!(e = e ? (e.nodeType === du ? e.documentElement : e.firstChild) : null) || e.nodeType !== cu || !e.hasAttribute(hu));
        }
        function dt(e, t, r, o, a) {
            pt(r) || n("200");
            var i = r._reactRootContainer;
            if (i) Ru.updateContainer(t, i, e, a);
            else {
                if (!o && !ft(r)) for (o = void 0; (o = r.lastChild); ) r.removeChild(o);
                var l = Ru.createContainer(r);
                (i = r._reactRootContainer = l),
                    Ru.unbatchedUpdates(function () {
                        Ru.updateContainer(t, l, e, a);
                    });
            }
            return Ru.getPublicRootInstance(i);
        }
        function _t(e, t) {
            var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
            return pt(t) || n("200"), vo.createPortal(e, t, null, r);
        }
        var ht = r(0);
        r(67);
        var bt = r(139),
            mt = r(66),
            gt = r(140),
            vt = r(46),
            yt = r(141),
            Et = r(142),
            Ct = r(143),
            kt = r(146),
            Pt = r(147);
        ht || n("227");
        var xt,
            wt,
            Ot = {
                Namespaces: { html: "http://www.w3.org/1999/xhtml", mathml: "http://www.w3.org/1998/Math/MathML", svg: "http://www.w3.org/2000/svg" },
                getIntrinsicNamespace: o,
                getChildNamespace: function (e, t) {
                    return null == e || "http://www.w3.org/1999/xhtml" === e ? o(t) : "http://www.w3.org/2000/svg" === e && "foreignObject" === t ? "http://www.w3.org/1999/xhtml" : e;
                },
            },
            Mt = null,
            Dt = {},
            Tt = {
                plugins: [],
                eventNameDispatchConfigs: {},
                registrationNameModules: {},
                registrationNameDependencies: {},
                possibleRegistrationNames: null,
                injectEventPluginOrder: function (e) {
                    Mt && n("101"), (Mt = Array.prototype.slice.call(e)), a();
                },
                injectEventPluginsByName: function (e) {
                    var t,
                        r = !1;
                    for (t in e)
                        if (e.hasOwnProperty(t)) {
                            var o = e[t];
                            (Dt.hasOwnProperty(t) && Dt[t] === o) || (Dt[t] && n("102", t), (Dt[t] = o), (r = !0));
                        }
                    r && a();
                },
            },
            St = Tt,
            Rt = { children: !0, dangerouslySetInnerHTML: !0, autoFocus: !0, defaultValue: !0, defaultChecked: !0, innerHTML: !0, suppressContentEditableWarning: !0, style: !0 },
            jt = {
                MUST_USE_PROPERTY: 1,
                HAS_BOOLEAN_VALUE: 4,
                HAS_NUMERIC_VALUE: 8,
                HAS_POSITIVE_NUMERIC_VALUE: 24,
                HAS_OVERLOADED_BOOLEAN_VALUE: 32,
                HAS_STRING_BOOLEAN_VALUE: 64,
                injectDOMPropertyConfig: function (e) {
                    var t = jt,
                        r = e.Properties || {},
                        o = e.DOMAttributeNamespaces || {},
                        a = e.DOMAttributeNames || {};
                    e = e.DOMMutationMethods || {};
                    for (var i in r) {
                        Bt.properties.hasOwnProperty(i) && n("48", i);
                        var u = i.toLowerCase(),
                            s = r[i];
                        1 >=
                            (u = {
                                attributeName: u,
                                attributeNamespace: null,
                                propertyName: i,
                                mutationMethod: null,
                                mustUseProperty: l(s, t.MUST_USE_PROPERTY),
                                hasBooleanValue: l(s, t.HAS_BOOLEAN_VALUE),
                                hasNumericValue: l(s, t.HAS_NUMERIC_VALUE),
                                hasPositiveNumericValue: l(s, t.HAS_POSITIVE_NUMERIC_VALUE),
                                hasOverloadedBooleanValue: l(s, t.HAS_OVERLOADED_BOOLEAN_VALUE),
                                hasStringBooleanValue: l(s, t.HAS_STRING_BOOLEAN_VALUE),
                            }).hasBooleanValue +
                                u.hasNumericValue +
                                u.hasOverloadedBooleanValue || n("50", i),
                            a.hasOwnProperty(i) && (u.attributeName = a[i]),
                            o.hasOwnProperty(i) && (u.attributeNamespace = o[i]),
                            e.hasOwnProperty(i) && (u.mutationMethod = e[i]),
                            (Bt.properties[i] = u);
                    }
                },
            },
            Bt = {
                ID_ATTRIBUTE_NAME: "data-reactid",
                ROOT_ATTRIBUTE_NAME: "data-reactroot",
                ATTRIBUTE_NAME_START_CHAR: ":A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD",
                ATTRIBUTE_NAME_CHAR:
                    ":A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040",
                properties: {},
                shouldSetAttribute: function (e, t) {
                    if (Bt.isReservedProp(e) || !(("o" !== e[0] && "O" !== e[0]) || ("n" !== e[1] && "N" !== e[1]))) return !1;
                    if (null === t) return !0;
                    switch (typeof t) {
                        case "boolean":
                            return Bt.shouldAttributeAcceptBooleanValue(e);
                        case "undefined":
                        case "number":
                        case "string":
                        case "object":
                            return !0;
                        default:
                            return !1;
                    }
                },
                getPropertyInfo: function (e) {
                    return Bt.properties.hasOwnProperty(e) ? Bt.properties[e] : null;
                },
                shouldAttributeAcceptBooleanValue: function (e) {
                    if (Bt.isReservedProp(e)) return !0;
                    var t = Bt.getPropertyInfo(e);
                    return t ? t.hasBooleanValue || t.hasStringBooleanValue || t.hasOverloadedBooleanValue : "data-" === (e = e.toLowerCase().slice(0, 5)) || "aria-" === e;
                },
                isReservedProp: function (e) {
                    return Rt.hasOwnProperty(e);
                },
                injection: jt,
            },
            At = Bt,
            Ut = { IndeterminateComponent: 0, FunctionalComponent: 1, ClassComponent: 2, HostRoot: 3, HostPortal: 4, HostComponent: 5, HostText: 6, CoroutineComponent: 7, CoroutineHandlerPhase: 8, YieldComponent: 9, Fragment: 10 },
            It = { ELEMENT_NODE: 1, TEXT_NODE: 3, COMMENT_NODE: 8, DOCUMENT_NODE: 9, DOCUMENT_FRAGMENT_NODE: 11 },
            Lt = Ut.HostComponent,
            Ft = Ut.HostText,
            Nt = It.ELEMENT_NODE,
            Wt = It.COMMENT_NODE,
            Ht = At.ID_ATTRIBUTE_NAME,
            Kt = { hasCachedChildNodes: 1 },
            zt = Math.random().toString(36).slice(2),
            qt = "__reactInternalInstance$" + zt,
            Gt = "__reactEventHandlers$" + zt,
            Vt = {
                getClosestInstanceFromNode: p,
                getInstanceFromNode: function (e) {
                    var t = e[qt];
                    return t ? (t.tag === Lt || t.tag === Ft ? t : t._hostNode === e ? t : null) : null != (t = p(e)) && t._hostNode === e ? t : null;
                },
                getNodeFromInstance: function (e) {
                    if (e.tag === Lt || e.tag === Ft) return e.stateNode;
                    if ((void 0 === e._hostNode && n("33"), e._hostNode)) return e._hostNode;
                    for (var t = []; !e._hostNode; ) t.push(e), e._hostParent || n("34"), (e = e._hostParent);
                    for (; t.length; e = t.pop()) c(e, e._hostNode);
                    return e._hostNode;
                },
                precacheChildNodes: c,
                precacheNode: s,
                uncacheNode: function (e) {
                    var t = e._hostNode;
                    t && (delete t[qt], (e._hostNode = null));
                },
                precacheFiberNode: function (e, t) {
                    t[qt] = e;
                },
                getFiberCurrentPropsFromNode: function (e) {
                    return e[Gt] || null;
                },
                updateFiberProps: function (e, t) {
                    e[Gt] = t;
                },
            },
            Yt = {
                remove: function (e) {
                    e._reactInternalFiber = void 0;
                },
                get: function (e) {
                    return e._reactInternalFiber;
                },
                has: function (e) {
                    return void 0 !== e._reactInternalFiber;
                },
                set: function (e, t) {
                    e._reactInternalFiber = t;
                },
            },
            $t = { ReactCurrentOwner: ht.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner },
            Xt = { NoEffect: 0, PerformedWork: 1, Placement: 2, Update: 4, PlacementAndUpdate: 6, Deletion: 8, ContentReset: 16, Callback: 32, Err: 64, Ref: 128 },
            Zt = Ut.HostComponent,
            Qt = Ut.HostRoot,
            Jt = Ut.HostPortal,
            er = Ut.HostText,
            tr = Xt.NoEffect,
            rr = Xt.Placement,
            nr = {
                isFiberMounted: function (e) {
                    return 2 === d(e);
                },
                isMounted: function (e) {
                    return !!(e = Yt.get(e)) && 2 === d(e);
                },
                findCurrentFiberUsingSlowPath: h,
                findCurrentHostFiber: function (e) {
                    if (!(e = h(e))) return null;
                    for (var t = e; ; ) {
                        if (t.tag === Zt || t.tag === er) return t;
                        if (t.child) (t.child.return = t), (t = t.child);
                        else {
                            if (t === e) break;
                            for (; !t.sibling; ) {
                                if (!t.return || t.return === e) return null;
                                t = t.return;
                            }
                            (t.sibling.return = t.return), (t = t.sibling);
                        }
                    }
                    return null;
                },
                findCurrentHostFiberWithNoPortals: function (e) {
                    if (!(e = h(e))) return null;
                    for (var t = e; ; ) {
                        if (t.tag === Zt || t.tag === er) return t;
                        if (t.child && t.tag !== Jt) (t.child.return = t), (t = t.child);
                        else {
                            if (t === e) break;
                            for (; !t.sibling; ) {
                                if (!t.return || t.return === e) return null;
                                t = t.return;
                            }
                            (t.sibling.return = t.return), (t = t.sibling);
                        }
                    }
                    return null;
                },
            },
            or = {
                _caughtError: null,
                _hasCaughtError: !1,
                _rethrowError: null,
                _hasRethrowError: !1,
                injection: {
                    injectErrorUtils: function (e) {
                        "function" != typeof e.invokeGuardedCallback && n("197"), (b = e.invokeGuardedCallback);
                    },
                },
                invokeGuardedCallback: function (e, t, r, n, o, a, i, l, u) {
                    b.apply(or, arguments);
                },
                invokeGuardedCallbackAndCatchFirstError: function (e, t, r, n, o, a, i, l, u) {
                    if ((or.invokeGuardedCallback.apply(this, arguments), or.hasCaughtError())) {
                        var s = or.clearCaughtError();
                        or._hasRethrowError || ((or._hasRethrowError = !0), (or._rethrowError = s));
                    }
                },
                rethrowCaughtError: function () {
                    return m.apply(or, arguments);
                },
                hasCaughtError: function () {
                    return or._hasCaughtError;
                },
                clearCaughtError: function () {
                    if (or._hasCaughtError) {
                        var e = or._caughtError;
                        return (or._caughtError = null), (or._hasCaughtError = !1), e;
                    }
                    n("198");
                },
            },
            ar = or,
            ir = {
                isEndish: function (e) {
                    return "topMouseUp" === e || "topTouchEnd" === e || "topTouchCancel" === e;
                },
                isMoveish: function (e) {
                    return "topMouseMove" === e || "topTouchMove" === e;
                },
                isStartish: function (e) {
                    return "topMouseDown" === e || "topTouchStart" === e;
                },
                executeDirectDispatch: function (e) {
                    var t = e._dispatchListeners,
                        r = e._dispatchInstances;
                    return Array.isArray(t) && n("103"), (e.currentTarget = t ? ir.getNodeFromInstance(r) : null), (t = t ? t(e) : null), (e.currentTarget = null), (e._dispatchListeners = null), (e._dispatchInstances = null), t;
                },
                executeDispatchesInOrder: function (e, t) {
                    var r = e._dispatchListeners,
                        n = e._dispatchInstances;
                    if (Array.isArray(r)) for (var o = 0; o < r.length && !e.isPropagationStopped(); o++) g(e, t, r[o], n[o]);
                    else r && g(e, t, r, n);
                    (e._dispatchListeners = null), (e._dispatchInstances = null);
                },
                executeDispatchesInOrderStopAtTrue: function (e) {
                    e: {
                        var t = e._dispatchListeners,
                            r = e._dispatchInstances;
                        if (Array.isArray(t)) {
                            for (var n = 0; n < t.length && !e.isPropagationStopped(); n++)
                                if (t[n](e, r[n])) {
                                    t = r[n];
                                    break e;
                                }
                        } else if (t && t(e, r)) {
                            t = r;
                            break e;
                        }
                        t = null;
                    }
                    return (e._dispatchInstances = null), (e._dispatchListeners = null), t;
                },
                hasDispatches: function (e) {
                    return !!e._dispatchListeners;
                },
                getFiberCurrentPropsFromNode: function (e) {
                    return xt.getFiberCurrentPropsFromNode(e);
                },
                getInstanceFromNode: function (e) {
                    return xt.getInstanceFromNode(e);
                },
                getNodeFromInstance: function (e) {
                    return xt.getNodeFromInstance(e);
                },
                injection: {
                    injectComponentTree: function (e) {
                        xt = e;
                    },
                },
            },
            lr = ir,
            ur = null,
            sr = null,
            cr = null,
            pr = {
                injection: {
                    injectFiberControlledHostComponent: function (e) {
                        ur = e;
                    },
                },
                enqueueStateRestore: function (e) {
                    sr ? (cr ? cr.push(e) : (cr = [e])) : (sr = e);
                },
                restoreStateIfNeeded: function () {
                    if (sr) {
                        var e = sr,
                            t = cr;
                        if (((cr = sr = null), v(e), t)) for (e = 0; e < t.length; e++) v(t[e]);
                    }
                },
            },
            fr = !1,
            dr = {
                batchedUpdates: function (e, t) {
                    if (fr) return y(C, e, t);
                    fr = !0;
                    try {
                        return y(C, e, t);
                    } finally {
                        (fr = !1), pr.restoreStateIfNeeded();
                    }
                },
                injection: {
                    injectStackBatchedUpdates: function (e) {
                        y = e;
                    },
                    injectFiberBatchedUpdates: function (e) {
                        E = e;
                    },
                },
            },
            _r = It.TEXT_NODE,
            hr = Ut.HostRoot,
            br = [],
            mr = {
                _enabled: !0,
                _handleTopLevel: null,
                setHandleTopLevel: function (e) {
                    mr._handleTopLevel = e;
                },
                setEnabled: function (e) {
                    mr._enabled = !!e;
                },
                isEnabled: function () {
                    return mr._enabled;
                },
                trapBubbledEvent: function (e, t, r) {
                    return r ? gt.listen(r, t, mr.dispatchEvent.bind(null, e)) : null;
                },
                trapCapturedEvent: function (e, t, r) {
                    return r ? gt.capture(r, t, mr.dispatchEvent.bind(null, e)) : null;
                },
                dispatchEvent: function (e, t) {
                    if (mr._enabled) {
                        var r = k(t);
                        if ((null === (r = Vt.getClosestInstanceFromNode(r)) || "number" != typeof r.tag || nr.isFiberMounted(r) || (r = null), br.length)) {
                            var n = br.pop();
                            (n.topLevelType = e), (n.nativeEvent = t), (n.targetInst = r), (e = n);
                        } else e = { topLevelType: e, nativeEvent: t, targetInst: r, ancestors: [] };
                        try {
                            dr.batchedUpdates(P, e);
                        } finally {
                            (e.topLevelType = null), (e.nativeEvent = null), (e.targetInst = null), (e.ancestors.length = 0), 10 > br.length && br.push(e);
                        }
                    }
                },
            },
            gr = mr,
            vr = null,
            yr = {
                injection: { injectEventPluginOrder: St.injectEventPluginOrder, injectEventPluginsByName: St.injectEventPluginsByName },
                getListener: function (e, t) {
                    if ("number" == typeof e.tag) {
                        var r = e.stateNode;
                        if (!r) return null;
                        var o = lr.getFiberCurrentPropsFromNode(r);
                        if (!o) return null;
                        if (((r = o[t]), T(t, e.type, o))) return null;
                    } else {
                        if ("string" == typeof (o = e._currentElement) || "number" == typeof o || !e._rootNodeID) return null;
                        if (((e = o.props), (r = e[t]), T(t, o.type, e))) return null;
                    }
                    return r && "function" != typeof r && n("231", t, typeof r), r;
                },
                extractEvents: function (e, t, r, n) {
                    for (var o, a = St.plugins, i = 0; i < a.length; i++) {
                        var l = a[i];
                        l && (l = l.extractEvents(e, t, r, n)) && (o = x(o, l));
                    }
                    return o;
                },
                enqueueEvents: function (e) {
                    e && (vr = x(vr, e));
                },
                processEventQueue: function (e) {
                    var t = vr;
                    (vr = null), e ? w(t, M) : w(t, D), vr && n("95"), ar.rethrowCaughtError();
                },
            };
        bt.canUseDOM && (wt = document.implementation && document.implementation.hasFeature && !0 !== document.implementation.hasFeature("", ""));
        var Er = { animationend: R("Animation", "AnimationEnd"), animationiteration: R("Animation", "AnimationIteration"), animationstart: R("Animation", "AnimationStart"), transitionend: R("Transition", "TransitionEnd") },
            Cr = {},
            kr = {};
        bt.canUseDOM &&
            ((kr = document.createElement("div").style),
            "AnimationEvent" in window || (delete Er.animationend.animation, delete Er.animationiteration.animation, delete Er.animationstart.animation),
            "TransitionEvent" in window || delete Er.transitionend.transition);
        var Pr = {
                topAbort: "abort",
                topAnimationEnd: j("animationend") || "animationend",
                topAnimationIteration: j("animationiteration") || "animationiteration",
                topAnimationStart: j("animationstart") || "animationstart",
                topBlur: "blur",
                topCancel: "cancel",
                topCanPlay: "canplay",
                topCanPlayThrough: "canplaythrough",
                topChange: "change",
                topClick: "click",
                topClose: "close",
                topCompositionEnd: "compositionend",
                topCompositionStart: "compositionstart",
                topCompositionUpdate: "compositionupdate",
                topContextMenu: "contextmenu",
                topCopy: "copy",
                topCut: "cut",
                topDoubleClick: "dblclick",
                topDrag: "drag",
                topDragEnd: "dragend",
                topDragEnter: "dragenter",
                topDragExit: "dragexit",
                topDragLeave: "dragleave",
                topDragOver: "dragover",
                topDragStart: "dragstart",
                topDrop: "drop",
                topDurationChange: "durationchange",
                topEmptied: "emptied",
                topEncrypted: "encrypted",
                topEnded: "ended",
                topError: "error",
                topFocus: "focus",
                topInput: "input",
                topKeyDown: "keydown",
                topKeyPress: "keypress",
                topKeyUp: "keyup",
                topLoadedData: "loadeddata",
                topLoad: "load",
                topLoadedMetadata: "loadedmetadata",
                topLoadStart: "loadstart",
                topMouseDown: "mousedown",
                topMouseMove: "mousemove",
                topMouseOut: "mouseout",
                topMouseOver: "mouseover",
                topMouseUp: "mouseup",
                topPaste: "paste",
                topPause: "pause",
                topPlay: "play",
                topPlaying: "playing",
                topProgress: "progress",
                topRateChange: "ratechange",
                topScroll: "scroll",
                topSeeked: "seeked",
                topSeeking: "seeking",
                topSelectionChange: "selectionchange",
                topStalled: "stalled",
                topSuspend: "suspend",
                topTextInput: "textInput",
                topTimeUpdate: "timeupdate",
                topToggle: "toggle",
                topTouchCancel: "touchcancel",
                topTouchEnd: "touchend",
                topTouchMove: "touchmove",
                topTouchStart: "touchstart",
                topTransitionEnd: j("transitionend") || "transitionend",
                topVolumeChange: "volumechange",
                topWaiting: "waiting",
                topWheel: "wheel",
            },
            xr = {},
            wr = 0,
            Or = "_reactListenersID" + ("" + Math.random()).slice(2),
            Mr = mt(
                {},
                {
                    handleTopLevel: function (e, t, r, n) {
                        (e = yr.extractEvents(e, t, r, n)), yr.enqueueEvents(e), yr.processEventQueue(!1);
                    },
                },
                {
                    setEnabled: function (e) {
                        gr && gr.setEnabled(e);
                    },
                    isEnabled: function () {
                        return !(!gr || !gr.isEnabled());
                    },
                    listenTo: function (e, t) {
                        var r = B(t);
                        e = St.registrationNameDependencies[e];
                        for (var n = 0; n < e.length; n++) {
                            var o = e[n];
                            (r.hasOwnProperty(o) && r[o]) ||
                                ("topWheel" === o
                                    ? S("wheel")
                                        ? gr.trapBubbledEvent("topWheel", "wheel", t)
                                        : S("mousewheel")
                                        ? gr.trapBubbledEvent("topWheel", "mousewheel", t)
                                        : gr.trapBubbledEvent("topWheel", "DOMMouseScroll", t)
                                    : "topScroll" === o
                                    ? gr.trapCapturedEvent("topScroll", "scroll", t)
                                    : "topFocus" === o || "topBlur" === o
                                    ? (gr.trapCapturedEvent("topFocus", "focus", t), gr.trapCapturedEvent("topBlur", "blur", t), (r.topBlur = !0), (r.topFocus = !0))
                                    : "topCancel" === o
                                    ? (S("cancel", !0) && gr.trapCapturedEvent("topCancel", "cancel", t), (r.topCancel = !0))
                                    : "topClose" === o
                                    ? (S("close", !0) && gr.trapCapturedEvent("topClose", "close", t), (r.topClose = !0))
                                    : Pr.hasOwnProperty(o) && gr.trapBubbledEvent(o, Pr[o], t),
                                (r[o] = !0));
                        }
                    },
                    isListeningToAllDependencies: function (e, t) {
                        (t = B(t)), (e = St.registrationNameDependencies[e]);
                        for (var r = 0; r < e.length; r++) {
                            var n = e[r];
                            if (!t.hasOwnProperty(n) || !t[n]) return !1;
                        }
                        return !0;
                    },
                    trapBubbledEvent: function (e, t, r) {
                        return gr.trapBubbledEvent(e, t, r);
                    },
                    trapCapturedEvent: function (e, t, r) {
                        return gr.trapCapturedEvent(e, t, r);
                    },
                }
            ),
            Dr = {
                animationIterationCount: !0,
                borderImageOutset: !0,
                borderImageSlice: !0,
                borderImageWidth: !0,
                boxFlex: !0,
                boxFlexGroup: !0,
                boxOrdinalGroup: !0,
                columnCount: !0,
                columns: !0,
                flex: !0,
                flexGrow: !0,
                flexPositive: !0,
                flexShrink: !0,
                flexNegative: !0,
                flexOrder: !0,
                gridRow: !0,
                gridRowEnd: !0,
                gridRowSpan: !0,
                gridRowStart: !0,
                gridColumn: !0,
                gridColumnEnd: !0,
                gridColumnSpan: !0,
                gridColumnStart: !0,
                fontWeight: !0,
                lineClamp: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                tabSize: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0,
                fillOpacity: !0,
                floodOpacity: !0,
                stopOpacity: !0,
                strokeDasharray: !0,
                strokeDashoffset: !0,
                strokeMiterlimit: !0,
                strokeOpacity: !0,
                strokeWidth: !0,
            },
            Tr = ["Webkit", "ms", "Moz", "O"];
        Object.keys(Dr).forEach(function (e) {
            Tr.forEach(function (t) {
                (t = t + e.charAt(0).toUpperCase() + e.substring(1)), (Dr[t] = Dr[e]);
            });
        });
        var Sr = {
                isUnitlessNumber: Dr,
                shorthandPropertyExpansions: {
                    background: { backgroundAttachment: !0, backgroundColor: !0, backgroundImage: !0, backgroundPositionX: !0, backgroundPositionY: !0, backgroundRepeat: !0 },
                    backgroundPosition: { backgroundPositionX: !0, backgroundPositionY: !0 },
                    border: { borderWidth: !0, borderStyle: !0, borderColor: !0 },
                    borderBottom: { borderBottomWidth: !0, borderBottomStyle: !0, borderBottomColor: !0 },
                    borderLeft: { borderLeftWidth: !0, borderLeftStyle: !0, borderLeftColor: !0 },
                    borderRight: { borderRightWidth: !0, borderRightStyle: !0, borderRightColor: !0 },
                    borderTop: { borderTopWidth: !0, borderTopStyle: !0, borderTopColor: !0 },
                    font: { fontStyle: !0, fontVariant: !0, fontWeight: !0, fontSize: !0, lineHeight: !0, fontFamily: !0 },
                    outline: { outlineWidth: !0, outlineStyle: !0, outlineColor: !0 },
                },
            },
            Rr = Sr.isUnitlessNumber,
            jr = !1;
        if (bt.canUseDOM) {
            var Br = document.createElement("div").style;
            try {
                Br.font = "";
            } catch (e) {
                jr = !0;
            }
        }
        var Ar,
            Ur = {
                createDangerousStringForStyles: function () {},
                setValueForStyles: function (e, t) {
                    e = e.style;
                    for (var r in t)
                        if (t.hasOwnProperty(r)) {
                            var n = 0 === r.indexOf("--"),
                                o = r,
                                a = t[r];
                            if (((o = null == a || "boolean" == typeof a || "" === a ? "" : n || "number" != typeof a || 0 === a || (Rr.hasOwnProperty(o) && Rr[o]) ? ("" + a).trim() : a + "px"), "float" === r && (r = "cssFloat"), n))
                                e.setProperty(r, o);
                            else if (o) e[r] = o;
                            else if ((n = jr && Sr.shorthandPropertyExpansions[r])) for (var i in n) e[i] = "";
                            else e[r] = "";
                        }
                },
            },
            Ir = new RegExp("^[" + At.ATTRIBUTE_NAME_START_CHAR + "][" + At.ATTRIBUTE_NAME_CHAR + "]*$"),
            Lr = {},
            Fr = {},
            Nr = {
                setAttributeForID: function (e, t) {
                    e.setAttribute(At.ID_ATTRIBUTE_NAME, t);
                },
                setAttributeForRoot: function (e) {
                    e.setAttribute(At.ROOT_ATTRIBUTE_NAME, "");
                },
                getValueForProperty: function () {},
                getValueForAttribute: function () {},
                setValueForProperty: function (e, t, r) {
                    var n = At.getPropertyInfo(t);
                    if (n && At.shouldSetAttribute(t, r)) {
                        var o = n.mutationMethod;
                        o
                            ? o(e, r)
                            : null == r || (n.hasBooleanValue && !r) || (n.hasNumericValue && isNaN(r)) || (n.hasPositiveNumericValue && 1 > r) || (n.hasOverloadedBooleanValue && !1 === r)
                            ? Nr.deleteValueForProperty(e, t)
                            : n.mustUseProperty
                            ? (e[n.propertyName] = r)
                            : ((t = n.attributeName), (o = n.attributeNamespace) ? e.setAttributeNS(o, t, "" + r) : n.hasBooleanValue || (n.hasOverloadedBooleanValue && !0 === r) ? e.setAttribute(t, "") : e.setAttribute(t, "" + r));
                    } else Nr.setValueForAttribute(e, t, At.shouldSetAttribute(t, r) ? r : null);
                },
                setValueForAttribute: function (e, t, r) {
                    A(t) && (null == r ? e.removeAttribute(t) : e.setAttribute(t, "" + r));
                },
                deleteValueForAttribute: function (e, t) {
                    e.removeAttribute(t);
                },
                deleteValueForProperty: function (e, t) {
                    var r = At.getPropertyInfo(t);
                    r ? ((t = r.mutationMethod) ? t(e, void 0) : r.mustUseProperty ? (e[r.propertyName] = !r.hasBooleanValue && "") : e.removeAttribute(r.attributeName)) : e.removeAttribute(t);
                },
            },
            Wr = Nr,
            Hr = $t.ReactDebugCurrentFrame,
            Kr = {
                current: null,
                phase: null,
                resetCurrentFiber: function () {
                    (Hr.getCurrentStack = null), (Kr.current = null), (Kr.phase = null);
                },
                setCurrentFiber: function (e, t) {
                    (Hr.getCurrentStack = U), (Kr.current = e), (Kr.phase = t);
                },
                getCurrentFiberOwnerName: function () {
                    return null;
                },
                getCurrentFiberStackAddendum: U,
            },
            zr = Kr,
            qr = {
                getHostProps: function (e, t) {
                    var r = t.value,
                        n = t.checked;
                    return mt({ type: void 0, step: void 0, min: void 0, max: void 0 }, t, {
                        defaultChecked: void 0,
                        defaultValue: void 0,
                        value: null != r ? r : e._wrapperState.initialValue,
                        checked: null != n ? n : e._wrapperState.initialChecked,
                    });
                },
                initWrapperState: function (e, t) {
                    var r = t.defaultValue;
                    e._wrapperState = {
                        initialChecked: null != t.checked ? t.checked : t.defaultChecked,
                        initialValue: null != t.value ? t.value : r,
                        controlled: "checkbox" === t.type || "radio" === t.type ? null != t.checked : null != t.value,
                    };
                },
                updateWrapper: function (e, t) {
                    var r = t.checked;
                    null != r && Wr.setValueForProperty(e, "checked", r || !1),
                        null != (r = t.value)
                            ? 0 === r && "" === e.value
                                ? (e.value = "0")
                                : "number" === t.type
                                ? (r != (t = parseFloat(e.value) || 0) || (r == t && e.value != r)) && (e.value = "" + r)
                                : e.value !== "" + r && (e.value = "" + r)
                            : (null == t.value && null != t.defaultValue && e.defaultValue !== "" + t.defaultValue && (e.defaultValue = "" + t.defaultValue),
                              null == t.checked && null != t.defaultChecked && (e.defaultChecked = !!t.defaultChecked));
                },
                postMountWrapper: function (e, t) {
                    switch (t.type) {
                        case "submit":
                        case "reset":
                            break;
                        case "color":
                        case "date":
                        case "datetime":
                        case "datetime-local":
                        case "month":
                        case "time":
                        case "week":
                            (e.value = ""), (e.value = e.defaultValue);
                            break;
                        default:
                            e.value = e.value;
                    }
                    "" !== (t = e.name) && (e.name = ""), (e.defaultChecked = !e.defaultChecked), (e.defaultChecked = !e.defaultChecked), "" !== t && (e.name = t);
                },
                restoreControlledState: function (e, t) {
                    qr.updateWrapper(e, t);
                    var r = t.name;
                    if ("radio" === t.type && null != r) {
                        for (t = e; t.parentNode; ) t = t.parentNode;
                        for (r = t.querySelectorAll("input[name=" + JSON.stringify("" + r) + '][type="radio"]'), t = 0; t < r.length; t++) {
                            var o = r[t];
                            if (o !== e && o.form === e.form) {
                                var a = Vt.getFiberCurrentPropsFromNode(o);
                                a || n("90"), qr.updateWrapper(o, a);
                            }
                        }
                    }
                },
            },
            Gr = qr,
            Vr = {
                validateProps: function () {},
                postMountWrapper: function (e, t) {
                    null != t.value && e.setAttribute("value", t.value);
                },
                getHostProps: function (e, t) {
                    return (e = mt({ children: void 0 }, t)), (t = I(t.children)) && (e.children = t), e;
                },
            },
            Yr = {
                getHostProps: function (e, t) {
                    return mt({}, t, { value: void 0 });
                },
                initWrapperState: function (e, t) {
                    var r = t.value;
                    e._wrapperState = { initialValue: null != r ? r : t.defaultValue, wasMultiple: !!t.multiple };
                },
                postMountWrapper: function (e, t) {
                    e.multiple = !!t.multiple;
                    var r = t.value;
                    null != r ? L(e, !!t.multiple, r) : null != t.defaultValue && L(e, !!t.multiple, t.defaultValue);
                },
                postUpdateWrapper: function (e, t) {
                    e._wrapperState.initialValue = void 0;
                    var r = e._wrapperState.wasMultiple;
                    e._wrapperState.wasMultiple = !!t.multiple;
                    var n = t.value;
                    null != n ? L(e, !!t.multiple, n) : r !== !!t.multiple && (null != t.defaultValue ? L(e, !!t.multiple, t.defaultValue) : L(e, !!t.multiple, t.multiple ? [] : ""));
                },
                restoreControlledState: function (e, t) {
                    var r = t.value;
                    null != r && L(e, !!t.multiple, r);
                },
            },
            $r = {
                getHostProps: function (e, t) {
                    return null != t.dangerouslySetInnerHTML && n("91"), mt({}, t, { value: void 0, defaultValue: void 0, children: "" + e._wrapperState.initialValue });
                },
                initWrapperState: function (e, t) {
                    var r = t.value,
                        o = r;
                    null == r && ((r = t.defaultValue), null != (t = t.children) && (null != r && n("92"), Array.isArray(t) && (1 >= t.length || n("93"), (t = t[0])), (r = "" + t)), null == r && (r = ""), (o = r)),
                        (e._wrapperState = { initialValue: "" + o });
                },
                updateWrapper: function (e, t) {
                    var r = t.value;
                    null != r && ((r = "" + r) !== e.value && (e.value = r), null == t.defaultValue && (e.defaultValue = r)), null != t.defaultValue && (e.defaultValue = t.defaultValue);
                },
                postMountWrapper: function (e) {
                    var t = e.textContent;
                    t === e._wrapperState.initialValue && (e.value = t);
                },
                restoreControlledState: function (e, t) {
                    $r.updateWrapper(e, t);
                },
            },
            Xr = $r,
            Zr = mt({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 }),
            Qr = {
                _getTrackerFromNode: function (e) {
                    return e._valueTracker;
                },
                track: function (e) {
                    e._valueTracker || (e._valueTracker = W(e));
                },
                updateValueIfChanged: function (e) {
                    if (!e) return !1;
                    var t = e._valueTracker;
                    if (!t) return !0;
                    var r = t.getValue(),
                        n = "";
                    return e && (n = N(e) ? (e.checked ? "true" : "false") : e.value), (e = n) !== r && (t.setValue(e), !0);
                },
                stopTracking: function (e) {
                    (e = e._valueTracker) && e.stopTracking();
                },
            },
            Jr = Ot.Namespaces,
            en = (function (e) {
                return "undefined" != typeof MSApp && MSApp.execUnsafeLocalFunction
                    ? function (t, r, n, o) {
                          MSApp.execUnsafeLocalFunction(function () {
                              return e(t, r);
                          });
                      }
                    : e;
            })(function (e, t) {
                if (e.namespaceURI !== Jr.svg || "innerHTML" in e) e.innerHTML = t;
                else for (Ar = Ar || document.createElement("div"), Ar.innerHTML = "<svg>" + t + "</svg>", t = Ar.firstChild; t.firstChild; ) e.appendChild(t.firstChild);
            }),
            tn = /["'&<>]/,
            rn = It.TEXT_NODE;
        bt.canUseDOM &&
            ("textContent" in document.documentElement ||
                (K = function (e, t) {
                    if (e.nodeType === rn) e.nodeValue = t;
                    else {
                        if ("boolean" == typeof t || "number" == typeof t) t = "" + t;
                        else {
                            t = "" + t;
                            var r = tn.exec(t);
                            if (r) {
                                var n,
                                    o = "",
                                    a = 0;
                                for (n = r.index; n < t.length; n++) {
                                    switch (t.charCodeAt(n)) {
                                        case 34:
                                            r = "&quot;";
                                            break;
                                        case 38:
                                            r = "&amp;";
                                            break;
                                        case 39:
                                            r = "&#x27;";
                                            break;
                                        case 60:
                                            r = "&lt;";
                                            break;
                                        case 62:
                                            r = "&gt;";
                                            break;
                                        default:
                                            continue;
                                    }
                                    a !== n && (o += t.substring(a, n)), (a = n + 1), (o += r);
                                }
                                t = a !== n ? o + t.substring(a, n) : o;
                            }
                        }
                        en(e, t);
                    }
                }));
        var nn = K,
            on = (zr.getCurrentFiberOwnerName, It.DOCUMENT_NODE),
            an = It.DOCUMENT_FRAGMENT_NODE,
            ln = Mr.listenTo,
            un = St.registrationNameModules,
            sn = Ot.Namespaces.html,
            cn = Ot.getIntrinsicNamespace,
            pn = {
                topAbort: "abort",
                topCanPlay: "canplay",
                topCanPlayThrough: "canplaythrough",
                topDurationChange: "durationchange",
                topEmptied: "emptied",
                topEncrypted: "encrypted",
                topEnded: "ended",
                topError: "error",
                topLoadedData: "loadeddata",
                topLoadedMetadata: "loadedmetadata",
                topLoadStart: "loadstart",
                topPause: "pause",
                topPlay: "play",
                topPlaying: "playing",
                topProgress: "progress",
                topRateChange: "ratechange",
                topSeeked: "seeked",
                topSeeking: "seeking",
                topStalled: "stalled",
                topSuspend: "suspend",
                topTimeUpdate: "timeupdate",
                topVolumeChange: "volumechange",
                topWaiting: "waiting",
            },
            fn = {
                createElement: function (e, t, r, n) {
                    return (
                        (r = r.nodeType === on ? r : r.ownerDocument),
                        n === sn && (n = cn(e)),
                        n === sn
                            ? "script" === e
                                ? ((e = r.createElement("div")), (e.innerHTML = "<script></script>"), (e = e.removeChild(e.firstChild)))
                                : (e = "string" == typeof t.is ? r.createElement(e, { is: t.is }) : r.createElement(e))
                            : (e = r.createElementNS(n, e)),
                        e
                    );
                },
                createTextNode: function (e, t) {
                    return (t.nodeType === on ? t : t.ownerDocument).createTextNode(e);
                },
                setInitialProperties: function (e, t, r, n) {
                    var o = H(t, r);
                    switch (t) {
                        case "iframe":
                        case "object":
                            Mr.trapBubbledEvent("topLoad", "load", e);
                            var a = r;
                            break;
                        case "video":
                        case "audio":
                            for (a in pn) pn.hasOwnProperty(a) && Mr.trapBubbledEvent(a, pn[a], e);
                            a = r;
                            break;
                        case "source":
                            Mr.trapBubbledEvent("topError", "error", e), (a = r);
                            break;
                        case "img":
                        case "image":
                            Mr.trapBubbledEvent("topError", "error", e), Mr.trapBubbledEvent("topLoad", "load", e), (a = r);
                            break;
                        case "form":
                            Mr.trapBubbledEvent("topReset", "reset", e), Mr.trapBubbledEvent("topSubmit", "submit", e), (a = r);
                            break;
                        case "details":
                            Mr.trapBubbledEvent("topToggle", "toggle", e), (a = r);
                            break;
                        case "input":
                            Gr.initWrapperState(e, r), (a = Gr.getHostProps(e, r)), Mr.trapBubbledEvent("topInvalid", "invalid", e), z(n, "onChange");
                            break;
                        case "option":
                            Vr.validateProps(e, r), (a = Vr.getHostProps(e, r));
                            break;
                        case "select":
                            Yr.initWrapperState(e, r), (a = Yr.getHostProps(e, r)), Mr.trapBubbledEvent("topInvalid", "invalid", e), z(n, "onChange");
                            break;
                        case "textarea":
                            Xr.initWrapperState(e, r), (a = Xr.getHostProps(e, r)), Mr.trapBubbledEvent("topInvalid", "invalid", e), z(n, "onChange");
                            break;
                        default:
                            a = r;
                    }
                    F(t, a);
                    var i,
                        l = a;
                    for (i in l)
                        if (l.hasOwnProperty(i)) {
                            var u = l[i];
                            "style" === i
                                ? Ur.setValueForStyles(e, u)
                                : "dangerouslySetInnerHTML" === i
                                ? null != (u = u ? u.__html : void 0) && en(e, u)
                                : "children" === i
                                ? "string" == typeof u
                                    ? nn(e, u)
                                    : "number" == typeof u && nn(e, "" + u)
                                : "suppressContentEditableWarning" !== i && (un.hasOwnProperty(i) ? null != u && z(n, i) : o ? Wr.setValueForAttribute(e, i, u) : null != u && Wr.setValueForProperty(e, i, u));
                        }
                    switch (t) {
                        case "input":
                            Qr.track(e), Gr.postMountWrapper(e, r);
                            break;
                        case "textarea":
                            Qr.track(e), Xr.postMountWrapper(e, r);
                            break;
                        case "option":
                            Vr.postMountWrapper(e, r);
                            break;
                        case "select":
                            Yr.postMountWrapper(e, r);
                            break;
                        default:
                            "function" == typeof a.onClick && (e.onclick = vt);
                    }
                },
                diffProperties: function (e, t, r, n, o) {
                    var a = null;
                    switch (t) {
                        case "input":
                            (r = Gr.getHostProps(e, r)), (n = Gr.getHostProps(e, n)), (a = []);
                            break;
                        case "option":
                            (r = Vr.getHostProps(e, r)), (n = Vr.getHostProps(e, n)), (a = []);
                            break;
                        case "select":
                            (r = Yr.getHostProps(e, r)), (n = Yr.getHostProps(e, n)), (a = []);
                            break;
                        case "textarea":
                            (r = Xr.getHostProps(e, r)), (n = Xr.getHostProps(e, n)), (a = []);
                            break;
                        default:
                            "function" != typeof r.onClick && "function" == typeof n.onClick && (e.onclick = vt);
                    }
                    F(t, n);
                    var i, l;
                    e = null;
                    for (i in r)
                        if (!n.hasOwnProperty(i) && r.hasOwnProperty(i) && null != r[i])
                            if ("style" === i) for (l in (t = r[i])) t.hasOwnProperty(l) && (e || (e = {}), (e[l] = ""));
                            else "dangerouslySetInnerHTML" !== i && "children" !== i && "suppressContentEditableWarning" !== i && (un.hasOwnProperty(i) ? a || (a = []) : (a = a || []).push(i, null));
                    for (i in n) {
                        var u = n[i];
                        if (((t = null != r ? r[i] : void 0), n.hasOwnProperty(i) && u !== t && (null != u || null != t)))
                            if ("style" === i)
                                if (t) {
                                    for (l in t) !t.hasOwnProperty(l) || (u && u.hasOwnProperty(l)) || (e || (e = {}), (e[l] = ""));
                                    for (l in u) u.hasOwnProperty(l) && t[l] !== u[l] && (e || (e = {}), (e[l] = u[l]));
                                } else e || (a || (a = []), a.push(i, e)), (e = u);
                            else
                                "dangerouslySetInnerHTML" === i
                                    ? ((u = u ? u.__html : void 0), (t = t ? t.__html : void 0), null != u && t !== u && (a = a || []).push(i, "" + u))
                                    : "children" === i
                                    ? t === u || ("string" != typeof u && "number" != typeof u) || (a = a || []).push(i, "" + u)
                                    : "suppressContentEditableWarning" !== i && (un.hasOwnProperty(i) ? (null != u && z(o, i), a || t === u || (a = [])) : (a = a || []).push(i, u));
                    }
                    return e && (a = a || []).push("style", e), a;
                },
                updateProperties: function (e, t, r, n, o) {
                    H(r, n), (n = H(r, o));
                    for (var a = 0; a < t.length; a += 2) {
                        var i = t[a],
                            l = t[a + 1];
                        "style" === i
                            ? Ur.setValueForStyles(e, l)
                            : "dangerouslySetInnerHTML" === i
                            ? en(e, l)
                            : "children" === i
                            ? nn(e, l)
                            : n
                            ? null != l
                                ? Wr.setValueForAttribute(e, i, l)
                                : Wr.deleteValueForAttribute(e, i)
                            : null != l
                            ? Wr.setValueForProperty(e, i, l)
                            : Wr.deleteValueForProperty(e, i);
                    }
                    switch (r) {
                        case "input":
                            Gr.updateWrapper(e, o), Qr.updateValueIfChanged(e);
                            break;
                        case "textarea":
                            Xr.updateWrapper(e, o);
                            break;
                        case "select":
                            Yr.postUpdateWrapper(e, o);
                    }
                },
                diffHydratedProperties: function (e, t, r, n, o) {
                    switch (t) {
                        case "iframe":
                        case "object":
                            Mr.trapBubbledEvent("topLoad", "load", e);
                            break;
                        case "video":
                        case "audio":
                            for (var a in pn) pn.hasOwnProperty(a) && Mr.trapBubbledEvent(a, pn[a], e);
                            break;
                        case "source":
                            Mr.trapBubbledEvent("topError", "error", e);
                            break;
                        case "img":
                        case "image":
                            Mr.trapBubbledEvent("topError", "error", e), Mr.trapBubbledEvent("topLoad", "load", e);
                            break;
                        case "form":
                            Mr.trapBubbledEvent("topReset", "reset", e), Mr.trapBubbledEvent("topSubmit", "submit", e);
                            break;
                        case "details":
                            Mr.trapBubbledEvent("topToggle", "toggle", e);
                            break;
                        case "input":
                            Gr.initWrapperState(e, r), Mr.trapBubbledEvent("topInvalid", "invalid", e), z(o, "onChange");
                            break;
                        case "option":
                            Vr.validateProps(e, r);
                            break;
                        case "select":
                            Yr.initWrapperState(e, r), Mr.trapBubbledEvent("topInvalid", "invalid", e), z(o, "onChange");
                            break;
                        case "textarea":
                            Xr.initWrapperState(e, r), Mr.trapBubbledEvent("topInvalid", "invalid", e), z(o, "onChange");
                    }
                    F(t, r), (n = null);
                    for (var i in r)
                        r.hasOwnProperty(i) &&
                            ((a = r[i]),
                            "children" === i
                                ? "string" == typeof a
                                    ? e.textContent !== a && (n = ["children", a])
                                    : "number" == typeof a && e.textContent !== "" + a && (n = ["children", "" + a])
                                : un.hasOwnProperty(i) && null != a && z(o, i));
                    switch (t) {
                        case "input":
                            Qr.track(e), Gr.postMountWrapper(e, r);
                            break;
                        case "textarea":
                            Qr.track(e), Xr.postMountWrapper(e, r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            "function" == typeof r.onClick && (e.onclick = vt);
                    }
                    return n;
                },
                diffHydratedText: function (e, t) {
                    return e.nodeValue !== t;
                },
                warnForDeletedHydratableElement: function () {},
                warnForDeletedHydratableText: function () {},
                warnForInsertedHydratedElement: function () {},
                warnForInsertedHydratedText: function () {},
                restoreControlledState: function (e, t, r) {
                    switch (t) {
                        case "input":
                            Gr.restoreControlledState(e, r);
                            break;
                        case "textarea":
                            Xr.restoreControlledState(e, r);
                            break;
                        case "select":
                            Yr.restoreControlledState(e, r);
                    }
                },
            },
            dn = void 0;
        if (bt.canUseDOM)
            if ("function" != typeof requestIdleCallback) {
                var _n = null,
                    hn = null,
                    bn = !1,
                    mn = !1,
                    gn = 0,
                    vn = 33,
                    yn = 33,
                    En = {
                        timeRemaining:
                            "object" == typeof performance && "function" == typeof performance.now
                                ? function () {
                                      return gn - performance.now();
                                  }
                                : function () {
                                      return gn - Date.now();
                                  },
                    },
                    Cn = "__reactIdleCallback$" + Math.random().toString(36).slice(2);
                window.addEventListener(
                    "message",
                    function (e) {
                        e.source === window && e.data === Cn && ((bn = !1), (e = hn), (hn = null), null !== e && e(En));
                    },
                    !1
                );
                var kn = function (e) {
                    mn = !1;
                    var t = e - gn + yn;
                    t < yn && vn < yn ? (8 > t && (t = 8), (yn = t < vn ? vn : t)) : (vn = t), (gn = e + yn), bn || ((bn = !0), window.postMessage(Cn, "*")), (t = _n), (_n = null), null !== t && t(e);
                };
                dn = function (e) {
                    return (hn = e), mn || ((mn = !0), requestAnimationFrame(kn)), 0;
                };
            } else dn = requestIdleCallback;
        else
            dn = function (e) {
                return (
                    setTimeout(function () {
                        e({
                            timeRemaining: function () {
                                return 1 / 0;
                            },
                        });
                    }),
                    0
                );
            };
        var Pn,
            xn,
            wn = { rIC: dn },
            On = { enableAsyncSubtreeAPI: !0 },
            Mn = { NoWork: 0, SynchronousPriority: 1, TaskPriority: 2, HighPriority: 3, LowPriority: 4, OffscreenPriority: 5 },
            Dn = Xt.Callback,
            Tn = Mn.NoWork,
            Sn = Mn.SynchronousPriority,
            Rn = Mn.TaskPriority,
            jn = Ut.ClassComponent,
            Bn = Ut.HostRoot,
            An = void 0,
            Un = void 0,
            In = {
                addUpdate: function (e, t, r, n) {
                    $(e, { priorityLevel: n, partialState: t, callback: r, isReplace: !1, isForced: !1, isTopLevelUnmount: !1, next: null });
                },
                addReplaceUpdate: function (e, t, r, n) {
                    $(e, { priorityLevel: n, partialState: t, callback: r, isReplace: !0, isForced: !1, isTopLevelUnmount: !1, next: null });
                },
                addForceUpdate: function (e, t, r) {
                    $(e, { priorityLevel: r, partialState: null, callback: t, isReplace: !1, isForced: !0, isTopLevelUnmount: !1, next: null });
                },
                getUpdatePriority: function (e) {
                    var t = e.updateQueue;
                    return null === t || (e.tag !== jn && e.tag !== Bn) ? Tn : null !== t.first ? t.first.priorityLevel : Tn;
                },
                addTopLevelUpdate: function (e, t, r, n) {
                    var o = null === t.element;
                    (e = $(e, (t = { priorityLevel: n, partialState: t, callback: r, isReplace: !1, isForced: !1, isTopLevelUnmount: o, next: null }))),
                        o && ((o = An), (r = Un), null !== o && null !== t.next && ((t.next = null), (o.last = t)), null !== r && null !== e && null !== e.next && ((e.next = null), (r.last = t)));
                },
                beginUpdateQueue: function (e, t, r, n, o, a, i) {
                    null !== e && e.updateQueue === r && (r = t.updateQueue = { first: r.first, last: r.last, callbackList: null, hasForceUpdate: !1 }), (e = r.callbackList);
                    for (var l = r.hasForceUpdate, u = !0, s = r.first; null !== s && 0 >= q(s.priorityLevel, i); ) {
                        (r.first = s.next), null === r.first && (r.last = null);
                        var c;
                        s.isReplace ? ((o = X(s, n, o, a)), (u = !0)) : (c = X(s, n, o, a)) && ((o = u ? mt({}, o, c) : mt(o, c)), (u = !1)),
                            s.isForced && (l = !0),
                            null === s.callback || (s.isTopLevelUnmount && null !== s.next) || ((e = null !== e ? e : []).push(s.callback), (t.effectTag |= Dn)),
                            (s = s.next);
                    }
                    return (r.callbackList = e), (r.hasForceUpdate = l), null !== r.first || null !== e || l || (t.updateQueue = null), o;
                },
                commitCallbacks: function (e, t, r) {
                    if (null !== (e = t.callbackList))
                        for (t.callbackList = null, t = 0; t < e.length; t++) {
                            var o = e[t];
                            "function" != typeof o && n("191", o), o.call(r);
                        }
                },
            },
            Ln = [],
            Fn = -1,
            Nn = {
                createCursor: function (e) {
                    return { current: e };
                },
                isEmpty: function () {
                    return -1 === Fn;
                },
                pop: function (e) {
                    0 > Fn || ((e.current = Ln[Fn]), (Ln[Fn] = null), Fn--);
                },
                push: function (e, t) {
                    (Ln[++Fn] = e.current), (e.current = t);
                },
                reset: function () {
                    for (; -1 < Fn; ) (Ln[Fn] = null), Fn--;
                },
            },
            Wn = nr.isFiberMounted,
            Hn = Ut.ClassComponent,
            Kn = Ut.HostRoot,
            zn = Nn.createCursor,
            qn = Nn.pop,
            Gn = Nn.push,
            Vn = zn(yt),
            Yn = zn(!1),
            $n = yt,
            Xn = {
                getUnmaskedContext: function (e) {
                    return Q(e) ? $n : Vn.current;
                },
                cacheContext: Z,
                getMaskedContext: function (e, t) {
                    var r = e.type.contextTypes;
                    if (!r) return yt;
                    var n = e.stateNode;
                    if (n && n.__reactInternalMemoizedUnmaskedChildContext === t) return n.__reactInternalMemoizedMaskedChildContext;
                    var o,
                        a = {};
                    for (o in r) a[o] = t[o];
                    return n && Z(e, t, a), a;
                },
                hasContextChanged: function () {
                    return Yn.current;
                },
                isContextConsumer: function (e) {
                    return e.tag === Hn && null != e.type.contextTypes;
                },
                isContextProvider: Q,
                popContextProvider: function (e) {
                    Q(e) && (qn(Yn, e), qn(Vn, e));
                },
                popTopLevelContextObject: function (e) {
                    qn(Yn, e), qn(Vn, e);
                },
                pushTopLevelContextObject: function (e, t, r) {
                    null != Vn.cursor && n("168"), Gn(Vn, t, e), Gn(Yn, r, e);
                },
                processChildContext: J,
                pushContextProvider: function (e) {
                    if (!Q(e)) return !1;
                    var t = e.stateNode;
                    return (t = (t && t.__reactInternalMemoizedMergedChildContext) || yt), ($n = Vn.current), Gn(Vn, t, e), Gn(Yn, Yn.current, e), !0;
                },
                invalidateContextProvider: function (e, t) {
                    var r = e.stateNode;
                    if ((r || n("169"), t)) {
                        var o = J(e, $n);
                        (r.__reactInternalMemoizedMergedChildContext = o), qn(Yn, e), qn(Vn, e), Gn(Vn, o, e);
                    } else qn(Yn, e);
                    Gn(Yn, t, e);
                },
                resetContext: function () {
                    ($n = yt), (Vn.current = yt), (Yn.current = !1);
                },
                findCurrentUnmaskedContext: function (e) {
                    for (Wn(e) && e.tag === Hn ? void 0 : n("170"); e.tag !== Kn; ) {
                        if (Q(e)) return e.stateNode.__reactInternalMemoizedMergedChildContext;
                        (e = e.return) || n("171");
                    }
                    return e.stateNode.context;
                },
            },
            Zn = { NoContext: 0, AsyncUpdates: 1 },
            Qn = Ut.IndeterminateComponent,
            Jn = Ut.ClassComponent,
            eo = Ut.HostRoot,
            to = Ut.HostComponent,
            ro = Ut.HostText,
            no = Ut.HostPortal,
            oo = Ut.CoroutineComponent,
            ao = Ut.YieldComponent,
            io = Ut.Fragment,
            lo = Mn.NoWork,
            uo = Zn.NoContext,
            so = Xt.NoEffect,
            co = {
                createWorkInProgress: function (e, t) {
                    var r = e.alternate;
                    return (
                        null === r
                            ? ((r = new ee(e.tag, e.key, e.internalContextTag)), (r.type = e.type), (r.stateNode = e.stateNode), (r.alternate = e), (e.alternate = r))
                            : ((r.effectTag = so), (r.nextEffect = null), (r.firstEffect = null), (r.lastEffect = null)),
                        (r.pendingWorkPriority = t),
                        (r.child = e.child),
                        (r.memoizedProps = e.memoizedProps),
                        (r.memoizedState = e.memoizedState),
                        (r.updateQueue = e.updateQueue),
                        (r.sibling = e.sibling),
                        (r.index = e.index),
                        (r.ref = e.ref),
                        r
                    );
                },
                createHostRootFiber: function () {
                    return new ee(eo, null, uo);
                },
                createFiberFromElement: function (e, t, r) {
                    return (t = te(e.type, e.key, t)), (t.pendingProps = e.props), (t.pendingWorkPriority = r), t;
                },
                createFiberFromFragment: function (e, t, r) {
                    return (t = new ee(io, null, t)), (t.pendingProps = e), (t.pendingWorkPriority = r), t;
                },
                createFiberFromText: function (e, t, r) {
                    return (t = new ee(ro, null, t)), (t.pendingProps = e), (t.pendingWorkPriority = r), t;
                },
                createFiberFromElementType: te,
                createFiberFromHostInstanceForDeletion: function () {
                    var e = new ee(to, null, uo);
                    return (e.type = "DELETED"), e;
                },
                createFiberFromCoroutine: function (e, t, r) {
                    return (t = new ee(oo, e.key, t)), (t.type = e.handler), (t.pendingProps = e), (t.pendingWorkPriority = r), t;
                },
                createFiberFromYield: function (e, t) {
                    return new ee(ao, null, t);
                },
                createFiberFromPortal: function (e, t, r) {
                    return (t = new ee(no, e.key, t)), (t.pendingProps = e.children || []), (t.pendingWorkPriority = r), (t.stateNode = { containerInfo: e.containerInfo, implementation: e.implementation }), t;
                },
                largerPriority: function (e, t) {
                    return e !== lo && (t === lo || t > e) ? e : t;
                },
            },
            po = co.createHostRootFiber,
            fo = Ut.IndeterminateComponent,
            _o = Ut.FunctionalComponent,
            ho = Ut.ClassComponent,
            bo = Ut.HostComponent;
        "function" == typeof Symbol && Symbol.for ? ((Pn = Symbol.for("react.coroutine")), (xn = Symbol.for("react.yield"))) : ((Pn = 60104), (xn = 60105));
        var mo = {
                createCoroutine: function (e, t, r) {
                    var n = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
                    return { $$typeof: Pn, key: null == n ? null : "" + n, children: e, handler: t, props: r };
                },
                createYield: function (e) {
                    return { $$typeof: xn, value: e };
                },
                isCoroutine: function (e) {
                    return "object" == typeof e && null !== e && e.$$typeof === Pn;
                },
                isYield: function (e) {
                    return "object" == typeof e && null !== e && e.$$typeof === xn;
                },
                REACT_YIELD_TYPE: xn,
                REACT_COROUTINE_TYPE: Pn,
            },
            go = ("function" == typeof Symbol && Symbol.for && Symbol.for("react.portal")) || 60106,
            vo = {
                createPortal: function (e, t, r) {
                    var n = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
                    return { $$typeof: go, key: null == n ? null : "" + n, children: e, containerInfo: t, implementation: r };
                },
                isPortal: function (e) {
                    return "object" == typeof e && null !== e && e.$$typeof === go;
                },
                REACT_PORTAL_TYPE: go,
            },
            yo = mo.REACT_COROUTINE_TYPE,
            Eo = mo.REACT_YIELD_TYPE,
            Co = vo.REACT_PORTAL_TYPE,
            ko = co.createWorkInProgress,
            Po = co.createFiberFromElement,
            xo = co.createFiberFromFragment,
            wo = co.createFiberFromText,
            Oo = co.createFiberFromCoroutine,
            Mo = co.createFiberFromYield,
            Do = co.createFiberFromPortal,
            To = Array.isArray,
            So = Ut.FunctionalComponent,
            Ro = Ut.ClassComponent,
            jo = Ut.HostText,
            Bo = Ut.HostPortal,
            Ao = Ut.CoroutineComponent,
            Uo = Ut.YieldComponent,
            Io = Ut.Fragment,
            Lo = Xt.NoEffect,
            Fo = Xt.Placement,
            No = Xt.Deletion,
            Wo = "function" == typeof Symbol && Symbol.iterator,
            Ho = ("function" == typeof Symbol && Symbol.for && Symbol.for("react.element")) || 60103,
            Ko = {
                reconcileChildFibers: ae(!0, !0),
                reconcileChildFibersInPlace: ae(!1, !0),
                mountChildFibersInPlace: ae(!1, !1),
                cloneChildFibers: function (e, t) {
                    if ((null !== e && t.child !== e.child && n("153"), null !== t.child)) {
                        e = t.child;
                        var r = ko(e, e.pendingWorkPriority);
                        for (r.pendingProps = e.pendingProps, t.child = r, r.return = t; null !== e.sibling; ) (e = e.sibling), (r = r.sibling = ko(e, e.pendingWorkPriority)), (r.pendingProps = e.pendingProps), (r.return = t);
                        r.sibling = null;
                    }
                },
            },
            zo = Xt.Update,
            qo = Zn.AsyncUpdates,
            Go = Xn.cacheContext,
            Vo = Xn.getMaskedContext,
            Yo = Xn.getUnmaskedContext,
            $o = Xn.isContextConsumer,
            Xo = In.addUpdate,
            Zo = In.addReplaceUpdate,
            Qo = In.addForceUpdate,
            Jo = In.beginUpdateQueue,
            ea = Xn.hasContextChanged,
            ta = nr.isMounted,
            ra = Ko.mountChildFibersInPlace,
            na = Ko.reconcileChildFibers,
            oa = Ko.reconcileChildFibersInPlace,
            aa = Ko.cloneChildFibers,
            ia = In.beginUpdateQueue,
            la = Xn.getMaskedContext,
            ua = Xn.getUnmaskedContext,
            sa = Xn.hasContextChanged,
            ca = Xn.pushContextProvider,
            pa = Xn.pushTopLevelContextObject,
            fa = Xn.invalidateContextProvider,
            da = Ut.IndeterminateComponent,
            _a = Ut.FunctionalComponent,
            ha = Ut.ClassComponent,
            ba = Ut.HostRoot,
            ma = Ut.HostComponent,
            ga = Ut.HostText,
            va = Ut.HostPortal,
            ya = Ut.CoroutineComponent,
            Ea = Ut.CoroutineHandlerPhase,
            Ca = Ut.YieldComponent,
            ka = Ut.Fragment,
            Pa = Mn.NoWork,
            xa = Mn.OffscreenPriority,
            wa = Xt.PerformedWork,
            Oa = Xt.Placement,
            Ma = Xt.ContentReset,
            Da = Xt.Err,
            Ta = Xt.Ref,
            Sa = $t.ReactCurrentOwner,
            Ra = Ko.reconcileChildFibers,
            ja = Xn.popContextProvider,
            Ba = Xn.popTopLevelContextObject,
            Aa = Ut.IndeterminateComponent,
            Ua = Ut.FunctionalComponent,
            Ia = Ut.ClassComponent,
            La = Ut.HostRoot,
            Fa = Ut.HostComponent,
            Na = Ut.HostText,
            Wa = Ut.HostPortal,
            Ha = Ut.CoroutineComponent,
            Ka = Ut.CoroutineHandlerPhase,
            za = Ut.YieldComponent,
            qa = Ut.Fragment,
            Ga = Xt.Placement,
            Va = Xt.Ref,
            Ya = Xt.Update,
            $a = Mn.OffscreenPriority,
            Xa = null,
            Za = null,
            Qa = {
                injectInternals: function (e) {
                    if ("undefined" == typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) return !1;
                    var t = __REACT_DEVTOOLS_GLOBAL_HOOK__;
                    if (!t.supportsFiber) return !0;
                    try {
                        var r = t.inject(e);
                        (Xa = se(function (e) {
                            return t.onCommitFiberRoot(r, e);
                        })),
                            (Za = se(function (e) {
                                return t.onCommitFiberUnmount(r, e);
                            }));
                    } catch (e) {}
                    return !0;
                },
                onCommitRoot: function (e) {
                    "function" == typeof Xa && Xa(e);
                },
                onCommitUnmount: function (e) {
                    "function" == typeof Za && Za(e);
                },
            },
            Ja = Ut.ClassComponent,
            ei = Ut.HostRoot,
            ti = Ut.HostComponent,
            ri = Ut.HostText,
            ni = Ut.HostPortal,
            oi = Ut.CoroutineComponent,
            ai = In.commitCallbacks,
            ii = Qa.onCommitUnmount,
            li = Xt.Placement,
            ui = Xt.Update,
            si = Xt.Callback,
            ci = Xt.ContentReset,
            pi = Nn.createCursor,
            fi = Nn.pop,
            di = Nn.push,
            _i = {},
            hi = Ut.HostComponent,
            bi = Ut.HostText,
            mi = Ut.HostRoot,
            gi = Xt.Deletion,
            vi = Xt.Placement,
            yi = co.createFiberFromHostInstanceForDeletion,
            Ei = Xn.popContextProvider,
            Ci = Nn.reset,
            ki = $t.ReactCurrentOwner,
            Pi = co.createWorkInProgress,
            xi = co.largerPriority,
            wi = Qa.onCommitRoot,
            Oi = Mn.NoWork,
            Mi = Mn.SynchronousPriority,
            Di = Mn.TaskPriority,
            Ti = Mn.HighPriority,
            Si = Mn.LowPriority,
            Ri = Mn.OffscreenPriority,
            ji = Zn.AsyncUpdates,
            Bi = Xt.PerformedWork,
            Ai = Xt.Placement,
            Ui = Xt.Update,
            Ii = Xt.PlacementAndUpdate,
            Li = Xt.Deletion,
            Fi = Xt.ContentReset,
            Ni = Xt.Callback,
            Wi = Xt.Err,
            Hi = Xt.Ref,
            Ki = Ut.HostRoot,
            zi = Ut.HostComponent,
            qi = Ut.HostPortal,
            Gi = Ut.ClassComponent,
            Vi = In.getUpdatePriority,
            Yi = Xn.resetContext;
        he._injectFiber = function (e) {
            _e = e;
        };
        var $i = In.addTopLevelUpdate,
            Xi = Xn.findCurrentUnmaskedContext,
            Zi = Xn.isContextProvider,
            Qi = Xn.processChildContext,
            Ji = Ut.HostComponent,
            el = nr.findCurrentHostFiber,
            tl = nr.findCurrentHostFiberWithNoPortals;
        he._injectFiber(function (e) {
            var t = Xi(e);
            return Zi(e) ? Qi(e, t, !1) : t;
        });
        var rl = It.TEXT_NODE,
            nl = null,
            ol = {
                getOffsets: function (e) {
                    var t = window.getSelection && window.getSelection();
                    if (!t || 0 === t.rangeCount) return null;
                    var r = t.anchorNode,
                        n = t.anchorOffset,
                        o = t.focusNode,
                        a = t.focusOffset,
                        i = t.getRangeAt(0);
                    try {
                        i.startContainer.nodeType, i.endContainer.nodeType;
                    } catch (e) {
                        return null;
                    }
                    t = t.anchorNode === t.focusNode && t.anchorOffset === t.focusOffset ? 0 : i.toString().length;
                    var l = i.cloneRange();
                    return (
                        l.selectNodeContents(e),
                        l.setEnd(i.startContainer, i.startOffset),
                        (e = l.startContainer === l.endContainer && l.startOffset === l.endOffset ? 0 : l.toString().length),
                        (i = e + t),
                        (t = document.createRange()).setStart(r, n),
                        t.setEnd(o, a),
                        (r = t.collapsed),
                        { start: r ? i : e, end: r ? e : i }
                    );
                },
                setOffsets: function (e, t) {
                    if (window.getSelection) {
                        var r = window.getSelection(),
                            n = e[ge()].length,
                            o = Math.min(t.start, n);
                        if (((t = void 0 === t.end ? o : Math.min(t.end, n)), !r.extend && o > t && ((n = t), (t = o), (o = n)), (n = me(e, o)), (e = me(e, t)), n && e)) {
                            var a = document.createRange();
                            a.setStart(n.node, n.offset), r.removeAllRanges(), o > t ? (r.addRange(a), r.extend(e.node, e.offset)) : (a.setEnd(e.node, e.offset), r.addRange(a));
                        }
                    }
                },
            },
            al = It.ELEMENT_NODE,
            il = {
                hasSelectionCapabilities: function (e) {
                    var t = e && e.nodeName && e.nodeName.toLowerCase();
                    return t && (("input" === t && "text" === e.type) || "textarea" === t || "true" === e.contentEditable);
                },
                getSelectionInformation: function () {
                    var e = Pt();
                    return { focusedElem: e, selectionRange: il.hasSelectionCapabilities(e) ? il.getSelection(e) : null };
                },
                restoreSelection: function (e) {
                    var t = Pt(),
                        r = e.focusedElem;
                    if (((e = e.selectionRange), t !== r && Ct(document.documentElement, r))) {
                        for (il.hasSelectionCapabilities(r) && il.setSelection(r, e), t = [], e = r; (e = e.parentNode); ) e.nodeType === al && t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
                        for (kt(r), r = 0; r < t.length; r++) (e = t[r]), (e.element.scrollLeft = e.left), (e.element.scrollTop = e.top);
                    }
                },
                getSelection: function (e) {
                    return ("selectionStart" in e ? { start: e.selectionStart, end: e.selectionEnd } : ol.getOffsets(e)) || { start: 0, end: 0 };
                },
                setSelection: function (e, t) {
                    var r = t.start,
                        n = t.end;
                    void 0 === n && (n = r), "selectionStart" in e ? ((e.selectionStart = r), (e.selectionEnd = Math.min(n, e.value.length))) : ol.setOffsets(e, t);
                },
            },
            ll = il,
            ul = It.ELEMENT_NODE;
        (Ee._injectFiber = function (e) {
            ve = e;
        }),
            (Ee._injectStack = function (e) {
                ye = e;
            });
        var sl = Ut.HostComponent,
            cl = {
                isAncestor: function (e, t) {
                    for (; t; ) {
                        if (e === t || e === t.alternate) return !0;
                        t = Ce(t);
                    }
                    return !1;
                },
                getLowestCommonAncestor: ke,
                getParentInstance: function (e) {
                    return Ce(e);
                },
                traverseTwoPhase: function (e, t, r) {
                    for (var n = []; e; ) n.push(e), (e = Ce(e));
                    for (e = n.length; 0 < e--; ) t(n[e], "captured", r);
                    for (e = 0; e < n.length; e++) t(n[e], "bubbled", r);
                },
                traverseEnterLeave: function (e, t, r, n, o) {
                    for (var a = e && t ? ke(e, t) : null, i = []; e && e !== a; ) i.push(e), (e = Ce(e));
                    for (e = []; t && t !== a; ) e.push(t), (t = Ce(t));
                    for (t = 0; t < i.length; t++) r(i[t], "bubbled", n);
                    for (t = e.length; 0 < t--; ) r(e[t], "captured", o);
                },
            },
            pl = yr.getListener,
            fl = {
                accumulateTwoPhaseDispatches: function (e) {
                    w(e, xe);
                },
                accumulateTwoPhaseDispatchesSkipTarget: function (e) {
                    w(e, we);
                },
                accumulateDirectDispatches: function (e) {
                    w(e, Me);
                },
                accumulateEnterLeaveDispatches: function (e, t, r, n) {
                    cl.traverseEnterLeave(r, n, Oe, e, t);
                },
            },
            dl = { _root: null, _startText: null, _fallbackText: null },
            _l = {
                initialize: function (e) {
                    return (dl._root = e), (dl._startText = _l.getText()), !0;
                },
                reset: function () {
                    (dl._root = null), (dl._startText = null), (dl._fallbackText = null);
                },
                getData: function () {
                    if (dl._fallbackText) return dl._fallbackText;
                    var e,
                        t,
                        r = dl._startText,
                        n = r.length,
                        o = _l.getText(),
                        a = o.length;
                    for (e = 0; e < n && r[e] === o[e]; e++);
                    var i = n - e;
                    for (t = 1; t <= i && r[n - t] === o[a - t]; t++);
                    return (dl._fallbackText = o.slice(e, 1 < t ? 1 - t : void 0)), dl._fallbackText;
                },
                getText: function () {
                    return "value" in dl._root ? dl._root.value : dl._root[ge()];
                },
            },
            hl = _l,
            bl = "dispatchConfig _targetInst nativeEvent isDefaultPrevented isPropagationStopped _dispatchListeners _dispatchInstances".split(" "),
            ml = {
                type: null,
                target: null,
                currentTarget: vt.thatReturnsNull,
                eventPhase: null,
                bubbles: null,
                cancelable: null,
                timeStamp: function (e) {
                    return e.timeStamp || Date.now();
                },
                defaultPrevented: null,
                isTrusted: null,
            };
        mt(De.prototype, {
            preventDefault: function () {
                this.defaultPrevented = !0;
                var e = this.nativeEvent;
                e && (e.preventDefault ? e.preventDefault() : "unknown" != typeof e.returnValue && (e.returnValue = !1), (this.isDefaultPrevented = vt.thatReturnsTrue));
            },
            stopPropagation: function () {
                var e = this.nativeEvent;
                e && (e.stopPropagation ? e.stopPropagation() : "unknown" != typeof e.cancelBubble && (e.cancelBubble = !0), (this.isPropagationStopped = vt.thatReturnsTrue));
            },
            persist: function () {
                this.isPersistent = vt.thatReturnsTrue;
            },
            isPersistent: vt.thatReturnsFalse,
            destructor: function () {
                var e,
                    t = this.constructor.Interface;
                for (e in t) this[e] = null;
                for (t = 0; t < bl.length; t++) this[bl[t]] = null;
            },
        }),
            (De.Interface = ml),
            (De.augmentClass = function (e, t) {
                function r() {}
                r.prototype = this.prototype;
                var n = new r();
                mt(n, e.prototype), (e.prototype = n), (e.prototype.constructor = e), (e.Interface = mt({}, this.Interface, t)), (e.augmentClass = this.augmentClass), Re(e);
            }),
            Re(De),
            De.augmentClass(je, { data: null }),
            De.augmentClass(Be, { data: null });
        var gl = [9, 13, 27, 32],
            vl = bt.canUseDOM && "CompositionEvent" in window,
            yl = null;
        bt.canUseDOM && "documentMode" in document && (yl = document.documentMode);
        var El;
        if ((El = bt.canUseDOM && "TextEvent" in window && !yl)) {
            var Cl = window.opera;
            El = !("object" == typeof Cl && "function" == typeof Cl.version && 12 >= parseInt(Cl.version(), 10));
        }
        var kl = El,
            Pl = bt.canUseDOM && (!vl || (yl && 8 < yl && 11 >= yl)),
            xl = String.fromCharCode(32),
            wl = {
                beforeInput: { phasedRegistrationNames: { bubbled: "onBeforeInput", captured: "onBeforeInputCapture" }, dependencies: ["topCompositionEnd", "topKeyPress", "topTextInput", "topPaste"] },
                compositionEnd: { phasedRegistrationNames: { bubbled: "onCompositionEnd", captured: "onCompositionEndCapture" }, dependencies: "topBlur topCompositionEnd topKeyDown topKeyPress topKeyUp topMouseDown".split(" ") },
                compositionStart: { phasedRegistrationNames: { bubbled: "onCompositionStart", captured: "onCompositionStartCapture" }, dependencies: "topBlur topCompositionStart topKeyDown topKeyPress topKeyUp topMouseDown".split(" ") },
                compositionUpdate: {
                    phasedRegistrationNames: { bubbled: "onCompositionUpdate", captured: "onCompositionUpdateCapture" },
                    dependencies: "topBlur topCompositionUpdate topKeyDown topKeyPress topKeyUp topMouseDown".split(" "),
                },
            },
            Ol = !1,
            Ml = !1,
            Dl = {
                eventTypes: wl,
                extractEvents: function (e, t, r, n) {
                    var o;
                    if (vl)
                        e: {
                            switch (e) {
                                case "topCompositionStart":
                                    var a = wl.compositionStart;
                                    break e;
                                case "topCompositionEnd":
                                    a = wl.compositionEnd;
                                    break e;
                                case "topCompositionUpdate":
                                    a = wl.compositionUpdate;
                                    break e;
                            }
                            a = void 0;
                        }
                    else Ml ? Ae(e, r) && (a = wl.compositionEnd) : "topKeyDown" === e && 229 === r.keyCode && (a = wl.compositionStart);
                    return (
                        a
                            ? (Pl && (Ml || a !== wl.compositionStart ? a === wl.compositionEnd && Ml && (o = hl.getData()) : (Ml = hl.initialize(n))),
                              (a = je.getPooled(a, t, r, n)),
                              o ? (a.data = o) : null !== (o = Ue(r)) && (a.data = o),
                              fl.accumulateTwoPhaseDispatches(a),
                              (o = a))
                            : (o = null),
                        (e = kl ? Ie(e, r) : Le(e, r)) ? ((t = Be.getPooled(wl.beforeInput, t, r, n)), (t.data = e), fl.accumulateTwoPhaseDispatches(t)) : (t = null),
                        [o, t]
                    );
                },
            },
            Tl = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 },
            Sl = { change: { phasedRegistrationNames: { bubbled: "onChange", captured: "onChangeCapture" }, dependencies: "topBlur topChange topClick topFocus topInput topKeyDown topKeyUp topSelectionChange".split(" ") } },
            Rl = null,
            jl = null,
            Bl = !1;
        bt.canUseDOM && (Bl = S("input") && (!document.documentMode || 9 < document.documentMode));
        var Al = {
            eventTypes: Sl,
            _isInputEventSupported: Bl,
            extractEvents: function (e, t, r, n) {
                var o = t ? Vt.getNodeFromInstance(t) : window,
                    a = o.nodeName && o.nodeName.toLowerCase();
                if ("select" === a || ("input" === a && "file" === o.type)) var i = Ke;
                else if (Fe(o))
                    if (Bl) i = $e;
                    else {
                        i = Ve;
                        var l = Ge;
                    }
                else !(a = o.nodeName) || "input" !== a.toLowerCase() || ("checkbox" !== o.type && "radio" !== o.type) || (i = Ye);
                if (i && (i = i(e, t))) return Ne(i, r, n);
                l && l(e, o, t), "topBlur" === e && null != t && (e = t._wrapperState || o._wrapperState) && e.controlled && "number" === o.type && ((e = "" + o.value), o.getAttribute("value") !== e && o.setAttribute("value", e));
            },
        };
        De.augmentClass(Xe, {
            view: function (e) {
                return e.view ? e.view : (e = k(e)).window === e ? e : (e = e.ownerDocument) ? e.defaultView || e.parentWindow : window;
            },
            detail: function (e) {
                return e.detail || 0;
            },
        });
        var Ul = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
        Xe.augmentClass(Je, {
            screenX: null,
            screenY: null,
            clientX: null,
            clientY: null,
            pageX: null,
            pageY: null,
            ctrlKey: null,
            shiftKey: null,
            altKey: null,
            metaKey: null,
            getModifierState: Qe,
            button: null,
            buttons: null,
            relatedTarget: function (e) {
                return e.relatedTarget || (e.fromElement === e.srcElement ? e.toElement : e.fromElement);
            },
        });
        var Il = { mouseEnter: { registrationName: "onMouseEnter", dependencies: ["topMouseOut", "topMouseOver"] }, mouseLeave: { registrationName: "onMouseLeave", dependencies: ["topMouseOut", "topMouseOver"] } },
            Ll = {
                eventTypes: Il,
                extractEvents: function (e, t, r, n) {
                    if (("topMouseOver" === e && (r.relatedTarget || r.fromElement)) || ("topMouseOut" !== e && "topMouseOver" !== e)) return null;
                    var o = n.window === n ? n : (o = n.ownerDocument) ? o.defaultView || o.parentWindow : window;
                    if (("topMouseOut" === e ? ((e = t), (t = (t = r.relatedTarget || r.toElement) ? Vt.getClosestInstanceFromNode(t) : null)) : (e = null), e === t)) return null;
                    var a = null == e ? o : Vt.getNodeFromInstance(e);
                    o = null == t ? o : Vt.getNodeFromInstance(t);
                    var i = Je.getPooled(Il.mouseLeave, e, r, n);
                    return (
                        (i.type = "mouseleave"),
                        (i.target = a),
                        (i.relatedTarget = o),
                        (r = Je.getPooled(Il.mouseEnter, t, r, n)),
                        (r.type = "mouseenter"),
                        (r.target = o),
                        (r.relatedTarget = a),
                        fl.accumulateEnterLeaveDispatches(i, r, e, t),
                        [i, r]
                    );
                },
            },
            Fl = It.DOCUMENT_NODE,
            Nl = bt.canUseDOM && "documentMode" in document && 11 >= document.documentMode,
            Wl = { select: { phasedRegistrationNames: { bubbled: "onSelect", captured: "onSelectCapture" }, dependencies: "topBlur topContextMenu topFocus topKeyDown topKeyUp topMouseDown topMouseUp topSelectionChange".split(" ") } },
            Hl = null,
            Kl = null,
            zl = null,
            ql = !1,
            Gl = Mr.isListeningToAllDependencies,
            Vl = {
                eventTypes: Wl,
                extractEvents: function (e, t, r, n) {
                    var o = n.window === n ? n.document : n.nodeType === Fl ? n : n.ownerDocument;
                    if (!o || !Gl("onSelect", o)) return null;
                    switch (((o = t ? Vt.getNodeFromInstance(t) : window), e)) {
                        case "topFocus":
                            (Fe(o) || "true" === o.contentEditable) && ((Hl = o), (Kl = t), (zl = null));
                            break;
                        case "topBlur":
                            zl = Kl = Hl = null;
                            break;
                        case "topMouseDown":
                            ql = !0;
                            break;
                        case "topContextMenu":
                        case "topMouseUp":
                            return (ql = !1), et(r, n);
                        case "topSelectionChange":
                            if (Nl) break;
                        case "topKeyDown":
                        case "topKeyUp":
                            return et(r, n);
                    }
                    return null;
                },
            };
        De.augmentClass(tt, { animationName: null, elapsedTime: null, pseudoElement: null }),
            De.augmentClass(rt, {
                clipboardData: function (e) {
                    return "clipboardData" in e ? e.clipboardData : window.clipboardData;
                },
            }),
            Xe.augmentClass(nt, { relatedTarget: null });
        var Yl = {
                Esc: "Escape",
                Spacebar: " ",
                Left: "ArrowLeft",
                Up: "ArrowUp",
                Right: "ArrowRight",
                Down: "ArrowDown",
                Del: "Delete",
                Win: "OS",
                Menu: "ContextMenu",
                Apps: "ContextMenu",
                Scroll: "ScrollLock",
                MozPrintableKey: "Unidentified",
            },
            $l = {
                8: "Backspace",
                9: "Tab",
                12: "Clear",
                13: "Enter",
                16: "Shift",
                17: "Control",
                18: "Alt",
                19: "Pause",
                20: "CapsLock",
                27: "Escape",
                32: " ",
                33: "PageUp",
                34: "PageDown",
                35: "End",
                36: "Home",
                37: "ArrowLeft",
                38: "ArrowUp",
                39: "ArrowRight",
                40: "ArrowDown",
                45: "Insert",
                46: "Delete",
                112: "F1",
                113: "F2",
                114: "F3",
                115: "F4",
                116: "F5",
                117: "F6",
                118: "F7",
                119: "F8",
                120: "F9",
                121: "F10",
                122: "F11",
                123: "F12",
                144: "NumLock",
                145: "ScrollLock",
                224: "Meta",
            };
        Xe.augmentClass(at, {
            key: function (e) {
                if (e.key) {
                    var t = Yl[e.key] || e.key;
                    if ("Unidentified" !== t) return t;
                }
                return "keypress" === e.type ? (13 === (e = ot(e)) ? "Enter" : String.fromCharCode(e)) : "keydown" === e.type || "keyup" === e.type ? $l[e.keyCode] || "Unidentified" : "";
            },
            location: null,
            ctrlKey: null,
            shiftKey: null,
            altKey: null,
            metaKey: null,
            repeat: null,
            locale: null,
            getModifierState: Qe,
            charCode: function (e) {
                return "keypress" === e.type ? ot(e) : 0;
            },
            keyCode: function (e) {
                return "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0;
            },
            which: function (e) {
                return "keypress" === e.type ? ot(e) : "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0;
            },
        }),
            Je.augmentClass(it, { dataTransfer: null }),
            Xe.augmentClass(lt, { touches: null, targetTouches: null, changedTouches: null, altKey: null, metaKey: null, ctrlKey: null, shiftKey: null, getModifierState: Qe }),
            De.augmentClass(ut, { propertyName: null, elapsedTime: null, pseudoElement: null }),
            Je.augmentClass(st, {
                deltaX: function (e) {
                    return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
                },
                deltaY: function (e) {
                    return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
                },
                deltaZ: null,
                deltaMode: null,
            });
        var Xl = {},
            Zl = {};
        "abort animationEnd animationIteration animationStart blur cancel canPlay canPlayThrough click close contextMenu copy cut doubleClick drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error focus input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing progress rateChange reset scroll seeked seeking stalled submit suspend timeUpdate toggle touchCancel touchEnd touchMove touchStart transitionEnd volumeChange waiting wheel"
            .split(" ")
            .forEach(function (e) {
                var t = e[0].toUpperCase() + e.slice(1),
                    r = "on" + t;
                (r = { phasedRegistrationNames: { bubbled: r, captured: r + "Capture" }, dependencies: [(t = "top" + t)] }), (Xl[e] = r), (Zl[t] = r);
            });
        var Ql = {
            eventTypes: Xl,
            extractEvents: function (e, t, r, o) {
                var a = Zl[e];
                if (!a) return null;
                switch (e) {
                    case "topAbort":
                    case "topCancel":
                    case "topCanPlay":
                    case "topCanPlayThrough":
                    case "topClose":
                    case "topDurationChange":
                    case "topEmptied":
                    case "topEncrypted":
                    case "topEnded":
                    case "topError":
                    case "topInput":
                    case "topInvalid":
                    case "topLoad":
                    case "topLoadedData":
                    case "topLoadedMetadata":
                    case "topLoadStart":
                    case "topPause":
                    case "topPlay":
                    case "topPlaying":
                    case "topProgress":
                    case "topRateChange":
                    case "topReset":
                    case "topSeeked":
                    case "topSeeking":
                    case "topStalled":
                    case "topSubmit":
                    case "topSuspend":
                    case "topTimeUpdate":
                    case "topToggle":
                    case "topVolumeChange":
                    case "topWaiting":
                        var i = De;
                        break;
                    case "topKeyPress":
                        if (0 === ot(r)) return null;
                    case "topKeyDown":
                    case "topKeyUp":
                        i = at;
                        break;
                    case "topBlur":
                    case "topFocus":
                        i = nt;
                        break;
                    case "topClick":
                        if (2 === r.button) return null;
                    case "topDoubleClick":
                    case "topMouseDown":
                    case "topMouseMove":
                    case "topMouseUp":
                    case "topMouseOut":
                    case "topMouseOver":
                    case "topContextMenu":
                        i = Je;
                        break;
                    case "topDrag":
                    case "topDragEnd":
                    case "topDragEnter":
                    case "topDragExit":
                    case "topDragLeave":
                    case "topDragOver":
                    case "topDragStart":
                    case "topDrop":
                        i = it;
                        break;
                    case "topTouchCancel":
                    case "topTouchEnd":
                    case "topTouchMove":
                    case "topTouchStart":
                        i = lt;
                        break;
                    case "topAnimationEnd":
                    case "topAnimationIteration":
                    case "topAnimationStart":
                        i = tt;
                        break;
                    case "topTransitionEnd":
                        i = ut;
                        break;
                    case "topScroll":
                        i = Xe;
                        break;
                    case "topWheel":
                        i = st;
                        break;
                    case "topCopy":
                    case "topCut":
                    case "topPaste":
                        i = rt;
                }
                return i || n("86", e), (e = i.getPooled(a, t, r, o)), fl.accumulateTwoPhaseDispatches(e), e;
            },
        };
        gr.setHandleTopLevel(Mr.handleTopLevel),
            yr.injection.injectEventPluginOrder("ResponderEventPlugin SimpleEventPlugin TapEventPlugin EnterLeaveEventPlugin ChangeEventPlugin SelectEventPlugin BeforeInputEventPlugin".split(" ")),
            lr.injection.injectComponentTree(Vt),
            yr.injection.injectEventPluginsByName({ SimpleEventPlugin: Ql, EnterLeaveEventPlugin: Ll, ChangeEventPlugin: Al, SelectEventPlugin: Vl, BeforeInputEventPlugin: Dl });
        var Jl = At.injection.MUST_USE_PROPERTY,
            eu = At.injection.HAS_BOOLEAN_VALUE,
            tu = At.injection.HAS_NUMERIC_VALUE,
            ru = At.injection.HAS_POSITIVE_NUMERIC_VALUE,
            nu = At.injection.HAS_STRING_BOOLEAN_VALUE,
            ou = {
                Properties: {
                    allowFullScreen: eu,
                    allowTransparency: nu,
                    async: eu,
                    autoPlay: eu,
                    capture: eu,
                    checked: Jl | eu,
                    cols: ru,
                    contentEditable: nu,
                    controls: eu,
                    default: eu,
                    defer: eu,
                    disabled: eu,
                    download: At.injection.HAS_OVERLOADED_BOOLEAN_VALUE,
                    draggable: nu,
                    formNoValidate: eu,
                    hidden: eu,
                    loop: eu,
                    multiple: Jl | eu,
                    muted: Jl | eu,
                    noValidate: eu,
                    open: eu,
                    playsInline: eu,
                    readOnly: eu,
                    required: eu,
                    reversed: eu,
                    rows: ru,
                    rowSpan: tu,
                    scoped: eu,
                    seamless: eu,
                    selected: Jl | eu,
                    size: ru,
                    start: tu,
                    span: ru,
                    spellCheck: nu,
                    style: 0,
                    itemScope: eu,
                    acceptCharset: 0,
                    className: 0,
                    htmlFor: 0,
                    httpEquiv: 0,
                    value: nu,
                },
                DOMAttributeNames: { acceptCharset: "accept-charset", className: "class", htmlFor: "for", httpEquiv: "http-equiv" },
                DOMMutationMethods: {
                    value: function (e, t) {
                        if (null == t) return e.removeAttribute("value");
                        "number" !== e.type || !1 === e.hasAttribute("value") ? e.setAttribute("value", "" + t) : e.validity && !e.validity.badInput && e.ownerDocument.activeElement !== e && e.setAttribute("value", "" + t);
                    },
                },
            },
            au = At.injection.HAS_STRING_BOOLEAN_VALUE,
            iu = { xlink: "http://www.w3.org/1999/xlink", xml: "http://www.w3.org/XML/1998/namespace" },
            lu = {
                Properties: { autoReverse: au, externalResourcesRequired: au, preserveAlpha: au },
                DOMAttributeNames: { autoReverse: "autoReverse", externalResourcesRequired: "externalResourcesRequired", preserveAlpha: "preserveAlpha" },
                DOMAttributeNamespaces: {
                    xlinkActuate: iu.xlink,
                    xlinkArcrole: iu.xlink,
                    xlinkHref: iu.xlink,
                    xlinkRole: iu.xlink,
                    xlinkShow: iu.xlink,
                    xlinkTitle: iu.xlink,
                    xlinkType: iu.xlink,
                    xmlBase: iu.xml,
                    xmlLang: iu.xml,
                    xmlSpace: iu.xml,
                },
            },
            uu = /[\-\:]([a-z])/g;
        "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode x-height xlink:actuate xlink:arcrole xlink:href xlink:role xlink:show xlink:title xlink:type xml:base xmlns:xlink xml:lang xml:space"
            .split(" ")
            .forEach(function (e) {
                var t = e.replace(uu, ct);
                (lu.Properties[t] = 0), (lu.DOMAttributeNames[t] = e);
            }),
            At.injection.injectDOMPropertyConfig(ou),
            At.injection.injectDOMPropertyConfig(lu);
        var su = Qa.injectInternals,
            cu = It.ELEMENT_NODE,
            pu = It.TEXT_NODE,
            fu = It.COMMENT_NODE,
            du = It.DOCUMENT_NODE,
            _u = It.DOCUMENT_FRAGMENT_NODE,
            hu = At.ROOT_ATTRIBUTE_NAME,
            bu = Ot.getChildNamespace,
            mu = fn.createElement,
            gu = fn.createTextNode,
            vu = fn.setInitialProperties,
            yu = fn.diffProperties,
            Eu = fn.updateProperties,
            Cu = fn.diffHydratedProperties,
            ku = fn.diffHydratedText,
            Pu = fn.warnForDeletedHydratableElement,
            xu = fn.warnForDeletedHydratableText,
            wu = fn.warnForInsertedHydratedElement,
            Ou = fn.warnForInsertedHydratedText,
            Mu = Vt.precacheFiberNode,
            Du = Vt.updateFiberProps;
        pr.injection.injectFiberControlledHostComponent(fn),
            Ee._injectFiber(function (e) {
                return Ru.findHostInstance(e);
            });
        var Tu = null,
            Su = null,
            Ru = (function (e) {
                var t = e.getPublicInstance,
                    r = (e = de(e)).scheduleUpdate,
                    n = e.getPriorityContext;
                return {
                    createContainer: function (e) {
                        var t = po();
                        return (e = { current: t, containerInfo: e, isScheduled: !1, nextScheduledRoot: null, context: null, pendingContext: null }), (t.stateNode = e);
                    },
                    updateContainer: function (e, t, o, a) {
                        var i = t.current;
                        (o = he(o)),
                            null === t.context ? (t.context = o) : (t.pendingContext = o),
                            (t = a),
                            (a = n(i, On.enableAsyncSubtreeAPI && null != e && null != e.type && null != e.type.prototype && !0 === e.type.prototype.unstable_isAsyncReactComponent)),
                            $i(i, (e = { element: e }), void 0 === t ? null : t, a),
                            r(i, a);
                    },
                    batchedUpdates: e.batchedUpdates,
                    unbatchedUpdates: e.unbatchedUpdates,
                    deferredUpdates: e.deferredUpdates,
                    flushSync: e.flushSync,
                    getPublicRootInstance: function (e) {
                        if (!(e = e.current).child) return null;
                        switch (e.child.tag) {
                            case Ji:
                                return t(e.child.stateNode);
                            default:
                                return e.child.stateNode;
                        }
                    },
                    findHostInstance: function (e) {
                        return null === (e = el(e)) ? null : e.stateNode;
                    },
                    findHostInstanceWithNoPortals: function (e) {
                        return null === (e = tl(e)) ? null : e.stateNode;
                    },
                };
            })({
                getRootHostContext: function (e) {
                    if (e.nodeType === du) e = (e = e.documentElement) ? e.namespaceURI : bu(null, "");
                    else {
                        var t = e.nodeType === fu ? e.parentNode : e;
                        (e = t.namespaceURI || null), (t = t.tagName), (e = bu(e, t));
                    }
                    return e;
                },
                getChildHostContext: function (e, t) {
                    return bu(e, t);
                },
                getPublicInstance: function (e) {
                    return e;
                },
                prepareForCommit: function () {
                    (Tu = Mr.isEnabled()), (Su = ll.getSelectionInformation()), Mr.setEnabled(!1);
                },
                resetAfterCommit: function () {
                    ll.restoreSelection(Su), (Su = null), Mr.setEnabled(Tu), (Tu = null);
                },
                createInstance: function (e, t, r, n, o) {
                    return (e = mu(e, t, r, n)), Mu(o, e), Du(e, t), e;
                },
                appendInitialChild: function (e, t) {
                    e.appendChild(t);
                },
                finalizeInitialChildren: function (e, t, r, n) {
                    vu(e, t, r, n);
                    e: {
                        switch (t) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                e = !!r.autoFocus;
                                break e;
                        }
                        e = !1;
                    }
                    return e;
                },
                prepareUpdate: function (e, t, r, n, o) {
                    return yu(e, t, r, n, o);
                },
                commitMount: function (e) {
                    e.focus();
                },
                commitUpdate: function (e, t, r, n, o) {
                    Du(e, o), Eu(e, t, r, n, o);
                },
                shouldSetTextContent: function (e, t) {
                    return (
                        "textarea" === e ||
                        "string" == typeof t.children ||
                        "number" == typeof t.children ||
                        ("object" == typeof t.dangerouslySetInnerHTML && null !== t.dangerouslySetInnerHTML && "string" == typeof t.dangerouslySetInnerHTML.__html)
                    );
                },
                resetTextContent: function (e) {
                    e.textContent = "";
                },
                shouldDeprioritizeSubtree: function (e, t) {
                    return !!t.hidden;
                },
                createTextInstance: function (e, t, r, n) {
                    return (e = gu(e, t)), Mu(n, e), e;
                },
                commitTextUpdate: function (e, t, r) {
                    e.nodeValue = r;
                },
                appendChild: function (e, t) {
                    e.appendChild(t);
                },
                appendChildToContainer: function (e, t) {
                    e.nodeType === fu ? e.parentNode.insertBefore(t, e) : e.appendChild(t);
                },
                insertBefore: function (e, t, r) {
                    e.insertBefore(t, r);
                },
                insertInContainerBefore: function (e, t, r) {
                    e.nodeType === fu ? e.parentNode.insertBefore(t, r) : e.insertBefore(t, r);
                },
                removeChild: function (e, t) {
                    e.removeChild(t);
                },
                removeChildFromContainer: function (e, t) {
                    e.nodeType === fu ? e.parentNode.removeChild(t) : e.removeChild(t);
                },
                canHydrateInstance: function (e, t) {
                    return e.nodeType === cu && t === e.nodeName.toLowerCase();
                },
                canHydrateTextInstance: function (e, t) {
                    return "" !== t && e.nodeType === pu;
                },
                getNextHydratableSibling: function (e) {
                    for (e = e.nextSibling; e && e.nodeType !== cu && e.nodeType !== pu; ) e = e.nextSibling;
                    return e;
                },
                getFirstHydratableChild: function (e) {
                    for (e = e.firstChild; e && e.nodeType !== cu && e.nodeType !== pu; ) e = e.nextSibling;
                    return e;
                },
                hydrateInstance: function (e, t, r, n, o, a) {
                    return Mu(a, e), Du(e, r), Cu(e, t, r, o, n);
                },
                hydrateTextInstance: function (e, t, r) {
                    return Mu(r, e), ku(e, t);
                },
                didNotHydrateInstance: function (e, t) {
                    1 === t.nodeType ? Pu(e, t) : xu(e, t);
                },
                didNotFindHydratableInstance: function (e, t, r) {
                    wu(e, t, r);
                },
                didNotFindHydratableTextInstance: function (e, t) {
                    Ou(e, t);
                },
                scheduleDeferredCallback: wn.rIC,
                useSyncScheduling: !0,
            });
        dr.injection.injectFiberBatchedUpdates(Ru.batchedUpdates);
        var ju = {
            createPortal: _t,
            hydrate: function (e, t, r) {
                return dt(null, e, t, !0, r);
            },
            render: function (e, t, r) {
                return dt(null, e, t, !1, r);
            },
            unstable_renderSubtreeIntoContainer: function (e, t, r, o) {
                return (null != e && Yt.has(e)) || n("38"), dt(e, t, r, !1, o);
            },
            unmountComponentAtNode: function (e) {
                return (
                    pt(e) || n("40"),
                    !!e._reactRootContainer &&
                        (Ru.unbatchedUpdates(function () {
                            dt(null, null, e, !1, function () {
                                e._reactRootContainer = null;
                            });
                        }),
                        !0)
                );
            },
            findDOMNode: Ee,
            unstable_createPortal: _t,
            unstable_batchedUpdates: dr.batchedUpdates,
            unstable_deferredUpdates: Ru.deferredUpdates,
            flushSync: Ru.flushSync,
            __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: { EventPluginHub: yr, EventPluginRegistry: St, EventPropagators: fl, ReactControlledComponent: pr, ReactDOMComponentTree: Vt, ReactDOMEventListener: gr },
        };
        su({ findFiberByHostInstance: Vt.getClosestInstanceFromNode, findHostInstanceByFiber: Ru.findHostInstance, bundleType: 0, version: "16.0.1", rendererPackageName: "react-dom" }), (e.exports = ju);
    },
    function (e, t, r) {
        "use strict";
        var n = !("undefined" == typeof window || !window.document || !window.document.createElement),
            o = { canUseDOM: n, canUseWorkers: "undefined" != typeof Worker, canUseEventListeners: n && !(!window.addEventListener && !window.attachEvent), canUseViewport: n && !!window.screen, isInWorker: !n };
        e.exports = o;
    },
    function (e, t, r) {
        "use strict";
        var n = r(46),
            o = {
                listen: function (e, t, r) {
                    return e.addEventListener
                        ? (e.addEventListener(t, r, !1),
                          {
                              remove: function () {
                                  e.removeEventListener(t, r, !1);
                              },
                          })
                        : e.attachEvent
                        ? (e.attachEvent("on" + t, r),
                          {
                              remove: function () {
                                  e.detachEvent("on" + t, r);
                              },
                          })
                        : void 0;
                },
                capture: function (e, t, r) {
                    return e.addEventListener
                        ? (e.addEventListener(t, r, !0),
                          {
                              remove: function () {
                                  e.removeEventListener(t, r, !0);
                              },
                          })
                        : { remove: n };
                },
                registerDefault: function () {},
            };
        e.exports = o;
    },
    function (e, t, r) {
        "use strict";
        var n = {};
        e.exports = n;
    },
    function (e, t, r) {
        "use strict";
        function n(e, t) {
            return e === t ? 0 !== e || 0 !== t || 1 / e == 1 / t : e !== e && t !== t;
        }
        var o = Object.prototype.hasOwnProperty;
        e.exports = function (e, t) {
            if (n(e, t)) return !0;
            if ("object" != typeof e || null === e || "object" != typeof t || null === t) return !1;
            var r = Object.keys(e),
                a = Object.keys(t);
            if (r.length !== a.length) return !1;
            for (var i = 0; i < r.length; i++) if (!o.call(t, r[i]) || !n(e[r[i]], t[r[i]])) return !1;
            return !0;
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e, t) {
            return !(!e || !t) && (e === t || (!o(e) && (o(t) ? n(e, t.parentNode) : "contains" in e ? e.contains(t) : !!e.compareDocumentPosition && !!(16 & e.compareDocumentPosition(t)))));
        }
        var o = r(144);
        e.exports = n;
    },
    function (e, t, r) {
        "use strict";
        var n = r(145);
        e.exports = function (e) {
            return n(e) && 3 == e.nodeType;
        };
    },
    function (e, t, r) {
        "use strict";
        e.exports = function (e) {
            var t = (e ? e.ownerDocument || e : document).defaultView || window;
            return !(!e || !("function" == typeof t.Node ? e instanceof t.Node : "object" == typeof e && "number" == typeof e.nodeType && "string" == typeof e.nodeName));
        };
    },
    function (e, t, r) {
        "use strict";
        e.exports = function (e) {
            try {
                e.focus();
            } catch (e) {}
        };
    },
    function (e, t, r) {
        "use strict";
        e.exports = function (e) {
            if (void 0 === (e = e || ("undefined" != typeof document ? document : void 0))) return null;
            try {
                return e.activeElement || e.body;
            } catch (t) {
                return e.body;
            }
        };
    },
    function (e, t, r) {
        "use strict";
        var n = r(46),
            o = r(67),
            a = r(149);
        e.exports = function () {
            function e(e, t, r, n, i, l) {
                l !== a && o(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
            }
            function t() {
                return e;
            }
            e.isRequired = e;
            var r = { array: e, bool: e, func: e, number: e, object: e, string: e, symbol: e, any: e, arrayOf: t, element: e, instanceOf: t, node: e, objectOf: t, oneOf: t, oneOfType: t, shape: t };
            return (r.checkPropTypes = n), (r.PropTypes = r), r;
        };
    },
    function (e, t, r) {
        "use strict";
        e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
    },
    function (e, t, r) {
        "use strict";
        (function (e, n) {
            Object.defineProperty(t, "__esModule", { value: !0 });
            var o,
                a = (function (e) {
                    return e && e.__esModule ? e : { default: e };
                })(r(151));
            o = "undefined" != typeof self ? self : "undefined" != typeof window ? window : void 0 !== e ? e : n;
            var i = (0, a.default)(o);
            t.default = i;
        }.call(this, r(47), r(22)(e)));
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.default = function (e) {
                var t,
                    r = e.Symbol;
                return "function" == typeof r ? (r.observable ? (t = r.observable) : ((t = r("observable")), (r.observable = t))) : (t = "@@observable"), t;
            });
    },
    function (e, t, r) {
        var n,
            o,
            a = r(71),
            i = r(72),
            l = 0,
            u = 0;
        e.exports = function (e, t, r) {
            var s = (t && r) || 0,
                c = t || [],
                p = (e = e || {}).node || n,
                f = void 0 !== e.clockseq ? e.clockseq : o;
            if (null == p || null == f) {
                var d = a();
                null == p && (p = n = [1 | d[0], d[1], d[2], d[3], d[4], d[5]]), null == f && (f = o = 16383 & ((d[6] << 8) | d[7]));
            }
            var _ = void 0 !== e.msecs ? e.msecs : new Date().getTime(),
                h = void 0 !== e.nsecs ? e.nsecs : u + 1,
                b = _ - l + (h - u) / 1e4;
            if ((b < 0 && void 0 === e.clockseq && (f = (f + 1) & 16383), (b < 0 || _ > l) && void 0 === e.nsecs && (h = 0), h >= 1e4)) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
            (l = _), (u = h), (o = f);
            var m = (1e4 * (268435455 & (_ += 122192928e5)) + h) % 4294967296;
            (c[s++] = (m >>> 24) & 255), (c[s++] = (m >>> 16) & 255), (c[s++] = (m >>> 8) & 255), (c[s++] = 255 & m);
            var g = ((_ / 4294967296) * 1e4) & 268435455;
            (c[s++] = (g >>> 8) & 255), (c[s++] = 255 & g), (c[s++] = ((g >>> 24) & 15) | 16), (c[s++] = (g >>> 16) & 255), (c[s++] = (f >>> 8) | 128), (c[s++] = 255 & f);
            for (var v = 0; v < 6; ++v) c[s + v] = p[v];
            return t || i(c);
        };
    },
    function (e, t, r) {
        var n = r(71),
            o = r(72);
        e.exports = function (e, t, r) {
            var a = (t && r) || 0;
            "string" == typeof e && ((t = "binary" === e ? new Array(16) : null), (e = null));
            var i = (e = e || {}).random || (e.rng || n)();
            if (((i[6] = (15 & i[6]) | 64), (i[8] = (63 & i[8]) | 128), t)) for (var l = 0; l < 16; ++l) t[a + l] = i[l];
            return t || o(i);
        };
    },
    function (e, t, r) {
        (function (e) {
            function t(e) {
                for (
                    var t = new THREE.BufferGeometry(),
                        r = new a(e.vertices.length, 0, THREE.Vector3, Float32Array, 3, ["x", "y", "z"]),
                        n = new a(e.faces.length, 0, THREE.Face3, Uint32Array, 3, ["a", "b", "c"]),
                        o = new a(3 * e.faceVertexUvs[0].length * 3, 0, THREE.Vector2, Float32Array, 2, ["x", "y"]),
                        i = 0,
                        l = e.vertices.length;
                    i < l;
                    i++
                )
                    r.push_element(e.vertices[i]);
                for (var i = 0, l = e.faces.length; i < l; i++) n.push_element(e.faces[i]);
                for (var i = 0, l = e.faceVertexUvs[0].length; i < l; i++) o.push_element(e.faceVertexUvs[0][i][0]), o.push_element(e.faceVertexUvs[0][i][1]), o.push_element(e.faceVertexUvs[0][i][2]);
                return (
                    n.trim_size(),
                    r.trim_size(),
                    o.trim_size(),
                    t.setIndex(new THREE.BufferAttribute(n.buffer, 3)),
                    t.addAttribute("position", new THREE.BufferAttribute(r.buffer, 3)),
                    t.addAttribute("uv", new THREE.BufferAttribute(o.buffer, 2)),
                    t
                );
            }
            function n(e) {
                var t = ["a", "b", "c"],
                    r = ["x", "y", "z"],
                    n = new a(0, 5, THREE.Vector3, Float32Array, 3, r),
                    o = new a(0, 3, THREE.Face3, Uint32Array, 3, t);
                n.from_existing(e.getAttribute("position").array);
                var i = new a(3 * n.length, 4, THREE.Vector3, Float32Array, 3, r),
                    l = new a(
                        n.length,
                        1,
                        function () {
                            this.x = 0;
                        },
                        Float32Array,
                        1,
                        ["x"]
                    );
                (i.length = n.length), o.from_existing(e.index.array);
                for (var u, s = [0, 0, 0], c = 0, p = o.length; c < p; c++)
                    o.index_to_register(c, 0),
                        n.index_to_register(o.register[0].a, 0),
                        n.index_to_register(o.register[0].b, 1),
                        n.index_to_register(o.register[0].c, 2),
                        i.register[0].subVectors(n.register[1], n.register[0]),
                        i.register[1].subVectors(n.register[2], n.register[1]),
                        i.register[0].cross(i.register[1]),
                        (u = Math.abs(i.register[0].length())),
                        (l.buffer[o.register[0].a] += u),
                        (l.buffer[o.register[0].b] += u),
                        (l.buffer[o.register[0].c] += u);
                for (var c = 0, p = o.length; c < p; c++)
                    o.index_to_register(c, 0),
                        n.index_to_register(o.register[0].a, 0),
                        n.index_to_register(o.register[0].b, 1),
                        n.index_to_register(o.register[0].c, 2),
                        i.register[0].subVectors(n.register[1], n.register[0]),
                        i.register[1].subVectors(n.register[2], n.register[0]),
                        i.register[3].set(0, 0, 0),
                        (i.register[3].x = i.register[0].y * i.register[1].z - i.register[0].z * i.register[1].y),
                        (i.register[3].y = i.register[0].z * i.register[1].x - i.register[0].x * i.register[1].z),
                        (i.register[3].z = i.register[0].x * i.register[1].y - i.register[0].y * i.register[1].x),
                        i.register[0].cross(i.register[1]),
                        (u = Math.abs(i.register[0].length())),
                        (s[0] = u / l.buffer[o.register[0].a]),
                        (s[1] = u / l.buffer[o.register[0].b]),
                        (s[2] = u / l.buffer[o.register[0].c]),
                        (i.buffer[3 * o.register[0].a + 0] += i.register[3].x * s[0]),
                        (i.buffer[3 * o.register[0].a + 1] += i.register[3].y * s[0]),
                        (i.buffer[3 * o.register[0].a + 2] += i.register[3].z * s[0]),
                        (i.buffer[3 * o.register[0].b + 0] += i.register[3].x * s[1]),
                        (i.buffer[3 * o.register[0].b + 1] += i.register[3].y * s[1]),
                        (i.buffer[3 * o.register[0].b + 2] += i.register[3].z * s[1]),
                        (i.buffer[3 * o.register[0].c + 0] += i.register[3].x * s[2]),
                        (i.buffer[3 * o.register[0].c + 1] += i.register[3].y * s[2]),
                        (i.buffer[3 * o.register[0].c + 2] += i.register[3].z * s[2]);
                i.trim_size(), e.addAttribute("normal", new THREE.BufferAttribute(i.buffer, 3));
            }
            function o(e) {
                var t = ["a", "b", "c"],
                    r = ["x", "y", "z"],
                    o = ["x", "y"],
                    i = new a(0, 3, THREE.Vector3, Float32Array, 3, r),
                    l = new a(0, 3, THREE.Face3, Uint32Array, 3, t),
                    u = new a(0, 3, THREE.Vector2, Float32Array, 2, o),
                    s = new a(0, 3, THREE.Vector3, Float32Array, 3, r);
                i.from_existing(e.getAttribute("position").array), l.from_existing(e.index.array), u.from_existing(e.getAttribute("uv").array), n(e), s.from_existing(e.getAttribute("normal").array);
                for (
                    var c = new a(3 * l.length, 3, THREE.Vector3, Float32Array, 3, r), p = new a(3 * l.length, 3, THREE.Vector3, Float32Array, 3, r), f = new a(3 * l.length, 3, THREE.Vector2, Float32Array, 2, o), d = 0, _ = l.length;
                    d < _;
                    d++
                )
                    l.index_to_register(d, 0),
                        i.index_to_register(l.register[0].a, 0),
                        i.index_to_register(l.register[0].b, 1),
                        i.index_to_register(l.register[0].c, 2),
                        c.push_element(i.register[0]),
                        c.push_element(i.register[1]),
                        c.push_element(i.register[2]),
                        0 !== u.length &&
                            (u.index_to_register(3 * d + 0, 0), u.index_to_register(3 * d + 1, 1), u.index_to_register(3 * d + 2, 2), f.push_element(u.register[0]), f.push_element(u.register[1]), f.push_element(u.register[2])),
                        s.index_to_register(l.register[0].a, 0),
                        s.index_to_register(l.register[0].b, 1),
                        s.index_to_register(l.register[0].c, 2),
                        p.push_element(s.register[0]),
                        p.push_element(s.register[1]),
                        p.push_element(s.register[2]);
                return (
                    c.trim_size(),
                    f.trim_size(),
                    p.trim_size(),
                    (e.index = null),
                    e.addAttribute("position", new THREE.BufferAttribute(c.buffer, 3)),
                    e.addAttribute("normal", new THREE.BufferAttribute(p.buffer, 3)),
                    0 !== f.length && e.addAttribute("uv", new THREE.BufferAttribute(f.buffer, 2)),
                    e
                );
            }
            !(function () {
                var t = r(1).enterModule;
                t && t(e);
            })(),
                (function () {
                    var t = r(1).enterModule;
                    t && t(e);
                })(),
                (THREE.Face3.prototype.set = function (e, t, r) {
                    (this.a = e), (this.b = t), (this.c = r);
                });
            var a = function (e, t, r, n, o, a) {
                (this.array_type = n), (this.register_type = r), (this.unit_size = o), (this.accessors = a), (this.buffer = new n(e * o)), (this.register = []), (this.length = 0), (this.real_length = e), (this.available_registers = t);
                for (var i = 0; i < t; i++) this.register.push(new r());
            };
            (a.prototype = {
                constructor: a,
                index_to_register: function (e, t, r) {
                    var n = e * this.unit_size;
                    if (t >= this.available_registers) throw new Error("THREE.BufferSubdivisionModifier: Not enough registers in TypedArrayHelper.");
                    if (e > this.length) throw new Error("THREE.BufferSubdivisionModifier: Index is out of range in TypedArrayHelper.");
                    for (var o = 0; o < this.unit_size; o++) this.register[t][this.accessors[o]] = this.buffer[n + o];
                },
                resize: function (e) {
                    if ((0 === e && (e = 8), e < this.length)) this.buffer = this.buffer.subarray(0, this.length * this.unit_size);
                    else {
                        var t;
                        this.buffer.length < e * this.unit_size
                            ? ((t = new this.array_type(e * this.unit_size)).set(this.buffer), (this.buffer = t), (this.real_length = e))
                            : ((t = new this.array_type(e * this.unit_size)).set(this.buffer.subarray(0, this.length * this.unit_size)), (this.buffer = t), (this.real_length = e));
                    }
                },
                from_existing: function (e) {
                    var t = e.length;
                    (this.buffer = new this.array_type(t)), this.buffer.set(e), (this.length = e.length / this.unit_size), (this.real_length = this.length);
                },
                push_element: function (e) {
                    this.length + 1 > this.real_length && this.resize(2 * this.real_length);
                    for (var t = this.length * this.unit_size, r = 0; r < this.unit_size; r++) this.buffer[t + r] = e[this.accessors[r]];
                    this.length++;
                },
                trim_size: function () {
                    this.length < this.real_length && this.resize(this.length);
                },
            }),
                (THREE.BufferSubdivisionModifier = function (e) {
                    this.subdivisions = void 0 === e ? 1 : e;
                }),
                (THREE.BufferSubdivisionModifier.prototype.modify = function (e) {
                    e instanceof THREE.Geometry
                        ? (e.mergeVertices(), void 0 === e.normals && (e.normals = []), (e = t(e)))
                        : e instanceof THREE.BufferGeometry || console.error("THREE.BufferSubdivisionModifier: Geometry is not an instance of THREE.BufferGeometry or THREE.Geometry");
                    for (var r = this.subdivisions; r-- > 0; ) this.smooth(e);
                    return o(e);
                });
            var i = function (e, t) {
                (this.a = e), (this.b = t), (this.faces = []), (this.newEdge = null);
            };
            !(function () {
                function e(e, t, r) {
                    return r[Math.min(e, t) + "_" + Math.max(e, t)];
                }
                function t(e, t, r, n, o, a) {
                    var l,
                        u = Math.min(e, t),
                        s = Math.max(e, t),
                        c = u + "_" + s;
                    c in n ? (l = n[c]) : ((l = new i(u, s)), (n[c] = l)), l.faces.push(o), a[e].edges.push(l), a[t].edges.push(l);
                }
                function r(e, r, n, o) {
                    var a, i, l;
                    for (a = 0, i = e.length; a < i; a++) n[a] = { edges: [] };
                    for (a = 0, i = r.length; a < i; a++) r.index_to_register(a, 0), t((l = r.register[0]).a, l.b, e, o, a, n), t(l.b, l.c, e, o, a, n), t(l.c, l.a, e, o, a, n);
                }
                function n(e, t) {
                    e.push_element(t);
                }
                function o(e, t) {
                    return Math.abs(t - e) / 2 + Math.min(e, t);
                }
                function l(e, t, r, n) {
                    e.push_element(t), e.push_element(r), e.push_element(n);
                }
                var u = ["a", "b", "c"],
                    s = ["x", "y", "z"],
                    c = ["x", "y"];
                THREE.BufferSubdivisionModifier.prototype.smooth = function (t) {
                    var i, p, f, d, _, h, b, m, g, v, y, E, C;
                    (i = new a(0, 3, THREE.Vector3, Float32Array, 3, s)),
                        (p = new a(0, 3, THREE.Face3, Uint32Array, 3, u)),
                        (f = new a(0, 3, THREE.Vector2, Float32Array, 2, c)),
                        i.from_existing(t.getAttribute("position").array),
                        p.from_existing(t.index.array),
                        f.from_existing(t.getAttribute("uv").array);
                    var k = !1;
                    void 0 !== f && 0 !== f.length && (k = !0), r(i, p, (E = new Array(i.length)), (C = {}));
                    var P,
                        x,
                        w,
                        O,
                        M,
                        D,
                        T,
                        S = (d = new a((2 * t.getAttribute("position").array.length) / 3, 2, THREE.Vector3, Float32Array, 3, s)).register[1];
                    for (m in C) {
                        for (
                            x = C[m],
                                w = d.register[0],
                                M = 3 / 8,
                                D = 1 / 8,
                                2 !== (T = x.faces.length) && ((M = 0.5), (D = 0)),
                                i.index_to_register(x.a, 0),
                                i.index_to_register(x.b, 1),
                                w.addVectors(i.register[0], i.register[1]).multiplyScalar(M),
                                S.set(0, 0, 0),
                                v = 0;
                            v < T;
                            v++
                        ) {
                            for (p.index_to_register(x.faces[v], 0), O = p.register[0], y = 0; y < 3 && (i.index_to_register(O[u[y]], 2), (P = i.register[2]), O[u[y]] === x.a || O[u[y]] === x.b); y++);
                            S.add(P);
                        }
                        S.multiplyScalar(D), w.add(S), (x.newEdge = d.length), d.push_element(w);
                    }
                    var R,
                        j,
                        B,
                        A,
                        U,
                        I,
                        L,
                        F = d.length;
                    for (m = 0, g = i.length; m < g; m++) {
                        for (
                            i.index_to_register(m, 0, s),
                                I = i.register[0],
                                3 === (b = (U = E[m].edges).length) ? (R = 3 / 16) : b > 3 && (R = 3 / (8 * b)),
                                j = 1 - b * R,
                                B = R,
                                b <= 2 && 2 === b && ((j = 0.75), (B = 1 / 8)),
                                L = I.multiplyScalar(j),
                                S.set(0, 0, 0),
                                v = 0;
                            v < b;
                            v++
                        )
                            (P = (A = U[v]).a !== m ? A.a : A.b), i.index_to_register(P, 1, s), S.add(i.register[1]);
                        S.multiplyScalar(B), L.add(S), d.push_element(L, s);
                    }
                    var N, W, H;
                    _ = new a((4 * t.index.array.length) / 3, 1, THREE.Face3, Float32Array, 3, u);
                    var K = (h = new a((4 * t.getAttribute("uv").array.length) / 2, 3, THREE.Vector2, Float32Array, 2, c)).register[0],
                        z = h.register[1],
                        q = h.register[2],
                        G = _.register[0];
                    for (m = 0, g = p.length; m < g; m++)
                        if (
                            (p.index_to_register(m, 0),
                            (O = p.register[0]),
                            (N = e(O.a, O.b, C).newEdge),
                            (W = e(O.b, O.c, C).newEdge),
                            (H = e(O.c, O.a, C).newEdge),
                            G.set(N, W, H),
                            n(_, G),
                            G.set(O.a + F, N, H),
                            n(_, G),
                            G.set(O.b + F, W, N),
                            n(_, G),
                            G.set(O.c + F, H, W),
                            n(_, G),
                            !0 === k)
                        ) {
                            f.index_to_register(3 * m + 0, 0), f.index_to_register(3 * m + 1, 1), f.index_to_register(3 * m + 2, 2);
                            var V = f.register[0],
                                Y = f.register[1],
                                $ = f.register[2];
                            K.set(o(V.x, Y.x), o(V.y, Y.y)), z.set(o(Y.x, $.x), o(Y.y, $.y)), q.set(o(V.x, $.x), o(V.y, $.y)), l(h, K, z, q), l(h, V, K, q), l(h, Y, z, K), l(h, $, q, z);
                        }
                    _.trim_size(),
                        d.trim_size(),
                        h.trim_size(),
                        t.setIndex(new THREE.BufferAttribute(_.buffer, 3)),
                        t.addAttribute("position", new THREE.BufferAttribute(d.buffer, 3)),
                        t.addAttribute("uv", new THREE.BufferAttribute(h.buffer, 2));
                };
            })(),
                (function () {
                    var l = r(1).default,
                        u = r(1).leaveModule;
                    l &&
                        (l.register(a, "TypedArrayHelper", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(t, "convertGeometryToIndexedBuffer", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(n, "compute_vertex_normals", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(o, "unIndexIndexedGeometry", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(i, "edge_type", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        u(e));
                })(),
                (function () {
                    var l = r(1).default,
                        u = r(1).leaveModule;
                    l &&
                        (l.register(a, "TypedArrayHelper", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(t, "convertGeometryToIndexedBuffer", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(n, "compute_vertex_normals", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(o, "unIndexIndexedGeometry", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        l.register(i, "edge_type", "/Users/nick/Documents/Programming/repos/brick-builder/app/utils/threejs/BufferSubdivisionModifier.js"),
                        u(e));
                })();
        }.call(this, r(22)(e)));
    },
    function (e, t) {
        e.exports = function (e) {
            function t(t, r) {
                function n() {
                    return ((2 * Math.PI) / 60 / 60) * B.autoRotateSpeed;
                }
                function o() {
                    return Math.pow(0.95, B.zoomSpeed);
                }
                function a(e) {
                    H.theta -= e;
                }
                function i(e) {
                    H.phi -= e;
                }
                function l(t) {
                    B.object instanceof e.PerspectiveCamera
                        ? (K /= t)
                        : B.object instanceof e.OrthographicCamera
                        ? ((B.object.zoom = Math.max(B.minZoom, Math.min(B.maxZoom, B.object.zoom * t))), B.object.updateProjectionMatrix(), (q = !0))
                        : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), (B.enableZoom = !1));
                }
                function u(t) {
                    B.object instanceof e.PerspectiveCamera
                        ? (K *= t)
                        : B.object instanceof e.OrthographicCamera
                        ? ((B.object.zoom = Math.max(B.minZoom, Math.min(B.maxZoom, B.object.zoom / t))), B.object.updateProjectionMatrix(), (q = !0))
                        : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), (B.enableZoom = !1));
                }
                function s(e) {
                    G.set(e.clientX, e.clientY);
                }
                function c(e) {
                    Q.set(e.clientX, e.clientY);
                }
                function p(e) {
                    $.set(e.clientX, e.clientY);
                }
                function f(e) {
                    V.set(e.clientX, e.clientY), Y.subVectors(V, G);
                    var t = B.domElement === document ? B.domElement.body : B.domElement;
                    a(((2 * Math.PI * Y.x) / t.clientWidth) * B.rotateSpeed), i(((2 * Math.PI * Y.y) / t.clientHeight) * B.rotateSpeed), G.copy(V), B.update();
                }
                function d(e) {
                    J.set(e.clientX, e.clientY), ee.subVectors(J, Q), ee.y > 0 ? l(o()) : ee.y < 0 && u(o()), Q.copy(J), B.update();
                }
                function _(e) {
                    X.set(e.clientX, e.clientY), Z.subVectors(X, $), ne(Z.x, Z.y), $.copy(X), B.update();
                }
                function h(e) {}
                function b(e) {
                    e.deltaY < 0 ? u(o()) : e.deltaY > 0 && l(o()), B.update();
                }
                function m(e) {
                    switch (e.keyCode) {
                        case B.keys.UP:
                            ne(0, B.keyPanSpeed), B.update();
                            break;
                        case B.keys.BOTTOM:
                            ne(0, -B.keyPanSpeed), B.update();
                            break;
                        case B.keys.LEFT:
                            ne(B.keyPanSpeed, 0), B.update();
                            break;
                        case B.keys.RIGHT:
                            ne(-B.keyPanSpeed, 0), B.update();
                    }
                }
                function g(e) {
                    G.set(e.touches[0].pageX, e.touches[0].pageY);
                }
                function v(e) {
                    var t = e.touches[0].pageX - e.touches[1].pageX,
                        r = e.touches[0].pageY - e.touches[1].pageY,
                        n = Math.sqrt(t * t + r * r);
                    Q.set(0, n);
                }
                function y(e) {
                    $.set(e.touches[0].pageX, e.touches[0].pageY);
                }
                function E(e) {
                    V.set(e.touches[0].pageX, e.touches[0].pageY), Y.subVectors(V, G);
                    var t = B.domElement === document ? B.domElement.body : B.domElement;
                    a(((2 * Math.PI * Y.x) / t.clientWidth) * B.rotateSpeed), i(((2 * Math.PI * Y.y) / t.clientHeight) * B.rotateSpeed), G.copy(V), B.update();
                }
                function C(e) {
                    var t = e.touches[0].pageX - e.touches[1].pageX,
                        r = e.touches[0].pageY - e.touches[1].pageY,
                        n = Math.sqrt(t * t + r * r);
                    J.set(0, n), ee.subVectors(J, Q), ee.y > 0 ? u(o()) : ee.y < 0 && l(o()), Q.copy(J), B.update();
                }
                function k(e) {
                    X.set(e.touches[0].pageX, e.touches[0].pageY), Z.subVectors(X, $), ne(Z.x, Z.y), $.copy(X), B.update();
                }
                function P(e) {}
                function x(e) {
                    if (!1 !== B.enabled) {
                        if ((e.preventDefault(), e.button === B.mouseButtons.PAN || (e.button === B.mouseButtons.ORBIT && e.shiftKey))) {
                            if (!1 === B.enablePan) return;
                            p(e), (F = L.PAN);
                        } else if (e.button === B.mouseButtons.ZOOM) {
                            if (!1 === B.enableZoom) return;
                            c(e), (F = L.DOLLY);
                        } else if (e.button === B.mouseButtons.ORBIT) {
                            if (!1 === B.enableRotate) return;
                            s(e), (F = L.ROTATE);
                        }
                        F !== L.NONE && (document.addEventListener("mousemove", w, !1), document.addEventListener("mouseup", O, !1), B.dispatchEvent(U));
                    }
                }
                function w(e) {
                    if (!1 !== B.enabled)
                        if ((e.preventDefault(), F === L.ROTATE)) {
                            if (!1 === B.enableRotate) return;
                            f(e);
                        } else if (F === L.DOLLY) {
                            if (!1 === B.enableZoom) return;
                            d(e);
                        } else if (F === L.PAN) {
                            if (!1 === B.enablePan) return;
                            _(e);
                        }
                }
                function O(e) {
                    !1 !== B.enabled && (h(e), document.removeEventListener("mousemove", w, !1), document.removeEventListener("mouseup", O, !1), B.dispatchEvent(I), (F = L.NONE));
                }
                function M(e) {
                    !1 === B.enabled || !1 === B.enableZoom || (F !== L.NONE && F !== L.ROTATE) || (e.preventDefault(), e.stopPropagation(), b(e), B.dispatchEvent(U), B.dispatchEvent(I));
                }
                function D(e) {
                    !1 !== B.enabled && !1 !== B.enableKeys && !1 !== B.enablePan && m(e);
                }
                function T(e) {
                    if (!1 !== B.enabled) {
                        switch (e.touches.length) {
                            case 1:
                                if (!1 === B.enableRotate) return;
                                g(e), (F = L.TOUCH_ROTATE);
                                break;
                            case 2:
                                if (!1 === B.enableZoom) return;
                                v(e), (F = L.TOUCH_DOLLY);
                                break;
                            case 3:
                                if (!1 === B.enablePan) return;
                                y(e), (F = L.TOUCH_PAN);
                                break;
                            default:
                                F = L.NONE;
                        }
                        F !== L.NONE && B.dispatchEvent(U);
                    }
                }
                function S(e) {
                    if (!1 !== B.enabled)
                        switch ((e.preventDefault(), e.stopPropagation(), e.touches.length)) {
                            case 1:
                                if (!1 === B.enableRotate) return;
                                if (F !== L.TOUCH_ROTATE) return;
                                E(e);
                                break;
                            case 2:
                                if (!1 === B.enableZoom) return;
                                if (F !== L.TOUCH_DOLLY) return;
                                C(e);
                                break;
                            case 3:
                                if (!1 === B.enablePan) return;
                                if (F !== L.TOUCH_PAN) return;
                                k(e);
                                break;
                            default:
                                F = L.NONE;
                        }
                }
                function R(e) {
                    !1 !== B.enabled && (P(e), B.dispatchEvent(I), (F = L.NONE));
                }
                function j(e) {
                    e.preventDefault();
                }
                (this.object = t),
                    (this.domElement = void 0 !== r ? r : document),
                    (this.enabled = !0),
                    (this.target = new e.Vector3()),
                    (this.minDistance = 0),
                    (this.maxDistance = 1 / 0),
                    (this.minZoom = 0),
                    (this.maxZoom = 1 / 0),
                    (this.minPolarAngle = 0),
                    (this.maxPolarAngle = Math.PI),
                    (this.minAzimuthAngle = -1 / 0),
                    (this.maxAzimuthAngle = 1 / 0),
                    (this.enableDamping = !1),
                    (this.dampingFactor = 0.25),
                    (this.enableZoom = !0),
                    (this.zoomSpeed = 1),
                    (this.enableRotate = !0),
                    (this.rotateSpeed = 1),
                    (this.enablePan = !0),
                    (this.keyPanSpeed = 20),
                    (this.autoRotate = !1),
                    (this.autoRotateSpeed = 2),
                    (this.enableKeys = !0),
                    (this.keys = { LEFT: 37, UP: 38, RIGHT: 39, BOTTOM: 40 }),
                    (this.mouseButtons = { ORBIT: e.MOUSE.LEFT, ZOOM: e.MOUSE.MIDDLE, PAN: e.MOUSE.RIGHT }),
                    (this.target0 = this.target.clone()),
                    (this.position0 = this.object.position.clone()),
                    (this.zoom0 = this.object.zoom),
                    (this.getPolarAngle = function () {
                        return W.phi;
                    }),
                    (this.getAzimuthalAngle = function () {
                        return W.theta;
                    }),
                    (this.reset = function () {
                        B.target.copy(B.target0), B.object.position.copy(B.position0), (B.object.zoom = B.zoom0), B.object.updateProjectionMatrix(), B.dispatchEvent(A), B.update(), (F = L.NONE);
                    }),
                    (this.update = (function () {
                        var r = new e.Vector3(),
                            o = new e.Quaternion().setFromUnitVectors(t.up, new e.Vector3(0, 1, 0)),
                            i = o.clone().inverse(),
                            l = new e.Vector3(),
                            u = new e.Quaternion();
                        return function () {
                            var e = B.object.position;
                            return (
                                r.copy(e).sub(B.target),
                                r.applyQuaternion(o),
                                W.setFromVector3(r),
                                B.autoRotate && F === L.NONE && a(n()),
                                (W.theta += H.theta),
                                (W.phi += H.phi),
                                (W.theta = Math.max(B.minAzimuthAngle, Math.min(B.maxAzimuthAngle, W.theta))),
                                (W.phi = Math.max(B.minPolarAngle, Math.min(B.maxPolarAngle, W.phi))),
                                W.makeSafe(),
                                (W.radius *= K),
                                (W.radius = Math.max(B.minDistance, Math.min(B.maxDistance, W.radius))),
                                B.target.add(z),
                                r.setFromSpherical(W),
                                r.applyQuaternion(i),
                                e.copy(B.target).add(r),
                                B.object.lookAt(B.target),
                                !0 === B.enableDamping ? ((H.theta *= 1 - B.dampingFactor), (H.phi *= 1 - B.dampingFactor)) : H.set(0, 0, 0),
                                (K = 1),
                                z.set(0, 0, 0),
                                !!(q || l.distanceToSquared(B.object.position) > N || 8 * (1 - u.dot(B.object.quaternion)) > N) && (B.dispatchEvent(A), l.copy(B.object.position), u.copy(B.object.quaternion), (q = !1), !0)
                            );
                        };
                    })()),
                    (this.dispose = function () {
                        B.domElement.removeEventListener("contextmenu", j, !1),
                            B.domElement.removeEventListener("mousedown", x, !1),
                            B.domElement.removeEventListener("wheel", M, !1),
                            B.domElement.removeEventListener("touchstart", T, !1),
                            B.domElement.removeEventListener("touchend", R, !1),
                            B.domElement.removeEventListener("touchmove", S, !1),
                            document.removeEventListener("mousemove", w, !1),
                            document.removeEventListener("mouseup", O, !1),
                            window.removeEventListener("keydown", D, !1);
                    });
                var B = this,
                    A = { type: "change" },
                    U = { type: "start" },
                    I = { type: "end" },
                    L = { NONE: -1, ROTATE: 0, DOLLY: 1, PAN: 2, TOUCH_ROTATE: 3, TOUCH_DOLLY: 4, TOUCH_PAN: 5 },
                    F = L.NONE,
                    N = 1e-6,
                    W = new e.Spherical(),
                    H = new e.Spherical(),
                    K = 1,
                    z = new e.Vector3(),
                    q = !1,
                    G = new e.Vector2(),
                    V = new e.Vector2(),
                    Y = new e.Vector2(),
                    $ = new e.Vector2(),
                    X = new e.Vector2(),
                    Z = new e.Vector2(),
                    Q = new e.Vector2(),
                    J = new e.Vector2(),
                    ee = new e.Vector2(),
                    te = (function () {
                        var t = new e.Vector3();
                        return function (e, r) {
                            t.setFromMatrixColumn(r, 0), t.multiplyScalar(-e), z.add(t);
                        };
                    })(),
                    re = (function () {
                        var t = new e.Vector3();
                        return function (e, r) {
                            t.setFromMatrixColumn(r, 1), t.multiplyScalar(e), z.add(t);
                        };
                    })(),
                    ne = (function () {
                        var t = new e.Vector3();
                        return function (r, n) {
                            var o = B.domElement === document ? B.domElement.body : B.domElement;
                            if (B.object instanceof e.PerspectiveCamera) {
                                var a = B.object.position;
                                t.copy(a).sub(B.target);
                                var i = t.length();
                                (i *= Math.tan(((B.object.fov / 2) * Math.PI) / 180)), te((2 * r * i) / o.clientHeight, B.object.matrix), re((2 * n * i) / o.clientHeight, B.object.matrix);
                            } else
                                B.object instanceof e.OrthographicCamera
                                    ? (te((r * (B.object.right - B.object.left)) / B.object.zoom / o.clientWidth, B.object.matrix), re((n * (B.object.top - B.object.bottom)) / B.object.zoom / o.clientHeight, B.object.matrix))
                                    : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."), (B.enablePan = !1));
                        };
                    })();
                B.domElement.addEventListener("contextmenu", j, !1),
                    B.domElement.addEventListener("mousedown", x, !1),
                    B.domElement.addEventListener("wheel", M, !1),
                    B.domElement.addEventListener("touchstart", T, !1),
                    B.domElement.addEventListener("touchend", R, !1),
                    B.domElement.addEventListener("touchmove", S, !1),
                    window.addEventListener("keydown", D, !1),
                    this.update();
            }
            return (
                (t.prototype = Object.create(e.EventDispatcher.prototype)),
                (t.prototype.constructor = t),
                Object.defineProperties(t.prototype, {
                    center: {
                        get: function () {
                            return console.warn("THREE.OrbitControls: .center has been renamed to .target"), this.target;
                        },
                    },
                    noZoom: {
                        get: function () {
                            return console.warn("THREE.OrbitControls: .noZoom has been deprecated. Use .enableZoom instead."), !this.enableZoom;
                        },
                        set: function (e) {
                            console.warn("THREE.OrbitControls: .noZoom has been deprecated. Use .enableZoom instead."), (this.enableZoom = !e);
                        },
                    },
                    noRotate: {
                        get: function () {
                            return console.warn("THREE.OrbitControls: .noRotate has been deprecated. Use .enableRotate instead."), !this.enableRotate;
                        },
                        set: function (e) {
                            console.warn("THREE.OrbitControls: .noRotate has been deprecated. Use .enableRotate instead."), (this.enableRotate = !e);
                        },
                    },
                    noPan: {
                        get: function () {
                            return console.warn("THREE.OrbitControls: .noPan has been deprecated. Use .enablePan instead."), !this.enablePan;
                        },
                        set: function (e) {
                            console.warn("THREE.OrbitControls: .noPan has been deprecated. Use .enablePan instead."), (this.enablePan = !e);
                        },
                    },
                    noKeys: {
                        get: function () {
                            return console.warn("THREE.OrbitControls: .noKeys has been deprecated. Use .enableKeys instead."), !this.enableKeys;
                        },
                        set: function (e) {
                            console.warn("THREE.OrbitControls: .noKeys has been deprecated. Use .enableKeys instead."), (this.enableKeys = !e);
                        },
                    },
                    staticMoving: {
                        get: function () {
                            return console.warn("THREE.OrbitControls: .staticMoving has been deprecated. Use .enableDamping instead."), !this.enableDamping;
                        },
                        set: function (e) {
                            console.warn("THREE.OrbitControls: .staticMoving has been deprecated. Use .enableDamping instead."), (this.enableDamping = !e);
                        },
                    },
                    dynamicDampingFactor: {
                        get: function () {
                            return console.warn("THREE.OrbitControls: .dynamicDampingFactor has been renamed. Use .dampingFactor instead."), this.dampingFactor;
                        },
                        set: function (e) {
                            console.warn("THREE.OrbitControls: .dynamicDampingFactor has been renamed. Use .dampingFactor instead."), (this.dampingFactor = e);
                        },
                    },
                }),
                t
            );
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.AlphaPicker = void 0);
        var o =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            a = n(r(0)),
            i = n(r(2)),
            l = r(5),
            u = n(r(276)),
            s = (t.AlphaPicker = function (e) {
                var t = e.rgb,
                    r = e.hsl,
                    n = e.width,
                    u = e.height,
                    s = e.onChange,
                    c = e.direction,
                    p = e.style,
                    f = e.renderers,
                    d = e.pointer,
                    _ = e.className,
                    h = void 0 === _ ? "" : _,
                    b = (0, i.default)({ default: { picker: { position: "relative", width: n, height: u }, alpha: { radius: "2px", style: p } } });
                return a.default.createElement("div", { style: b.picker, className: "alpha-picker " + h }, a.default.createElement(l.Alpha, o({}, b.alpha, { rgb: t, hsl: r, pointer: d, renderers: f, onChange: s, direction: c })));
            });
        (s.defaultProps = { width: "316px", height: "16px", direction: "horizontal", pointer: u.default }), (t.default = (0, l.ColorWrap)(s));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.flattenNames = void 0);
        var o = n(r(158)),
            a = n(r(48)),
            i = n(r(169)),
            l = n(r(14)),
            u = (t.flattenNames = function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                    r = [];
                return (
                    (0, l.default)(t, function (t) {
                        Array.isArray(t)
                            ? e(t).map(function (e) {
                                  return r.push(e);
                              })
                            : (0, i.default)(t)
                            ? (0, a.default)(t, function (e, t) {
                                  !0 === e && r.push(t), r.push(t + "-" + e);
                              })
                            : (0, o.default)(t) && r.push(t);
                    }),
                    r
                );
            });
        t.default = u;
    },
    function (e, t, r) {
        var n = r(17),
            o = r(8),
            a = r(11),
            i = "[object String]";
        e.exports = function (e) {
            return "string" == typeof e || (!o(e) && a(e) && n(e) == i);
        };
    },
    function (e, t, r) {
        var n = r(24),
            o = Object.prototype,
            a = o.hasOwnProperty,
            i = o.toString,
            l = n ? n.toStringTag : void 0;
        e.exports = function (e) {
            var t = a.call(e, l),
                r = e[l];
            try {
                e[l] = void 0;
                var n = !0;
            } catch (e) {}
            var o = i.call(e);
            return n && (t ? (e[l] = r) : delete e[l]), o;
        };
    },
    function (e, t) {
        var r = Object.prototype.toString;
        e.exports = function (e) {
            return r.call(e);
        };
    },
    function (e, t, r) {
        var n = r(162)();
        e.exports = n;
    },
    function (e, t) {
        e.exports = function (e) {
            return function (t, r, n) {
                for (var o = -1, a = Object(t), i = n(t), l = i.length; l--; ) {
                    var u = i[e ? l : ++o];
                    if (!1 === r(a[u], u, a)) break;
                }
                return t;
            };
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            for (var r = -1, n = Array(e); ++r < e; ) n[r] = t(r);
            return n;
        };
    },
    function (e, t, r) {
        var n = r(17),
            o = r(11),
            a = "[object Arguments]";
        e.exports = function (e) {
            return o(e) && n(e) == a;
        };
    },
    function (e, t) {
        e.exports = function () {
            return !1;
        };
    },
    function (e, t, r) {
        var n = r(17),
            o = r(50),
            a = r(11),
            i = {};
        (i["[object Float32Array]"] = i["[object Float64Array]"] = i["[object Int8Array]"] = i["[object Int16Array]"] = i["[object Int32Array]"] = i["[object Uint8Array]"] = i["[object Uint8ClampedArray]"] = i["[object Uint16Array]"] = i[
            "[object Uint32Array]"
        ] = !0),
            (i["[object Arguments]"] = i["[object Array]"] = i["[object ArrayBuffer]"] = i["[object Boolean]"] = i["[object DataView]"] = i["[object Date]"] = i["[object Error]"] = i["[object Function]"] = i["[object Map]"] = i[
                "[object Number]"
            ] = i["[object Object]"] = i["[object RegExp]"] = i["[object Set]"] = i["[object String]"] = i["[object WeakMap]"] = !1),
            (e.exports = function (e) {
                return a(e) && o(e.length) && !!i[n(e)];
            });
    },
    function (e, t, r) {
        var n = r(53),
            o = r(168),
            a = Object.prototype.hasOwnProperty;
        e.exports = function (e) {
            if (!n(e)) return o(e);
            var t = [];
            for (var r in Object(e)) a.call(e, r) && "constructor" != r && t.push(r);
            return t;
        };
    },
    function (e, t, r) {
        var n = r(83)(Object.keys, Object);
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(17),
            o = r(54),
            a = r(11),
            i = "[object Object]",
            l = Function.prototype,
            u = Object.prototype,
            s = l.toString,
            c = u.hasOwnProperty,
            p = s.call(Object);
        e.exports = function (e) {
            if (!a(e) || n(e) != i) return !1;
            var t = o(e);
            if (null === t) return !0;
            var r = c.call(t, "constructor") && t.constructor;
            return "function" == typeof r && r instanceof r && s.call(r) == p;
        };
    },
    function (e, t, r) {
        var n = r(171),
            o = r(215),
            a = r(86),
            i = r(8),
            l = r(225);
        e.exports = function (e) {
            return "function" == typeof e ? e : null == e ? a : "object" == typeof e ? (i(e) ? o(e[0], e[1]) : n(e)) : l(e);
        };
    },
    function (e, t, r) {
        var n = r(172),
            o = r(214),
            a = r(96);
        e.exports = function (e) {
            var t = o(e);
            return 1 == t.length && t[0][2]
                ? a(t[0][0], t[0][1])
                : function (r) {
                      return r === e || n(r, e, t);
                  };
        };
    },
    function (e, t, r) {
        var n = r(55),
            o = r(59),
            a = 1,
            i = 2;
        e.exports = function (e, t, r, l) {
            var u = r.length,
                s = u,
                c = !l;
            if (null == e) return !s;
            for (e = Object(e); u--; ) {
                var p = r[u];
                if (c && p[2] ? p[1] !== e[p[0]] : !(p[0] in e)) return !1;
            }
            for (; ++u < s; ) {
                var f = (p = r[u])[0],
                    d = e[f],
                    _ = p[1];
                if (c && p[2]) {
                    if (void 0 === d && !(f in e)) return !1;
                } else {
                    var h = new n();
                    if (l) var b = l(d, _, f, e, t, h);
                    if (!(void 0 === b ? o(_, d, a | i, l, h) : b)) return !1;
                }
            }
            return !0;
        };
    },
    function (e, t) {
        e.exports = function () {
            (this.__data__ = []), (this.size = 0);
        };
    },
    function (e, t, r) {
        var n = r(33),
            o = Array.prototype.splice;
        e.exports = function (e) {
            var t = this.__data__,
                r = n(t, e);
            return !(r < 0 || (r == t.length - 1 ? t.pop() : o.call(t, r, 1), --this.size, 0));
        };
    },
    function (e, t, r) {
        var n = r(33);
        e.exports = function (e) {
            var t = this.__data__,
                r = n(t, e);
            return r < 0 ? void 0 : t[r][1];
        };
    },
    function (e, t, r) {
        var n = r(33);
        e.exports = function (e) {
            return n(this.__data__, e) > -1;
        };
    },
    function (e, t, r) {
        var n = r(33);
        e.exports = function (e, t) {
            var r = this.__data__,
                o = n(r, e);
            return o < 0 ? (++this.size, r.push([e, t])) : (r[o][1] = t), this;
        };
    },
    function (e, t, r) {
        var n = r(32);
        e.exports = function () {
            (this.__data__ = new n()), (this.size = 0);
        };
    },
    function (e, t) {
        e.exports = function (e) {
            var t = this.__data__,
                r = t.delete(e);
            return (this.size = t.size), r;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            return this.__data__.get(e);
        };
    },
    function (e, t) {
        e.exports = function (e) {
            return this.__data__.has(e);
        };
    },
    function (e, t, r) {
        var n = r(32),
            o = r(57),
            a = r(58),
            i = 200;
        e.exports = function (e, t) {
            var r = this.__data__;
            if (r instanceof n) {
                var l = r.__data__;
                if (!o || l.length < i - 1) return l.push([e, t]), (this.size = ++r.size), this;
                r = this.__data__ = new a(l);
            }
            return r.set(e, t), (this.size = r.size), this;
        };
    },
    function (e, t, r) {
        var n = r(84),
            o = r(184),
            a = r(12),
            i = r(88),
            l = /[\\^$.*+?()[\]{}|]/g,
            u = /^\[object .+?Constructor\]$/,
            s = Function.prototype,
            c = Object.prototype,
            p = s.toString,
            f = c.hasOwnProperty,
            d = RegExp(
                "^" +
                    p
                        .call(f)
                        .replace(l, "\\$&")
                        .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") +
                    "$"
            );
        e.exports = function (e) {
            return !(!a(e) || o(e)) && (n(e) ? d : u).test(i(e));
        };
    },
    function (e, t, r) {
        var n = r(185),
            o = (function () {
                var e = /[^.]+$/.exec((n && n.keys && n.keys.IE_PROTO) || "");
                return e ? "Symbol(src)_1." + e : "";
            })();
        e.exports = function (e) {
            return !!o && o in e;
        };
    },
    function (e, t, r) {
        var n = r(9)["__core-js_shared__"];
        e.exports = n;
    },
    function (e, t) {
        e.exports = function (e, t) {
            return null == e ? void 0 : e[t];
        };
    },
    function (e, t, r) {
        var n = r(188),
            o = r(32),
            a = r(57);
        e.exports = function () {
            (this.size = 0), (this.__data__ = { hash: new n(), map: new (a || o)(), string: new n() });
        };
    },
    function (e, t, r) {
        function n(e) {
            var t = -1,
                r = null == e ? 0 : e.length;
            for (this.clear(); ++t < r; ) {
                var n = e[t];
                this.set(n[0], n[1]);
            }
        }
        var o = r(189),
            a = r(190),
            i = r(191),
            l = r(192),
            u = r(193);
        (n.prototype.clear = o), (n.prototype.delete = a), (n.prototype.get = i), (n.prototype.has = l), (n.prototype.set = u), (e.exports = n);
    },
    function (e, t, r) {
        var n = r(34);
        e.exports = function () {
            (this.__data__ = n ? n(null) : {}), (this.size = 0);
        };
    },
    function (e, t) {
        e.exports = function (e) {
            var t = this.has(e) && delete this.__data__[e];
            return (this.size -= t ? 1 : 0), t;
        };
    },
    function (e, t, r) {
        var n = r(34),
            o = "__lodash_hash_undefined__",
            a = Object.prototype.hasOwnProperty;
        e.exports = function (e) {
            var t = this.__data__;
            if (n) {
                var r = t[e];
                return r === o ? void 0 : r;
            }
            return a.call(t, e) ? t[e] : void 0;
        };
    },
    function (e, t, r) {
        var n = r(34),
            o = Object.prototype.hasOwnProperty;
        e.exports = function (e) {
            var t = this.__data__;
            return n ? void 0 !== t[e] : o.call(t, e);
        };
    },
    function (e, t, r) {
        var n = r(34),
            o = "__lodash_hash_undefined__";
        e.exports = function (e, t) {
            var r = this.__data__;
            return (this.size += this.has(e) ? 0 : 1), (r[e] = n && void 0 === t ? o : t), this;
        };
    },
    function (e, t, r) {
        var n = r(35);
        e.exports = function (e) {
            var t = n(this, e).delete(e);
            return (this.size -= t ? 1 : 0), t;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            var t = typeof e;
            return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e;
        };
    },
    function (e, t, r) {
        var n = r(35);
        e.exports = function (e) {
            return n(this, e).get(e);
        };
    },
    function (e, t, r) {
        var n = r(35);
        e.exports = function (e) {
            return n(this, e).has(e);
        };
    },
    function (e, t, r) {
        var n = r(35);
        e.exports = function (e, t) {
            var r = n(this, e),
                o = r.size;
            return r.set(e, t), (this.size += r.size == o ? 0 : 1), this;
        };
    },
    function (e, t, r) {
        var n = r(55),
            o = r(89),
            a = r(205),
            i = r(208),
            l = r(36),
            u = r(8),
            s = r(49),
            c = r(82),
            p = 1,
            f = "[object Arguments]",
            d = "[object Array]",
            _ = "[object Object]",
            h = Object.prototype.hasOwnProperty;
        e.exports = function (e, t, r, b, m, g) {
            var v = u(e),
                y = u(t),
                E = v ? d : l(e),
                C = y ? d : l(t),
                k = (E = E == f ? _ : E) == _,
                P = (C = C == f ? _ : C) == _,
                x = E == C;
            if (x && s(e)) {
                if (!s(t)) return !1;
                (v = !0), (k = !1);
            }
            if (x && !k) return g || (g = new n()), v || c(e) ? o(e, t, r, b, m, g) : a(e, t, E, r, b, m, g);
            if (!(r & p)) {
                var w = k && h.call(e, "__wrapped__"),
                    O = P && h.call(t, "__wrapped__");
                if (w || O) {
                    var M = w ? e.value() : e,
                        D = O ? t.value() : t;
                    return g || (g = new n()), m(M, D, r, b, g);
                }
            }
            return !!x && (g || (g = new n()), i(e, t, r, b, m, g));
        };
    },
    function (e, t, r) {
        function n(e) {
            var t = -1,
                r = null == e ? 0 : e.length;
            for (this.__data__ = new o(); ++t < r; ) this.add(e[t]);
        }
        var o = r(58),
            a = r(201),
            i = r(202);
        (n.prototype.add = n.prototype.push = a), (n.prototype.has = i), (e.exports = n);
    },
    function (e, t) {
        var r = "__lodash_hash_undefined__";
        e.exports = function (e) {
            return this.__data__.set(e, r), this;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            return this.__data__.has(e);
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            for (var r = -1, n = null == e ? 0 : e.length; ++r < n; ) if (t(e[r], r, e)) return !0;
            return !1;
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            return e.has(t);
        };
    },
    function (e, t, r) {
        var n = r(24),
            o = r(90),
            a = r(56),
            i = r(89),
            l = r(206),
            u = r(207),
            s = 1,
            c = 2,
            p = "[object Boolean]",
            f = "[object Date]",
            d = "[object Error]",
            _ = "[object Map]",
            h = "[object Number]",
            b = "[object RegExp]",
            m = "[object Set]",
            g = "[object String]",
            v = "[object Symbol]",
            y = "[object ArrayBuffer]",
            E = "[object DataView]",
            C = n ? n.prototype : void 0,
            k = C ? C.valueOf : void 0;
        e.exports = function (e, t, r, n, C, P, x) {
            switch (r) {
                case E:
                    if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                    (e = e.buffer), (t = t.buffer);
                case y:
                    return !(e.byteLength != t.byteLength || !P(new o(e), new o(t)));
                case p:
                case f:
                case h:
                    return a(+e, +t);
                case d:
                    return e.name == t.name && e.message == t.message;
                case b:
                case g:
                    return e == t + "";
                case _:
                    var w = l;
                case m:
                    var O = n & s;
                    if ((w || (w = u), e.size != t.size && !O)) return !1;
                    var M = x.get(e);
                    if (M) return M == t;
                    (n |= c), x.set(e, t);
                    var D = i(w(e), w(t), n, C, P, x);
                    return x.delete(e), D;
                case v:
                    if (k) return k.call(e) == k.call(t);
            }
            return !1;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            var t = -1,
                r = Array(e.size);
            return (
                e.forEach(function (e, n) {
                    r[++t] = [n, e];
                }),
                r
            );
        };
    },
    function (e, t) {
        e.exports = function (e) {
            var t = -1,
                r = Array(e.size);
            return (
                e.forEach(function (e) {
                    r[++t] = e;
                }),
                r
            );
        };
    },
    function (e, t, r) {
        var n = r(91),
            o = 1,
            a = Object.prototype.hasOwnProperty;
        e.exports = function (e, t, r, i, l, u) {
            var s = r & o,
                c = n(e),
                p = c.length;
            if (p != n(t).length && !s) return !1;
            for (var f = p; f--; ) {
                var d = c[f];
                if (!(s ? d in t : a.call(t, d))) return !1;
            }
            var _ = u.get(e);
            if (_ && u.get(t)) return _ == t;
            var h = !0;
            u.set(e, t), u.set(t, e);
            for (var b = s; ++f < p; ) {
                var m = e[(d = c[f])],
                    g = t[d];
                if (i) var v = s ? i(g, m, d, t, e, u) : i(m, g, d, e, t, u);
                if (!(void 0 === v ? m === g || l(m, g, r, i, u) : v)) {
                    h = !1;
                    break;
                }
                b || (b = "constructor" == d);
            }
            if (h && !b) {
                var y = e.constructor,
                    E = t.constructor;
                y != E && "constructor" in e && "constructor" in t && !("function" == typeof y && y instanceof y && "function" == typeof E && E instanceof E) && (h = !1);
            }
            return u.delete(e), u.delete(t), h;
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            for (var r = -1, n = null == e ? 0 : e.length, o = 0, a = []; ++r < n; ) {
                var i = e[r];
                t(i, r, e) && (a[o++] = i);
            }
            return a;
        };
    },
    function (e, t, r) {
        var n = r(18)(r(9), "DataView");
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(18)(r(9), "Promise");
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(18)(r(9), "Set");
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(18)(r(9), "WeakMap");
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(95),
            o = r(25);
        e.exports = function (e) {
            for (var t = o(e), r = t.length; r--; ) {
                var a = t[r],
                    i = e[a];
                t[r] = [a, i, n(i)];
            }
            return t;
        };
    },
    function (e, t, r) {
        var n = r(59),
            o = r(216),
            a = r(222),
            i = r(61),
            l = r(95),
            u = r(96),
            s = r(38),
            c = 1,
            p = 2;
        e.exports = function (e, t) {
            return i(e) && l(t)
                ? u(s(e), t)
                : function (r) {
                      var i = o(r, e);
                      return void 0 === i && i === t ? a(r, e) : n(t, i, c | p);
                  };
        };
    },
    function (e, t, r) {
        var n = r(97);
        e.exports = function (e, t, r) {
            var o = null == e ? void 0 : n(e, t);
            return void 0 === o ? r : o;
        };
    },
    function (e, t, r) {
        var n = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            o = /\\(\\)?/g,
            a = r(218)(function (e) {
                var t = [];
                return (
                    46 === e.charCodeAt(0) && t.push(""),
                    e.replace(n, function (e, r, n, a) {
                        t.push(n ? a.replace(o, "$1") : r || e);
                    }),
                    t
                );
            });
        e.exports = a;
    },
    function (e, t, r) {
        var n = r(219),
            o = 500;
        e.exports = function (e) {
            var t = n(e, function (e) {
                    return r.size === o && r.clear(), e;
                }),
                r = t.cache;
            return t;
        };
    },
    function (e, t, r) {
        function n(e, t) {
            if ("function" != typeof e || (null != t && "function" != typeof t)) throw new TypeError(a);
            var r = function () {
                var n = arguments,
                    o = t ? t.apply(this, n) : n[0],
                    a = r.cache;
                if (a.has(o)) return a.get(o);
                var i = e.apply(this, n);
                return (r.cache = a.set(o, i) || a), i;
            };
            return (r.cache = new (n.Cache || o)()), r;
        }
        var o = r(58),
            a = "Expected a function";
        (n.Cache = o), (e.exports = n);
    },
    function (e, t, r) {
        var n = r(221);
        e.exports = function (e) {
            return null == e ? "" : n(e);
        };
    },
    function (e, t, r) {
        function n(e) {
            if ("string" == typeof e) return e;
            if (i(e)) return a(e, n) + "";
            if (l(e)) return c ? c.call(e) : "";
            var t = e + "";
            return "0" == t && 1 / e == -u ? "-0" : t;
        }
        var o = r(24),
            a = r(87),
            i = r(8),
            l = r(37),
            u = 1 / 0,
            s = o ? o.prototype : void 0,
            c = s ? s.toString : void 0;
        e.exports = n;
    },
    function (e, t, r) {
        var n = r(223),
            o = r(224);
        e.exports = function (e, t) {
            return null != e && o(e, t, n);
        };
    },
    function (e, t) {
        e.exports = function (e, t) {
            return null != e && t in Object(e);
        };
    },
    function (e, t, r) {
        var n = r(98),
            o = r(80),
            a = r(8),
            i = r(81),
            l = r(50),
            u = r(38);
        e.exports = function (e, t, r) {
            for (var s = -1, c = (t = n(t, e)).length, p = !1; ++s < c; ) {
                var f = u(t[s]);
                if (!(p = null != e && r(e, f))) break;
                e = e[f];
            }
            return p || ++s != c ? p : !!(c = null == e ? 0 : e.length) && l(c) && i(f, c) && (a(e) || o(e));
        };
    },
    function (e, t, r) {
        var n = r(226),
            o = r(227),
            a = r(61),
            i = r(38);
        e.exports = function (e) {
            return a(e) ? n(i(e)) : o(e);
        };
    },
    function (e, t) {
        e.exports = function (e) {
            return function (t) {
                return null == t ? void 0 : t[e];
            };
        };
    },
    function (e, t, r) {
        var n = r(97);
        e.exports = function (e) {
            return function (t) {
                return n(t, e);
            };
        };
    },
    function (e, t, r) {
        var n = r(99),
            o = r(31);
        e.exports = function (e, t) {
            var r = -1,
                a = o(e) ? Array(e.length) : [];
            return (
                n(e, function (e, n, o) {
                    a[++r] = t(e, n, o);
                }),
                a
            );
        };
    },
    function (e, t, r) {
        var n = r(31);
        e.exports = function (e, t) {
            return function (r, o) {
                if (null == r) return r;
                if (!n(r)) return e(r, o);
                for (var a = r.length, i = t ? a : -1, l = Object(r); (t ? i-- : ++i < a) && !1 !== o(l[i], i, l); );
                return r;
            };
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.mergeClasses = void 0);
        var o = n(r(48)),
            a = n(r(231)),
            i =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            l = (t.mergeClasses = function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                    r = (e.default && (0, a.default)(e.default)) || {};
                return (
                    t.map(function (t) {
                        var n = e[t];
                        return (
                            n &&
                                (0, o.default)(n, function (e, t) {
                                    r[t] || (r[t] = {}), (r[t] = i({}, r[t], n[t]));
                                }),
                            t
                        );
                    }),
                    r
                );
            });
        t.default = l;
    },
    function (e, t, r) {
        var n = r(232),
            o = 1,
            a = 4;
        e.exports = function (e) {
            return n(e, o | a);
        };
    },
    function (e, t, r) {
        function n(e, t, r, j, B, A) {
            var U,
                I = t & x,
                L = t & w,
                F = t & O;
            if ((r && (U = B ? r(e, j, B, A) : r(e)), void 0 !== U)) return U;
            if (!C(e)) return e;
            var N = v(e);
            if (N) {
                if (((U = b(e)), !I)) return c(e, U);
            } else {
                var W = h(e),
                    H = W == D || W == T;
                if (y(e)) return s(e, I);
                if (W == S || W == M || (H && !B)) {
                    if (((U = L || H ? {} : g(e)), !I)) return L ? f(e, u(U, e)) : p(e, l(U, e));
                } else {
                    if (!R[W]) return B ? e : {};
                    U = m(e, W, I);
                }
            }
            A || (A = new o());
            var K = A.get(e);
            if (K) return K;
            if ((A.set(e, U), k(e)))
                return (
                    e.forEach(function (o) {
                        U.add(n(o, t, r, o, e, A));
                    }),
                    U
                );
            if (E(e))
                return (
                    e.forEach(function (o, a) {
                        U.set(a, n(o, t, r, a, e, A));
                    }),
                    U
                );
            var z = F ? (L ? _ : d) : L ? keysIn : P,
                q = N ? void 0 : z(e);
            return (
                a(q || e, function (o, a) {
                    q && (o = e[(a = o)]), i(U, a, n(o, t, r, a, e, A));
                }),
                U
            );
        }
        var o = r(55),
            a = r(100),
            i = r(101),
            l = r(234),
            u = r(235),
            s = r(238),
            c = r(239),
            p = r(240),
            f = r(241),
            d = r(91),
            _ = r(242),
            h = r(36),
            b = r(243),
            m = r(244),
            g = r(249),
            v = r(8),
            y = r(49),
            E = r(251),
            C = r(12),
            k = r(253),
            P = r(25),
            x = 1,
            w = 2,
            O = 4,
            M = "[object Arguments]",
            D = "[object Function]",
            T = "[object GeneratorFunction]",
            S = "[object Object]",
            R = {};
        (R[M] = R["[object Array]"] = R["[object ArrayBuffer]"] = R["[object DataView]"] = R["[object Boolean]"] = R["[object Date]"] = R["[object Float32Array]"] = R["[object Float64Array]"] = R["[object Int8Array]"] = R[
            "[object Int16Array]"
        ] = R["[object Int32Array]"] = R["[object Map]"] = R["[object Number]"] = R[S] = R["[object RegExp]"] = R["[object Set]"] = R["[object String]"] = R["[object Symbol]"] = R["[object Uint8Array]"] = R[
            "[object Uint8ClampedArray]"
        ] = R["[object Uint16Array]"] = R["[object Uint32Array]"] = !0),
            (R["[object Error]"] = R[D] = R["[object WeakMap]"] = !1),
            (e.exports = n);
    },
    function (e, t, r) {
        var n = r(18),
            o = (function () {
                try {
                    var e = n(Object, "defineProperty");
                    return e({}, "", {}), e;
                } catch (e) {}
            })();
        e.exports = o;
    },
    function (e, t, r) {
        var n = r(39),
            o = r(25);
        e.exports = function (e, t) {
            return e && n(t, o(t), e);
        };
    },
    function (e, t, r) {
        var n = r(39),
            o = r(103);
        e.exports = function (e, t) {
            return e && n(t, o(t), e);
        };
    },
    function (e, t, r) {
        var n = r(12),
            o = r(53),
            a = r(237),
            i = Object.prototype.hasOwnProperty;
        e.exports = function (e) {
            if (!n(e)) return a(e);
            var t = o(e),
                r = [];
            for (var l in e) ("constructor" != l || (!t && i.call(e, l))) && r.push(l);
            return r;
        };
    },
    function (e, t) {
        e.exports = function (e) {
            var t = [];
            if (null != e) for (var r in Object(e)) t.push(r);
            return t;
        };
    },
    function (e, t, r) {
        (function (e) {
            var n = r(9),
                o = t && !t.nodeType && t,
                a = o && "object" == typeof e && e && !e.nodeType && e,
                i = a && a.exports === o ? n.Buffer : void 0,
                l = i ? i.allocUnsafe : void 0;
            e.exports = function (e, t) {
                if (t) return e.slice();
                var r = e.length,
                    n = l ? l(r) : new e.constructor(r);
                return e.copy(n), n;
            };
        }.call(this, r(22)(e)));
    },
    function (e, t) {
        e.exports = function (e, t) {
            var r = -1,
                n = e.length;
            for (t || (t = Array(n)); ++r < n; ) t[r] = e[r];
            return t;
        };
    },
    function (e, t, r) {
        var n = r(39),
            o = r(60);
        e.exports = function (e, t) {
            return n(e, o(e), t);
        };
    },
    function (e, t, r) {
        var n = r(39),
            o = r(104);
        e.exports = function (e, t) {
            return n(e, o(e), t);
        };
    },
    function (e, t, r) {
        var n = r(92),
            o = r(104),
            a = r(103);
        e.exports = function (e) {
            return n(e, a, o);
        };
    },
    function (e, t) {
        var r = Object.prototype.hasOwnProperty;
        e.exports = function (e) {
            var t = e.length,
                n = new e.constructor(t);
            return t && "string" == typeof e[0] && r.call(e, "index") && ((n.index = e.index), (n.input = e.input)), n;
        };
    },
    function (e, t, r) {
        var n = r(62),
            o = r(245),
            a = r(246),
            i = r(247),
            l = r(248),
            u = "[object Boolean]",
            s = "[object Date]",
            c = "[object Map]",
            p = "[object Number]",
            f = "[object RegExp]",
            d = "[object Set]",
            _ = "[object String]",
            h = "[object Symbol]",
            b = "[object ArrayBuffer]",
            m = "[object DataView]",
            g = "[object Float32Array]",
            v = "[object Float64Array]",
            y = "[object Int8Array]",
            E = "[object Int16Array]",
            C = "[object Int32Array]",
            k = "[object Uint8Array]",
            P = "[object Uint8ClampedArray]",
            x = "[object Uint16Array]",
            w = "[object Uint32Array]";
        e.exports = function (e, t, r) {
            var O = e.constructor;
            switch (t) {
                case b:
                    return n(e);
                case u:
                case s:
                    return new O(+e);
                case m:
                    return o(e, r);
                case g:
                case v:
                case y:
                case E:
                case C:
                case k:
                case P:
                case x:
                case w:
                    return l(e, r);
                case c:
                    return new O();
                case p:
                case _:
                    return new O(e);
                case f:
                    return a(e);
                case d:
                    return new O();
                case h:
                    return i(e);
            }
        };
    },
    function (e, t, r) {
        var n = r(62);
        e.exports = function (e, t) {
            var r = t ? n(e.buffer) : e.buffer;
            return new e.constructor(r, e.byteOffset, e.byteLength);
        };
    },
    function (e, t) {
        var r = /\w*$/;
        e.exports = function (e) {
            var t = new e.constructor(e.source, r.exec(e));
            return (t.lastIndex = e.lastIndex), t;
        };
    },
    function (e, t, r) {
        var n = r(24),
            o = n ? n.prototype : void 0,
            a = o ? o.valueOf : void 0;
        e.exports = function (e) {
            return a ? Object(a.call(e)) : {};
        };
    },
    function (e, t, r) {
        var n = r(62);
        e.exports = function (e, t) {
            var r = t ? n(e.buffer) : e.buffer;
            return new e.constructor(r, e.byteOffset, e.length);
        };
    },
    function (e, t, r) {
        var n = r(250),
            o = r(54),
            a = r(53);
        e.exports = function (e) {
            return "function" != typeof e.constructor || a(e) ? {} : n(o(e));
        };
    },
    function (e, t, r) {
        var n = r(12),
            o = Object.create,
            a = (function () {
                function e() {}
                return function (t) {
                    if (!n(t)) return {};
                    if (o) return o(t);
                    e.prototype = t;
                    var r = new e();
                    return (e.prototype = void 0), r;
                };
            })();
        e.exports = a;
    },
    function (e, t, r) {
        var n = r(252),
            o = r(51),
            a = r(52),
            i = a && a.isMap,
            l = i ? o(i) : n;
        e.exports = l;
    },
    function (e, t, r) {
        var n = r(36),
            o = r(11),
            a = "[object Map]";
        e.exports = function (e) {
            return o(e) && n(e) == a;
        };
    },
    function (e, t, r) {
        var n = r(254),
            o = r(51),
            a = r(52),
            i = a && a.isSet,
            l = i ? o(i) : n;
        e.exports = l;
    },
    function (e, t, r) {
        var n = r(36),
            o = r(11),
            a = "[object Set]";
        e.exports = function (e) {
            return o(e) && n(e) == a;
        };
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.autoprefix = void 0);
        var n = (function (e) {
                return e && e.__esModule ? e : { default: e };
            })(r(48)),
            o =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            a = {
                borderRadius: function (e) {
                    return { msBorderRadius: e, MozBorderRadius: e, OBorderRadius: e, WebkitBorderRadius: e, borderRadius: e };
                },
                boxShadow: function (e) {
                    return { msBoxShadow: e, MozBoxShadow: e, OBoxShadow: e, WebkitBoxShadow: e, boxShadow: e };
                },
                userSelect: function (e) {
                    return { WebkitTouchCallout: e, KhtmlUserSelect: e, MozUserSelect: e, msUserSelect: e, WebkitUserSelect: e, userSelect: e };
                },
                flex: function (e) {
                    return { WebkitBoxFlex: e, MozBoxFlex: e, WebkitFlex: e, msFlex: e, flex: e };
                },
                flexBasis: function (e) {
                    return { WebkitFlexBasis: e, flexBasis: e };
                },
                justifyContent: function (e) {
                    return { WebkitJustifyContent: e, justifyContent: e };
                },
                transition: function (e) {
                    return { msTransition: e, MozTransition: e, OTransition: e, WebkitTransition: e, transition: e };
                },
                transform: function (e) {
                    return { msTransform: e, MozTransform: e, OTransform: e, WebkitTransform: e, transform: e };
                },
                absolute: function (e) {
                    var t = e && e.split(" ");
                    return { position: "absolute", top: t && t[0], right: t && t[1], bottom: t && t[2], left: t && t[3] };
                },
                extend: function (e, t) {
                    var r = t[e];
                    return r || { extend: e };
                },
            },
            i = (t.autoprefix = function (e) {
                var t = {};
                return (
                    (0, n.default)(e, function (e, r) {
                        var i = {};
                        (0, n.default)(e, function (e, t) {
                            var r = a[t];
                            r ? (i = o({}, i, r(e))) : (i[t] = e);
                        }),
                            (t[r] = i);
                    }),
                    t
                );
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function o(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.hover = void 0);
        var i =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            l = (function (e) {
                return e && e.__esModule ? e : { default: e };
            })(r(0)),
            u = (t.hover = function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "span";
                return (function (r) {
                    function u() {
                        var r, a, s, c;
                        n(this, u);
                        for (var p = arguments.length, f = Array(p), d = 0; d < p; d++) f[d] = arguments[d];
                        return (
                            (a = s = o(this, (r = u.__proto__ || Object.getPrototypeOf(u)).call.apply(r, [this].concat(f)))),
                            (s.state = { hover: !1 }),
                            (s.handleMouseOver = function () {
                                return s.setState({ hover: !0 });
                            }),
                            (s.handleMouseOut = function () {
                                return s.setState({ hover: !1 });
                            }),
                            (s.render = function () {
                                return l.default.createElement(t, { onMouseOver: s.handleMouseOver, onMouseOut: s.handleMouseOut }, l.default.createElement(e, i({}, s.props, s.state)));
                            }),
                            (c = a),
                            o(s, c)
                        );
                    }
                    return a(u, l.default.Component), u;
                })();
            });
        t.default = u;
    },
    function (e, t, r) {
        "use strict";
        function n(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function o(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.active = void 0);
        var i =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            l = (function (e) {
                return e && e.__esModule ? e : { default: e };
            })(r(0)),
            u = (t.active = function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "span";
                return (function (r) {
                    function u() {
                        var r, a, s, c;
                        n(this, u);
                        for (var p = arguments.length, f = Array(p), d = 0; d < p; d++) f[d] = arguments[d];
                        return (
                            (a = s = o(this, (r = u.__proto__ || Object.getPrototypeOf(u)).call.apply(r, [this].concat(f)))),
                            (s.state = { active: !1 }),
                            (s.handleMouseDown = function () {
                                return s.setState({ active: !0 });
                            }),
                            (s.handleMouseUp = function () {
                                return s.setState({ active: !1 });
                            }),
                            (s.render = function () {
                                return l.default.createElement(t, { onMouseDown: s.handleMouseDown, onMouseUp: s.handleMouseUp }, l.default.createElement(e, i({}, s.props, s.state)));
                            }),
                            (c = a),
                            o(s, c)
                        );
                    }
                    return a(u, l.default.Component), u;
                })();
            });
        t.default = u;
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        t.default = function (e, t) {
            var r = {},
                n = function (e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    r[e] = t;
                };
            return 0 === e && n("first-child"), e === t - 1 && n("last-child"), (0 === e || e % 2 == 0) && n("even"), 1 === Math.abs(e % 2) && n("odd"), n("nth-child", e), r;
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function a(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function i(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Alpha = void 0);
        var l =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            u = (function () {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                    }
                }
                return function (t, r, n) {
                    return r && e(t.prototype, r), n && e(t, n), t;
                };
            })(),
            s = r(0),
            c = n(s),
            p = n(r(2)),
            f = (function (e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return (t.default = e), t;
            })(r(260)),
            d = n(r(105)),
            _ = (t.Alpha = (function (e) {
                function t() {
                    var e, r, n, i;
                    o(this, t);
                    for (var l = arguments.length, u = Array(l), s = 0; s < l; s++) u[s] = arguments[s];
                    return (
                        (r = n = a(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [this].concat(u)))),
                        (n.handleChange = function (e, t) {
                            var r = f.calculateChange(e, t, n.props, n.container);
                            r && n.props.onChange && n.props.onChange(r, e);
                        }),
                        (n.handleMouseDown = function (e) {
                            n.handleChange(e, !0), window.addEventListener("mousemove", n.handleChange), window.addEventListener("mouseup", n.handleMouseUp);
                        }),
                        (n.handleMouseUp = function () {
                            n.unbindEventListeners();
                        }),
                        (n.unbindEventListeners = function () {
                            window.removeEventListener("mousemove", n.handleChange), window.removeEventListener("mouseup", n.handleMouseUp);
                        }),
                        (i = r),
                        a(n, i)
                    );
                }
                return (
                    i(t, s.PureComponent || s.Component),
                    u(t, [
                        {
                            key: "componentWillUnmount",
                            value: function () {
                                this.unbindEventListeners();
                            },
                        },
                        {
                            key: "render",
                            value: function () {
                                var e = this,
                                    t = this.props.rgb,
                                    r = (0, p.default)(
                                        {
                                            default: {
                                                alpha: { absolute: "0px 0px 0px 0px", borderRadius: this.props.radius },
                                                checkboard: { absolute: "0px 0px 0px 0px", overflow: "hidden" },
                                                gradient: {
                                                    absolute: "0px 0px 0px 0px",
                                                    background: "linear-gradient(to right, rgba(" + t.r + "," + t.g + "," + t.b + ", 0) 0%,\n           rgba(" + t.r + "," + t.g + "," + t.b + ", 1) 100%)",
                                                    boxShadow: this.props.shadow,
                                                    borderRadius: this.props.radius,
                                                },
                                                container: { position: "relative", height: "100%", margin: "0 3px" },
                                                pointer: { position: "absolute", left: 100 * t.a + "%" },
                                                slider: { width: "4px", borderRadius: "1px", height: "8px", boxShadow: "0 0 2px rgba(0, 0, 0, .6)", background: "#fff", marginTop: "1px", transform: "translateX(-2px)" },
                                            },
                                            vertical: {
                                                gradient: { background: "linear-gradient(to bottom, rgba(" + t.r + "," + t.g + "," + t.b + ", 0) 0%,\n           rgba(" + t.r + "," + t.g + "," + t.b + ", 1) 100%)" },
                                                pointer: { left: 0, top: 100 * t.a + "%" },
                                            },
                                            overwrite: l({}, this.props.style),
                                        },
                                        { vertical: "vertical" === this.props.direction, overwrite: !0 }
                                    );
                                return c.default.createElement(
                                    "div",
                                    { style: r.alpha },
                                    c.default.createElement("div", { style: r.checkboard }, c.default.createElement(d.default, { renderers: this.props.renderers })),
                                    c.default.createElement("div", { style: r.gradient }),
                                    c.default.createElement(
                                        "div",
                                        {
                                            style: r.container,
                                            ref: function (t) {
                                                return (e.container = t);
                                            },
                                            onMouseDown: this.handleMouseDown,
                                            onTouchMove: this.handleChange,
                                            onTouchStart: this.handleChange,
                                        },
                                        c.default.createElement("div", { style: r.pointer }, this.props.pointer ? c.default.createElement(this.props.pointer, this.props) : c.default.createElement("div", { style: r.slider }))
                                    )
                                );
                            },
                        },
                    ]),
                    t
                );
            })());
        t.default = _;
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        t.calculateChange = function (e, t, r, n) {
            e.preventDefault();
            var o = n.clientWidth,
                a = n.clientHeight,
                i = "number" == typeof e.pageX ? e.pageX : e.touches[0].pageX,
                l = "number" == typeof e.pageY ? e.pageY : e.touches[0].pageY,
                u = i - (n.getBoundingClientRect().left + window.pageXOffset),
                s = l - (n.getBoundingClientRect().top + window.pageYOffset);
            if ("vertical" === r.direction) {
                var c = void 0;
                if (((c = s < 0 ? 0 : s > a ? 1 : Math.round((100 * s) / a) / 100), r.hsl.a !== c)) return { h: r.hsl.h, s: r.hsl.s, l: r.hsl.l, a: c, source: "rgb" };
            } else {
                var p = void 0;
                if (((p = u < 0 ? 0 : u > o ? 1 : Math.round((100 * u) / o) / 100), r.a !== p)) return { h: r.hsl.h, s: r.hsl.s, l: r.hsl.l, a: p, source: "rgb" };
            }
            return null;
        };
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        var n = {},
            o = (t.render = function (e, t, r, n) {
                if ("undefined" == typeof document && !n) return null;
                var o = n ? new n() : document.createElement("canvas");
                (o.width = 2 * r), (o.height = 2 * r);
                var a = o.getContext("2d");
                return a ? ((a.fillStyle = e), a.fillRect(0, 0, o.width, o.height), (a.fillStyle = t), a.fillRect(0, 0, r, r), a.translate(r, r), a.fillRect(0, 0, r, r), o.toDataURL()) : null;
            });
        t.get = function (e, t, r, a) {
            var i = e + "-" + t + "-" + r + (a ? "-server" : ""),
                l = o(e, t, r, a);
            return n[i] ? n[i] : ((n[i] = l), l);
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        function o(e, t, r) {
            return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : (e[t] = r), e;
        }
        function a(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function i(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function l(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.EditableInput = void 0);
        var u = (function () {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                    }
                }
                return function (t, r, n) {
                    return r && e(t.prototype, r), n && e(t, n), t;
                };
            })(),
            s = r(0),
            c = n(s),
            p = n(r(2)),
            f = (t.EditableInput = (function (e) {
                function t(e) {
                    a(this, t);
                    var r = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    return (
                        (r.handleBlur = function () {
                            r.state.blurValue && r.setState({ value: r.state.blurValue, blurValue: null });
                        }),
                        (r.handleChange = function (e) {
                            r.props.label ? r.props.onChange && r.props.onChange(o({}, r.props.label, e.target.value), e) : r.props.onChange && r.props.onChange(e.target.value, e), r.setState({ value: e.target.value });
                        }),
                        (r.handleKeyDown = function (e) {
                            var t = String(e.target.value),
                                n = t.indexOf("%") > -1,
                                a = Number(t.replace(/%/g, ""));
                            if (!isNaN(a)) {
                                var i = r.props.arrowOffset || 1;
                                38 === e.keyCode &&
                                    (null !== r.props.label ? r.props.onChange && r.props.onChange(o({}, r.props.label, a + i), e) : r.props.onChange && r.props.onChange(a + i, e),
                                    n ? r.setState({ value: a + i + "%" }) : r.setState({ value: a + i })),
                                    40 === e.keyCode &&
                                        (null !== r.props.label ? r.props.onChange && r.props.onChange(o({}, r.props.label, a - i), e) : r.props.onChange && r.props.onChange(a - i, e),
                                        n ? r.setState({ value: a - i + "%" }) : r.setState({ value: a - i }));
                            }
                        }),
                        (r.handleDrag = function (e) {
                            if (r.props.dragLabel) {
                                var t = Math.round(r.props.value + e.movementX);
                                t >= 0 && t <= r.props.dragMax && r.props.onChange && r.props.onChange(o({}, r.props.label, t), e);
                            }
                        }),
                        (r.handleMouseDown = function (e) {
                            r.props.dragLabel && (e.preventDefault(), r.handleDrag(e), window.addEventListener("mousemove", r.handleDrag), window.addEventListener("mouseup", r.handleMouseUp));
                        }),
                        (r.handleMouseUp = function () {
                            r.unbindEventListeners();
                        }),
                        (r.unbindEventListeners = function () {
                            window.removeEventListener("mousemove", r.handleDrag), window.removeEventListener("mouseup", r.handleMouseUp);
                        }),
                        (r.state = { value: String(e.value).toUpperCase(), blurValue: String(e.value).toUpperCase() }),
                        r
                    );
                }
                return (
                    l(t, s.PureComponent || s.Component),
                    u(t, [
                        {
                            key: "componentWillReceiveProps",
                            value: function (e) {
                                var t = this.input;
                                e.value !== this.state.value && (t === document.activeElement ? this.setState({ blurValue: String(e.value).toUpperCase() }) : this.setState({ value: String(e.value).toUpperCase() }));
                            },
                        },
                        {
                            key: "componentWillUnmount",
                            value: function () {
                                this.unbindEventListeners();
                            },
                        },
                        {
                            key: "render",
                            value: function () {
                                var e = this,
                                    t = (0, p.default)(
                                        {
                                            default: { wrap: { position: "relative" } },
                                            "user-override": {
                                                wrap: this.props.style && this.props.style.wrap ? this.props.style.wrap : {},
                                                input: this.props.style && this.props.style.input ? this.props.style.input : {},
                                                label: this.props.style && this.props.style.label ? this.props.style.label : {},
                                            },
                                            "dragLabel-true": { label: { cursor: "ew-resize" } },
                                        },
                                        { "user-override": !0 },
                                        this.props
                                    );
                                return c.default.createElement(
                                    "div",
                                    { style: t.wrap },
                                    c.default.createElement("input", {
                                        style: t.input,
                                        ref: function (t) {
                                            return (e.input = t);
                                        },
                                        value: this.state.value,
                                        onKeyDown: this.handleKeyDown,
                                        onChange: this.handleChange,
                                        onBlur: this.handleBlur,
                                        placeholder: this.props.placeholder,
                                        spellCheck: "false",
                                    }),
                                    this.props.label ? c.default.createElement("span", { style: t.label, onMouseDown: this.handleMouseDown }, this.props.label) : null
                                );
                            },
                        },
                    ]),
                    t
                );
            })());
        t.default = f;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function a(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function i(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Hue = void 0);
        var l = (function () {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                    }
                }
                return function (t, r, n) {
                    return r && e(t.prototype, r), n && e(t, n), t;
                };
            })(),
            u = r(0),
            s = n(u),
            c = n(r(2)),
            p = (function (e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return (t.default = e), t;
            })(r(264)),
            f = (t.Hue = (function (e) {
                function t() {
                    var e, r, n, i;
                    o(this, t);
                    for (var l = arguments.length, u = Array(l), s = 0; s < l; s++) u[s] = arguments[s];
                    return (
                        (r = n = a(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [this].concat(u)))),
                        (n.handleChange = function (e, t) {
                            var r = p.calculateChange(e, t, n.props, n.container);
                            r && n.props.onChange && n.props.onChange(r, e);
                        }),
                        (n.handleMouseDown = function (e) {
                            n.handleChange(e, !0), window.addEventListener("mousemove", n.handleChange), window.addEventListener("mouseup", n.handleMouseUp);
                        }),
                        (n.handleMouseUp = function () {
                            n.unbindEventListeners();
                        }),
                        (i = r),
                        a(n, i)
                    );
                }
                return (
                    i(t, u.PureComponent || u.Component),
                    l(t, [
                        {
                            key: "componentWillUnmount",
                            value: function () {
                                this.unbindEventListeners();
                            },
                        },
                        {
                            key: "unbindEventListeners",
                            value: function () {
                                window.removeEventListener("mousemove", this.handleChange), window.removeEventListener("mouseup", this.handleMouseUp);
                            },
                        },
                        {
                            key: "render",
                            value: function () {
                                var e = this,
                                    t = this.props.direction,
                                    r = void 0 === t ? "horizontal" : t,
                                    n = (0, c.default)(
                                        {
                                            default: {
                                                hue: { absolute: "0px 0px 0px 0px", borderRadius: this.props.radius, boxShadow: this.props.shadow },
                                                container: { padding: "0 2px", position: "relative", height: "100%" },
                                                pointer: { position: "absolute", left: (100 * this.props.hsl.h) / 360 + "%" },
                                                slider: { marginTop: "1px", width: "4px", borderRadius: "1px", height: "8px", boxShadow: "0 0 2px rgba(0, 0, 0, .6)", background: "#fff", transform: "translateX(-2px)" },
                                            },
                                            vertical: { pointer: { left: "0px", top: (-100 * this.props.hsl.h) / 360 + 100 + "%" } },
                                        },
                                        { vertical: "vertical" === r }
                                    );
                                return s.default.createElement(
                                    "div",
                                    { style: n.hue },
                                    s.default.createElement(
                                        "div",
                                        {
                                            className: "hue-" + r,
                                            style: n.container,
                                            ref: function (t) {
                                                return (e.container = t);
                                            },
                                            onMouseDown: this.handleMouseDown,
                                            onTouchMove: this.handleChange,
                                            onTouchStart: this.handleChange,
                                        },
                                        s.default.createElement(
                                            "style",
                                            null,
                                            "\n            .hue-horizontal {\n              background: linear-gradient(to right, #f00 0%, #ff0 17%, #0f0\n                33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n              background: -webkit-linear-gradient(to right, #f00 0%, #ff0\n                17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n            }\n\n            .hue-vertical {\n              background: linear-gradient(to top, #f00 0%, #ff0 17%, #0f0 33%,\n                #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n              background: -webkit-linear-gradient(to top, #f00 0%, #ff0 17%,\n                #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n            }\n          "
                                        ),
                                        s.default.createElement("div", { style: n.pointer }, this.props.pointer ? s.default.createElement(this.props.pointer, this.props) : s.default.createElement("div", { style: n.slider }))
                                    )
                                );
                            },
                        },
                    ]),
                    t
                );
            })());
        t.default = f;
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        t.calculateChange = function (e, t, r, n) {
            e.preventDefault();
            var o = n.clientWidth,
                a = n.clientHeight,
                i = "number" == typeof e.pageX ? e.pageX : e.touches[0].pageX,
                l = "number" == typeof e.pageY ? e.pageY : e.touches[0].pageY,
                u = i - (n.getBoundingClientRect().left + window.pageXOffset),
                s = l - (n.getBoundingClientRect().top + window.pageYOffset);
            if ("vertical" === r.direction) {
                var c = void 0;
                if (((c = s < 0 ? 359 : s > a ? 0 : (360 * ((-100 * s) / a + 100)) / 100), r.hsl.h !== c)) return { h: c, s: r.hsl.s, l: r.hsl.l, a: r.hsl.a, source: "rgb" };
            } else {
                var p = void 0;
                if (((p = u < 0 ? 0 : u > o ? 359 : (360 * ((100 * u) / o)) / 100), r.hsl.h !== p)) return { h: p, s: r.hsl.s, l: r.hsl.l, a: r.hsl.a, source: "rgb" };
            }
            return null;
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Raised = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = (t.Raised = function (e) {
                var t = e.zDepth,
                    r = e.radius,
                    n = e.background,
                    a = e.children,
                    l = (0, i.default)(
                        {
                            default: {
                                wrap: { position: "relative", display: "inline-block" },
                                content: { position: "relative" },
                                bg: { absolute: "0px 0px 0px 0px", boxShadow: "0 " + t + "px " + 4 * t + "px rgba(0,0,0,.24)", borderRadius: r, background: n },
                            },
                            "zDepth-0": { bg: { boxShadow: "none" } },
                            "zDepth-1": { bg: { boxShadow: "0 2px 10px rgba(0,0,0,.12), 0 2px 5px rgba(0,0,0,.16)" } },
                            "zDepth-2": { bg: { boxShadow: "0 6px 20px rgba(0,0,0,.19), 0 8px 17px rgba(0,0,0,.2)" } },
                            "zDepth-3": { bg: { boxShadow: "0 17px 50px rgba(0,0,0,.19), 0 12px 15px rgba(0,0,0,.24)" } },
                            "zDepth-4": { bg: { boxShadow: "0 25px 55px rgba(0,0,0,.21), 0 16px 28px rgba(0,0,0,.22)" } },
                            "zDepth-5": { bg: { boxShadow: "0 40px 77px rgba(0,0,0,.22), 0 27px 24px rgba(0,0,0,.2)" } },
                            square: { bg: { borderRadius: "0" } },
                            circle: { bg: { borderRadius: "50%" } },
                        },
                        { "zDepth-1": 1 === t }
                    );
                return o.default.createElement("div", { style: l.wrap }, o.default.createElement("div", { style: l.bg }), o.default.createElement("div", { style: l.content }, a));
            });
        (l.propTypes = { background: a.default.string, zDepth: a.default.oneOf([0, 1, 2, 3, 4, 5]), radius: a.default.number }), (l.defaultProps = { background: "#fff", zDepth: 1, radius: 2 }), (t.default = l);
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function a(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function i(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Saturation = void 0);
        var l = (function () {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                    }
                }
                return function (t, r, n) {
                    return r && e(t.prototype, r), n && e(t, n), t;
                };
            })(),
            u = r(0),
            s = n(u),
            c = n(r(2)),
            p = n(r(267)),
            f = (function (e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return (t.default = e), t;
            })(r(270)),
            d = (t.Saturation = (function (e) {
                function t(e) {
                    o(this, t);
                    var r = a(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                    return (
                        (r.handleChange = function (e, t) {
                            r.props.onChange && r.throttle(r.props.onChange, f.calculateChange(e, t, r.props, r.container), e);
                        }),
                        (r.handleMouseDown = function (e) {
                            r.handleChange(e, !0), window.addEventListener("mousemove", r.handleChange), window.addEventListener("mouseup", r.handleMouseUp);
                        }),
                        (r.handleMouseUp = function () {
                            r.unbindEventListeners();
                        }),
                        (r.throttle = (0, p.default)(function (e, t, r) {
                            e(t, r);
                        }, 50)),
                        r
                    );
                }
                return (
                    i(t, u.PureComponent || u.Component),
                    l(t, [
                        {
                            key: "componentWillUnmount",
                            value: function () {
                                this.unbindEventListeners();
                            },
                        },
                        {
                            key: "unbindEventListeners",
                            value: function () {
                                window.removeEventListener("mousemove", this.handleChange), window.removeEventListener("mouseup", this.handleMouseUp);
                            },
                        },
                        {
                            key: "render",
                            value: function () {
                                var e = this,
                                    t = this.props.style || {},
                                    r = t.color,
                                    n = t.white,
                                    o = t.black,
                                    a = t.pointer,
                                    i = t.circle,
                                    l = (0, c.default)(
                                        {
                                            default: {
                                                color: { absolute: "0px 0px 0px 0px", background: "hsl(" + this.props.hsl.h + ",100%, 50%)", borderRadius: this.props.radius },
                                                white: { absolute: "0px 0px 0px 0px", borderRadius: this.props.radius },
                                                black: { absolute: "0px 0px 0px 0px", boxShadow: this.props.shadow, borderRadius: this.props.radius },
                                                pointer: { position: "absolute", top: -100 * this.props.hsv.v + 100 + "%", left: 100 * this.props.hsv.s + "%", cursor: "default" },
                                                circle: {
                                                    width: "4px",
                                                    height: "4px",
                                                    boxShadow: "0 0 0 1.5px #fff, inset 0 0 1px 1px rgba(0,0,0,.3),\n            0 0 1px 2px rgba(0,0,0,.4)",
                                                    borderRadius: "50%",
                                                    cursor: "hand",
                                                    transform: "translate(-2px, -2px)",
                                                },
                                            },
                                            custom: { color: r, white: n, black: o, pointer: a, circle: i },
                                        },
                                        { custom: !!this.props.style }
                                    );
                                return s.default.createElement(
                                    "div",
                                    {
                                        style: l.color,
                                        ref: function (t) {
                                            return (e.container = t);
                                        },
                                        onMouseDown: this.handleMouseDown,
                                        onTouchMove: this.handleChange,
                                        onTouchStart: this.handleChange,
                                    },
                                    s.default.createElement(
                                        "style",
                                        null,
                                        "\n          .saturation-white {\n            background: -webkit-linear-gradient(to right, #fff, rgba(255,255,255,0));\n            background: linear-gradient(to right, #fff, rgba(255,255,255,0));\n          }\n          .saturation-black {\n            background: -webkit-linear-gradient(to top, #000, rgba(0,0,0,0));\n            background: linear-gradient(to top, #000, rgba(0,0,0,0));\n          }\n        "
                                    ),
                                    s.default.createElement(
                                        "div",
                                        { style: l.white, className: "saturation-white" },
                                        s.default.createElement("div", { style: l.black, className: "saturation-black" }),
                                        s.default.createElement("div", { style: l.pointer }, this.props.pointer ? s.default.createElement(this.props.pointer, this.props) : s.default.createElement("div", { style: l.circle }))
                                    )
                                );
                            },
                        },
                    ]),
                    t
                );
            })());
        t.default = d;
    },
    function (e, t, r) {
        var n = r(106),
            o = r(12),
            a = "Expected a function";
        e.exports = function (e, t, r) {
            var i = !0,
                l = !0;
            if ("function" != typeof e) throw new TypeError(a);
            return o(r) && ((i = "leading" in r ? !!r.leading : i), (l = "trailing" in r ? !!r.trailing : l)), n(e, t, { leading: i, maxWait: t, trailing: l });
        };
    },
    function (e, t, r) {
        var n = r(9);
        e.exports = function () {
            return n.Date.now();
        };
    },
    function (e, t, r) {
        var n = r(12),
            o = r(37),
            a = NaN,
            i = /^\s+|\s+$/g,
            l = /^[-+]0x[0-9a-f]+$/i,
            u = /^0b[01]+$/i,
            s = /^0o[0-7]+$/i,
            c = parseInt;
        e.exports = function (e) {
            if ("number" == typeof e) return e;
            if (o(e)) return a;
            if (n(e)) {
                var t = "function" == typeof e.valueOf ? e.valueOf() : e;
                e = n(t) ? t + "" : t;
            }
            if ("string" != typeof e) return 0 === e ? e : +e;
            e = e.replace(i, "");
            var r = u.test(e);
            return r || s.test(e) ? c(e.slice(2), r ? 2 : 8) : l.test(e) ? a : +e;
        };
    },
    function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        t.calculateChange = function (e, t, r, n) {
            e.preventDefault();
            var o = n.getBoundingClientRect(),
                a = o.width,
                i = o.height,
                l = "number" == typeof e.pageX ? e.pageX : e.touches[0].pageX,
                u = "number" == typeof e.pageY ? e.pageY : e.touches[0].pageY,
                s = l - (n.getBoundingClientRect().left + window.pageXOffset),
                c = u - (n.getBoundingClientRect().top + window.pageYOffset);
            s < 0 ? (s = 0) : s > a ? (s = a) : c < 0 ? (c = 0) : c > i && (c = i);
            var p = (100 * s) / a,
                f = (-100 * c) / i + 100;
            return { h: r.hsl.h, s: p, v: f, a: r.hsl.a, source: "rgb" };
        };
    },
    function (e, t, r) {
        e.exports = r(272);
    },
    function (e, t, r) {
        var n = r(100),
            o = r(99),
            a = r(85),
            i = r(8);
        e.exports = function (e, t) {
            return (i(e) ? n : o)(e, a(t));
        };
    },
    function (e, t, r) {
        var n;
        !(function (o) {
            function a(e, t) {
                if (((e = e || ""), (t = t || {}), e instanceof a)) return e;
                if (!(this instanceof a)) return new a(e, t);
                var r = i(e);
                (this._originalInput = e),
                    (this._r = r.r),
                    (this._g = r.g),
                    (this._b = r.b),
                    (this._a = r.a),
                    (this._roundA = z(100 * this._a) / 100),
                    (this._format = t.format || r.format),
                    (this._gradientType = t.gradientType),
                    this._r < 1 && (this._r = z(this._r)),
                    this._g < 1 && (this._g = z(this._g)),
                    this._b < 1 && (this._b = z(this._b)),
                    (this._ok = r.ok),
                    (this._tc_id = K++);
            }
            function i(e) {
                var t = { r: 0, g: 0, b: 0 },
                    r = 1,
                    n = null,
                    o = null,
                    a = null,
                    i = !1,
                    u = !1;
                return (
                    "string" == typeof e && (e = F(e)),
                    "object" == typeof e &&
                        (L(e.r) && L(e.g) && L(e.b)
                            ? ((t = l(e.r, e.g, e.b)), (i = !0), (u = "%" === String(e.r).substr(-1) ? "prgb" : "rgb"))
                            : L(e.h) && L(e.s) && L(e.v)
                            ? ((n = A(e.s)), (o = A(e.v)), (t = p(e.h, n, o)), (i = !0), (u = "hsv"))
                            : L(e.h) && L(e.s) && L(e.l) && ((n = A(e.s)), (a = A(e.l)), (t = s(e.h, n, a)), (i = !0), (u = "hsl")),
                        e.hasOwnProperty("a") && (r = e.a)),
                    (r = M(r)),
                    { ok: i, format: e.format || u, r: q(255, G(t.r, 0)), g: q(255, G(t.g, 0)), b: q(255, G(t.b, 0)), a: r }
                );
            }
            function l(e, t, r) {
                return { r: 255 * D(e, 255), g: 255 * D(t, 255), b: 255 * D(r, 255) };
            }
            function u(e, t, r) {
                (e = D(e, 255)), (t = D(t, 255)), (r = D(r, 255));
                var n,
                    o,
                    a = G(e, t, r),
                    i = q(e, t, r),
                    l = (a + i) / 2;
                if (a == i) n = o = 0;
                else {
                    var u = a - i;
                    switch (((o = l > 0.5 ? u / (2 - a - i) : u / (a + i)), a)) {
                        case e:
                            n = (t - r) / u + (t < r ? 6 : 0);
                            break;
                        case t:
                            n = (r - e) / u + 2;
                            break;
                        case r:
                            n = (e - t) / u + 4;
                    }
                    n /= 6;
                }
                return { h: n, s: o, l: l };
            }
            function s(e, t, r) {
                function n(e, t, r) {
                    return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + 6 * (t - e) * r : r < 0.5 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e;
                }
                var o, a, i;
                if (((e = D(e, 360)), (t = D(t, 100)), (r = D(r, 100)), 0 === t)) o = a = i = r;
                else {
                    var l = r < 0.5 ? r * (1 + t) : r + t - r * t,
                        u = 2 * r - l;
                    (o = n(u, l, e + 1 / 3)), (a = n(u, l, e)), (i = n(u, l, e - 1 / 3));
                }
                return { r: 255 * o, g: 255 * a, b: 255 * i };
            }
            function c(e, t, r) {
                (e = D(e, 255)), (t = D(t, 255)), (r = D(r, 255));
                var n,
                    o,
                    a = G(e, t, r),
                    i = q(e, t, r),
                    l = a,
                    u = a - i;
                if (((o = 0 === a ? 0 : u / a), a == i)) n = 0;
                else {
                    switch (a) {
                        case e:
                            n = (t - r) / u + (t < r ? 6 : 0);
                            break;
                        case t:
                            n = (r - e) / u + 2;
                            break;
                        case r:
                            n = (e - t) / u + 4;
                    }
                    n /= 6;
                }
                return { h: n, s: o, v: l };
            }
            function p(e, t, r) {
                (e = 6 * D(e, 360)), (t = D(t, 100)), (r = D(r, 100));
                var n = o.floor(e),
                    a = e - n,
                    i = r * (1 - t),
                    l = r * (1 - a * t),
                    u = r * (1 - (1 - a) * t),
                    s = n % 6;
                return { r: 255 * [r, l, i, i, u, r][s], g: 255 * [u, r, r, l, i, i][s], b: 255 * [i, i, u, r, r, l][s] };
            }
            function f(e, t, r, n) {
                var o = [B(z(e).toString(16)), B(z(t).toString(16)), B(z(r).toString(16))];
                return n && o[0].charAt(0) == o[0].charAt(1) && o[1].charAt(0) == o[1].charAt(1) && o[2].charAt(0) == o[2].charAt(1) ? o[0].charAt(0) + o[1].charAt(0) + o[2].charAt(0) : o.join("");
            }
            function d(e, t, r, n, o) {
                var a = [B(z(e).toString(16)), B(z(t).toString(16)), B(z(r).toString(16)), B(U(n))];
                return o && a[0].charAt(0) == a[0].charAt(1) && a[1].charAt(0) == a[1].charAt(1) && a[2].charAt(0) == a[2].charAt(1) && a[3].charAt(0) == a[3].charAt(1)
                    ? a[0].charAt(0) + a[1].charAt(0) + a[2].charAt(0) + a[3].charAt(0)
                    : a.join("");
            }
            function _(e, t, r, n) {
                return [B(U(n)), B(z(e).toString(16)), B(z(t).toString(16)), B(z(r).toString(16))].join("");
            }
            function h(e, t) {
                t = 0 === t ? 0 : t || 10;
                var r = a(e).toHsl();
                return (r.s -= t / 100), (r.s = T(r.s)), a(r);
            }
            function b(e, t) {
                t = 0 === t ? 0 : t || 10;
                var r = a(e).toHsl();
                return (r.s += t / 100), (r.s = T(r.s)), a(r);
            }
            function m(e) {
                return a(e).desaturate(100);
            }
            function g(e, t) {
                t = 0 === t ? 0 : t || 10;
                var r = a(e).toHsl();
                return (r.l += t / 100), (r.l = T(r.l)), a(r);
            }
            function v(e, t) {
                t = 0 === t ? 0 : t || 10;
                var r = a(e).toRgb();
                return (r.r = G(0, q(255, r.r - z((-t / 100) * 255)))), (r.g = G(0, q(255, r.g - z((-t / 100) * 255)))), (r.b = G(0, q(255, r.b - z((-t / 100) * 255)))), a(r);
            }
            function y(e, t) {
                t = 0 === t ? 0 : t || 10;
                var r = a(e).toHsl();
                return (r.l -= t / 100), (r.l = T(r.l)), a(r);
            }
            function E(e, t) {
                var r = a(e).toHsl(),
                    n = (r.h + t) % 360;
                return (r.h = n < 0 ? 360 + n : n), a(r);
            }
            function C(e) {
                var t = a(e).toHsl();
                return (t.h = (t.h + 180) % 360), a(t);
            }
            function k(e) {
                var t = a(e).toHsl(),
                    r = t.h;
                return [a(e), a({ h: (r + 120) % 360, s: t.s, l: t.l }), a({ h: (r + 240) % 360, s: t.s, l: t.l })];
            }
            function P(e) {
                var t = a(e).toHsl(),
                    r = t.h;
                return [a(e), a({ h: (r + 90) % 360, s: t.s, l: t.l }), a({ h: (r + 180) % 360, s: t.s, l: t.l }), a({ h: (r + 270) % 360, s: t.s, l: t.l })];
            }
            function x(e) {
                var t = a(e).toHsl(),
                    r = t.h;
                return [a(e), a({ h: (r + 72) % 360, s: t.s, l: t.l }), a({ h: (r + 216) % 360, s: t.s, l: t.l })];
            }
            function w(e, t, r) {
                (t = t || 6), (r = r || 30);
                var n = a(e).toHsl(),
                    o = 360 / r,
                    i = [a(e)];
                for (n.h = (n.h - ((o * t) >> 1) + 720) % 360; --t; ) (n.h = (n.h + o) % 360), i.push(a(n));
                return i;
            }
            function O(e, t) {
                t = t || 6;
                for (var r = a(e).toHsv(), n = r.h, o = r.s, i = r.v, l = [], u = 1 / t; t--; ) l.push(a({ h: n, s: o, v: i })), (i = (i + u) % 1);
                return l;
            }
            function M(e) {
                return (e = parseFloat(e)), (isNaN(e) || e < 0 || e > 1) && (e = 1), e;
            }
            function D(e, t) {
                R(e) && (e = "100%");
                var r = j(e);
                return (e = q(t, G(0, parseFloat(e)))), r && (e = parseInt(e * t, 10) / 100), o.abs(e - t) < 1e-6 ? 1 : (e % t) / parseFloat(t);
            }
            function T(e) {
                return q(1, G(0, e));
            }
            function S(e) {
                return parseInt(e, 16);
            }
            function R(e) {
                return "string" == typeof e && -1 != e.indexOf(".") && 1 === parseFloat(e);
            }
            function j(e) {
                return "string" == typeof e && -1 != e.indexOf("%");
            }
            function B(e) {
                return 1 == e.length ? "0" + e : "" + e;
            }
            function A(e) {
                return e <= 1 && (e = 100 * e + "%"), e;
            }
            function U(e) {
                return o.round(255 * parseFloat(e)).toString(16);
            }
            function I(e) {
                return S(e) / 255;
            }
            function L(e) {
                return !!X.CSS_UNIT.exec(e);
            }
            function F(e) {
                e = e.replace(W, "").replace(H, "").toLowerCase();
                var t = !1;
                if (Y[e]) (e = Y[e]), (t = !0);
                else if ("transparent" == e) return { r: 0, g: 0, b: 0, a: 0, format: "name" };
                var r;
                return (r = X.rgb.exec(e))
                    ? { r: r[1], g: r[2], b: r[3] }
                    : (r = X.rgba.exec(e))
                    ? { r: r[1], g: r[2], b: r[3], a: r[4] }
                    : (r = X.hsl.exec(e))
                    ? { h: r[1], s: r[2], l: r[3] }
                    : (r = X.hsla.exec(e))
                    ? { h: r[1], s: r[2], l: r[3], a: r[4] }
                    : (r = X.hsv.exec(e))
                    ? { h: r[1], s: r[2], v: r[3] }
                    : (r = X.hsva.exec(e))
                    ? { h: r[1], s: r[2], v: r[3], a: r[4] }
                    : (r = X.hex8.exec(e))
                    ? { r: S(r[1]), g: S(r[2]), b: S(r[3]), a: I(r[4]), format: t ? "name" : "hex8" }
                    : (r = X.hex6.exec(e))
                    ? { r: S(r[1]), g: S(r[2]), b: S(r[3]), format: t ? "name" : "hex" }
                    : (r = X.hex4.exec(e))
                    ? { r: S(r[1] + "" + r[1]), g: S(r[2] + "" + r[2]), b: S(r[3] + "" + r[3]), a: I(r[4] + "" + r[4]), format: t ? "name" : "hex8" }
                    : !!(r = X.hex3.exec(e)) && { r: S(r[1] + "" + r[1]), g: S(r[2] + "" + r[2]), b: S(r[3] + "" + r[3]), format: t ? "name" : "hex" };
            }
            function N(e) {
                var t, r;
                return (
                    (e = e || { level: "AA", size: "small" }),
                    (t = (e.level || "AA").toUpperCase()),
                    (r = (e.size || "small").toLowerCase()),
                    "AA" !== t && "AAA" !== t && (t = "AA"),
                    "small" !== r && "large" !== r && (r = "small"),
                    { level: t, size: r }
                );
            }
            var W = /^\s+/,
                H = /\s+$/,
                K = 0,
                z = o.round,
                q = o.min,
                G = o.max,
                V = o.random;
            (a.prototype = {
                isDark: function () {
                    return this.getBrightness() < 128;
                },
                isLight: function () {
                    return !this.isDark();
                },
                isValid: function () {
                    return this._ok;
                },
                getOriginalInput: function () {
                    return this._originalInput;
                },
                getFormat: function () {
                    return this._format;
                },
                getAlpha: function () {
                    return this._a;
                },
                getBrightness: function () {
                    var e = this.toRgb();
                    return (299 * e.r + 587 * e.g + 114 * e.b) / 1e3;
                },
                getLuminance: function () {
                    var e,
                        t,
                        r,
                        n,
                        a,
                        i,
                        l = this.toRgb();
                    return (
                        (e = l.r / 255),
                        (t = l.g / 255),
                        (r = l.b / 255),
                        (n = e <= 0.03928 ? e / 12.92 : o.pow((e + 0.055) / 1.055, 2.4)),
                        (a = t <= 0.03928 ? t / 12.92 : o.pow((t + 0.055) / 1.055, 2.4)),
                        (i = r <= 0.03928 ? r / 12.92 : o.pow((r + 0.055) / 1.055, 2.4)),
                        0.2126 * n + 0.7152 * a + 0.0722 * i
                    );
                },
                setAlpha: function (e) {
                    return (this._a = M(e)), (this._roundA = z(100 * this._a) / 100), this;
                },
                toHsv: function () {
                    var e = c(this._r, this._g, this._b);
                    return { h: 360 * e.h, s: e.s, v: e.v, a: this._a };
                },
                toHsvString: function () {
                    var e = c(this._r, this._g, this._b),
                        t = z(360 * e.h),
                        r = z(100 * e.s),
                        n = z(100 * e.v);
                    return 1 == this._a ? "hsv(" + t + ", " + r + "%, " + n + "%)" : "hsva(" + t + ", " + r + "%, " + n + "%, " + this._roundA + ")";
                },
                toHsl: function () {
                    var e = u(this._r, this._g, this._b);
                    return { h: 360 * e.h, s: e.s, l: e.l, a: this._a };
                },
                toHslString: function () {
                    var e = u(this._r, this._g, this._b),
                        t = z(360 * e.h),
                        r = z(100 * e.s),
                        n = z(100 * e.l);
                    return 1 == this._a ? "hsl(" + t + ", " + r + "%, " + n + "%)" : "hsla(" + t + ", " + r + "%, " + n + "%, " + this._roundA + ")";
                },
                toHex: function (e) {
                    return f(this._r, this._g, this._b, e);
                },
                toHexString: function (e) {
                    return "#" + this.toHex(e);
                },
                toHex8: function (e) {
                    return d(this._r, this._g, this._b, this._a, e);
                },
                toHex8String: function (e) {
                    return "#" + this.toHex8(e);
                },
                toRgb: function () {
                    return { r: z(this._r), g: z(this._g), b: z(this._b), a: this._a };
                },
                toRgbString: function () {
                    return 1 == this._a ? "rgb(" + z(this._r) + ", " + z(this._g) + ", " + z(this._b) + ")" : "rgba(" + z(this._r) + ", " + z(this._g) + ", " + z(this._b) + ", " + this._roundA + ")";
                },
                toPercentageRgb: function () {
                    return { r: z(100 * D(this._r, 255)) + "%", g: z(100 * D(this._g, 255)) + "%", b: z(100 * D(this._b, 255)) + "%", a: this._a };
                },
                toPercentageRgbString: function () {
                    return 1 == this._a
                        ? "rgb(" + z(100 * D(this._r, 255)) + "%, " + z(100 * D(this._g, 255)) + "%, " + z(100 * D(this._b, 255)) + "%)"
                        : "rgba(" + z(100 * D(this._r, 255)) + "%, " + z(100 * D(this._g, 255)) + "%, " + z(100 * D(this._b, 255)) + "%, " + this._roundA + ")";
                },
                toName: function () {
                    return 0 === this._a ? "transparent" : !(this._a < 1) && ($[f(this._r, this._g, this._b, !0)] || !1);
                },
                toFilter: function (e) {
                    var t = "#" + _(this._r, this._g, this._b, this._a),
                        r = t,
                        n = this._gradientType ? "GradientType = 1, " : "";
                    if (e) {
                        var o = a(e);
                        r = "#" + _(o._r, o._g, o._b, o._a);
                    }
                    return "progid:DXImageTransform.Microsoft.gradient(" + n + "startColorstr=" + t + ",endColorstr=" + r + ")";
                },
                toString: function (e) {
                    var t = !!e;
                    e = e || this._format;
                    var r = !1,
                        n = this._a < 1 && this._a >= 0;
                    return t || !n || ("hex" !== e && "hex6" !== e && "hex3" !== e && "hex4" !== e && "hex8" !== e && "name" !== e)
                        ? ("rgb" === e && (r = this.toRgbString()),
                          "prgb" === e && (r = this.toPercentageRgbString()),
                          ("hex" !== e && "hex6" !== e) || (r = this.toHexString()),
                          "hex3" === e && (r = this.toHexString(!0)),
                          "hex4" === e && (r = this.toHex8String(!0)),
                          "hex8" === e && (r = this.toHex8String()),
                          "name" === e && (r = this.toName()),
                          "hsl" === e && (r = this.toHslString()),
                          "hsv" === e && (r = this.toHsvString()),
                          r || this.toHexString())
                        : "name" === e && 0 === this._a
                        ? this.toName()
                        : this.toRgbString();
                },
                clone: function () {
                    return a(this.toString());
                },
                _applyModification: function (e, t) {
                    var r = e.apply(null, [this].concat([].slice.call(t)));
                    return (this._r = r._r), (this._g = r._g), (this._b = r._b), this.setAlpha(r._a), this;
                },
                lighten: function () {
                    return this._applyModification(g, arguments);
                },
                brighten: function () {
                    return this._applyModification(v, arguments);
                },
                darken: function () {
                    return this._applyModification(y, arguments);
                },
                desaturate: function () {
                    return this._applyModification(h, arguments);
                },
                saturate: function () {
                    return this._applyModification(b, arguments);
                },
                greyscale: function () {
                    return this._applyModification(m, arguments);
                },
                spin: function () {
                    return this._applyModification(E, arguments);
                },
                _applyCombination: function (e, t) {
                    return e.apply(null, [this].concat([].slice.call(t)));
                },
                analogous: function () {
                    return this._applyCombination(w, arguments);
                },
                complement: function () {
                    return this._applyCombination(C, arguments);
                },
                monochromatic: function () {
                    return this._applyCombination(O, arguments);
                },
                splitcomplement: function () {
                    return this._applyCombination(x, arguments);
                },
                triad: function () {
                    return this._applyCombination(k, arguments);
                },
                tetrad: function () {
                    return this._applyCombination(P, arguments);
                },
            }),
                (a.fromRatio = function (e, t) {
                    if ("object" == typeof e) {
                        var r = {};
                        for (var n in e) e.hasOwnProperty(n) && (r[n] = "a" === n ? e[n] : A(e[n]));
                        e = r;
                    }
                    return a(e, t);
                }),
                (a.equals = function (e, t) {
                    return !(!e || !t) && a(e).toRgbString() == a(t).toRgbString();
                }),
                (a.random = function () {
                    return a.fromRatio({ r: V(), g: V(), b: V() });
                }),
                (a.mix = function (e, t, r) {
                    r = 0 === r ? 0 : r || 50;
                    var n = a(e).toRgb(),
                        o = a(t).toRgb(),
                        i = r / 100;
                    return a({ r: (o.r - n.r) * i + n.r, g: (o.g - n.g) * i + n.g, b: (o.b - n.b) * i + n.b, a: (o.a - n.a) * i + n.a });
                }),
                (a.readability = function (e, t) {
                    var r = a(e),
                        n = a(t);
                    return (o.max(r.getLuminance(), n.getLuminance()) + 0.05) / (o.min(r.getLuminance(), n.getLuminance()) + 0.05);
                }),
                (a.isReadable = function (e, t, r) {
                    var n,
                        o,
                        i = a.readability(e, t);
                    switch (((o = !1), (n = N(r)).level + n.size)) {
                        case "AAsmall":
                        case "AAAlarge":
                            o = i >= 4.5;
                            break;
                        case "AAlarge":
                            o = i >= 3;
                            break;
                        case "AAAsmall":
                            o = i >= 7;
                    }
                    return o;
                }),
                (a.mostReadable = function (e, t, r) {
                    var n,
                        o,
                        i,
                        l,
                        u = null,
                        s = 0;
                    (o = (r = r || {}).includeFallbackColors), (i = r.level), (l = r.size);
                    for (var c = 0; c < t.length; c++) (n = a.readability(e, t[c])) > s && ((s = n), (u = a(t[c])));
                    return a.isReadable(e, u, { level: i, size: l }) || !o ? u : ((r.includeFallbackColors = !1), a.mostReadable(e, ["#fff", "#000"], r));
                });
            var Y = (a.names = {
                    aliceblue: "f0f8ff",
                    antiquewhite: "faebd7",
                    aqua: "0ff",
                    aquamarine: "7fffd4",
                    azure: "f0ffff",
                    beige: "f5f5dc",
                    bisque: "ffe4c4",
                    black: "000",
                    blanchedalmond: "ffebcd",
                    blue: "00f",
                    blueviolet: "8a2be2",
                    brown: "a52a2a",
                    burlywood: "deb887",
                    burntsienna: "ea7e5d",
                    cadetblue: "5f9ea0",
                    chartreuse: "7fff00",
                    chocolate: "d2691e",
                    coral: "ff7f50",
                    cornflowerblue: "6495ed",
                    cornsilk: "fff8dc",
                    crimson: "dc143c",
                    cyan: "0ff",
                    darkblue: "00008b",
                    darkcyan: "008b8b",
                    darkgoldenrod: "b8860b",
                    darkgray: "a9a9a9",
                    darkgreen: "006400",
                    darkgrey: "a9a9a9",
                    darkkhaki: "bdb76b",
                    darkmagenta: "8b008b",
                    darkolivegreen: "556b2f",
                    darkorange: "ff8c00",
                    darkorchid: "9932cc",
                    darkred: "8b0000",
                    darksalmon: "e9967a",
                    darkseagreen: "8fbc8f",
                    darkslateblue: "483d8b",
                    darkslategray: "2f4f4f",
                    darkslategrey: "2f4f4f",
                    darkturquoise: "00ced1",
                    darkviolet: "9400d3",
                    deeppink: "ff1493",
                    deepskyblue: "00bfff",
                    dimgray: "696969",
                    dimgrey: "696969",
                    dodgerblue: "1e90ff",
                    firebrick: "b22222",
                    floralwhite: "fffaf0",
                    forestgreen: "228b22",
                    fuchsia: "f0f",
                    gainsboro: "dcdcdc",
                    ghostwhite: "f8f8ff",
                    gold: "ffd700",
                    goldenrod: "daa520",
                    gray: "808080",
                    green: "008000",
                    greenyellow: "adff2f",
                    grey: "808080",
                    honeydew: "f0fff0",
                    hotpink: "ff69b4",
                    indianred: "cd5c5c",
                    indigo: "4b0082",
                    ivory: "fffff0",
                    khaki: "f0e68c",
                    lavender: "e6e6fa",
                    lavenderblush: "fff0f5",
                    lawngreen: "7cfc00",
                    lemonchiffon: "fffacd",
                    lightblue: "add8e6",
                    lightcoral: "f08080",
                    lightcyan: "e0ffff",
                    lightgoldenrodyellow: "fafad2",
                    lightgray: "d3d3d3",
                    lightgreen: "90ee90",
                    lightgrey: "d3d3d3",
                    lightpink: "ffb6c1",
                    lightsalmon: "ffa07a",
                    lightseagreen: "20b2aa",
                    lightskyblue: "87cefa",
                    lightslategray: "789",
                    lightslategrey: "789",
                    lightsteelblue: "b0c4de",
                    lightyellow: "ffffe0",
                    lime: "0f0",
                    limegreen: "32cd32",
                    linen: "faf0e6",
                    magenta: "f0f",
                    maroon: "800000",
                    mediumaquamarine: "66cdaa",
                    mediumblue: "0000cd",
                    mediumorchid: "ba55d3",
                    mediumpurple: "9370db",
                    mediumseagreen: "3cb371",
                    mediumslateblue: "7b68ee",
                    mediumspringgreen: "00fa9a",
                    mediumturquoise: "48d1cc",
                    mediumvioletred: "c71585",
                    midnightblue: "191970",
                    mintcream: "f5fffa",
                    mistyrose: "ffe4e1",
                    moccasin: "ffe4b5",
                    navajowhite: "ffdead",
                    navy: "000080",
                    oldlace: "fdf5e6",
                    olive: "808000",
                    olivedrab: "6b8e23",
                    orange: "ffa500",
                    orangered: "ff4500",
                    orchid: "da70d6",
                    palegoldenrod: "eee8aa",
                    palegreen: "98fb98",
                    paleturquoise: "afeeee",
                    palevioletred: "db7093",
                    papayawhip: "ffefd5",
                    peachpuff: "ffdab9",
                    peru: "cd853f",
                    pink: "ffc0cb",
                    plum: "dda0dd",
                    powderblue: "b0e0e6",
                    purple: "800080",
                    rebeccapurple: "663399",
                    red: "f00",
                    rosybrown: "bc8f8f",
                    royalblue: "4169e1",
                    saddlebrown: "8b4513",
                    salmon: "fa8072",
                    sandybrown: "f4a460",
                    seagreen: "2e8b57",
                    seashell: "fff5ee",
                    sienna: "a0522d",
                    silver: "c0c0c0",
                    skyblue: "87ceeb",
                    slateblue: "6a5acd",
                    slategray: "708090",
                    slategrey: "708090",
                    snow: "fffafa",
                    springgreen: "00ff7f",
                    steelblue: "4682b4",
                    tan: "d2b48c",
                    teal: "008080",
                    thistle: "d8bfd8",
                    tomato: "ff6347",
                    turquoise: "40e0d0",
                    violet: "ee82ee",
                    wheat: "f5deb3",
                    white: "fff",
                    whitesmoke: "f5f5f5",
                    yellow: "ff0",
                    yellowgreen: "9acd32",
                }),
                $ = (a.hexNames = (function (e) {
                    var t = {};
                    for (var r in e) e.hasOwnProperty(r) && (t[e[r]] = r);
                    return t;
                })(Y)),
                X = (function () {
                    var e = "(?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?)",
                        t = "[\\s|\\(]+(" + e + ")[,|\\s]+(" + e + ")[,|\\s]+(" + e + ")\\s*\\)?",
                        r = "[\\s|\\(]+(" + e + ")[,|\\s]+(" + e + ")[,|\\s]+(" + e + ")[,|\\s]+(" + e + ")\\s*\\)?";
                    return {
                        CSS_UNIT: new RegExp(e),
                        rgb: new RegExp("rgb" + t),
                        rgba: new RegExp("rgba" + r),
                        hsl: new RegExp("hsl" + t),
                        hsla: new RegExp("hsla" + r),
                        hsv: new RegExp("hsv" + t),
                        hsva: new RegExp("hsva" + r),
                        hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                        hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
                        hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                        hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
                    };
                })();
            e.exports
                ? (e.exports = a)
                : void 0 !==
                      (n = function () {
                          return a;
                      }.call(t, r, t, e)) && (e.exports = n);
        })(Math);
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Swatch = void 0);
        var o =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            a = n(r(0)),
            i = n(r(2)),
            l = r(275),
            u = r(5),
            s = (t.Swatch = function (e) {
                var t = e.color,
                    r = e.style,
                    n = e.onClick,
                    l = void 0 === n ? function () {} : n,
                    s = e.onHover,
                    c = e.title,
                    p = void 0 === c ? t : c,
                    f = e.children,
                    d = e.focus,
                    _ = e.focusStyle,
                    h = void 0 === _ ? {} : _,
                    b = "transparent" === t,
                    m = (0, i.default)({ default: { swatch: o({ background: t, height: "100%", width: "100%", cursor: "pointer", position: "relative", outline: "none" }, r, d ? h : {}) } }),
                    g = {};
                return (
                    s &&
                        (g.onMouseOver = function (e) {
                            return s(t, e);
                        }),
                    a.default.createElement(
                        "div",
                        o(
                            {
                                style: m.swatch,
                                onClick: function (e) {
                                    return l(t, e);
                                },
                                title: p,
                                tabIndex: 0,
                                onKeyDown: function (e) {
                                    return 13 === e.keyCode && l(t, e);
                                },
                            },
                            g
                        ),
                        f,
                        b && a.default.createElement(u.Checkboard, { borderRadius: m.swatch.borderRadius, boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.1)" })
                    )
                );
            });
        t.default = (0, l.handleFocus)(s);
    },
    function (e, t, r) {
        "use strict";
        function n(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function o(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.handleFocus = void 0);
        var i =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            l = (function (e) {
                return e && e.__esModule ? e : { default: e };
            })(r(0));
        t.handleFocus = function (e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "span";
            return (function (r) {
                function u() {
                    var r, a, s, c;
                    n(this, u);
                    for (var p = arguments.length, f = Array(p), d = 0; d < p; d++) f[d] = arguments[d];
                    return (
                        (a = s = o(this, (r = u.__proto__ || Object.getPrototypeOf(u)).call.apply(r, [this].concat(f)))),
                        (s.state = { focus: !1 }),
                        (s.handleFocus = function () {
                            return s.setState({ focus: !0 });
                        }),
                        (s.handleBlur = function () {
                            return s.setState({ focus: !1 });
                        }),
                        (s.render = function () {
                            return l.default.createElement(t, { onFocus: s.handleFocus, onBlur: s.handleBlur }, l.default.createElement(e, i({}, s.props, s.state)));
                        }),
                        (c = a),
                        o(s, c)
                    );
                }
                return a(u, l.default.Component), u;
            })();
        };
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.AlphaPointer = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.AlphaPointer = function (e) {
                var t = e.direction,
                    r = (0, a.default)(
                        {
                            default: { picker: { width: "18px", height: "18px", borderRadius: "50%", transform: "translate(-9px, -1px)", backgroundColor: "rgb(248, 248, 248)", boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)" } },
                            vertical: { picker: { transform: "translate(-3px, -9px)" } },
                        },
                        { vertical: "vertical" === t }
                    );
                return o.default.createElement("div", { style: r.picker });
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Block = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = n(r(13)),
            u = r(5),
            s = n(r(278)),
            c = (t.Block = function (e) {
                var t = e.onChange,
                    r = e.onSwatchHover,
                    n = e.hex,
                    a = e.colors,
                    c = e.width,
                    p = e.triangle,
                    f = e.className,
                    d = void 0 === f ? "" : f,
                    _ = "transparent" === n,
                    h = function (e, r) {
                        l.default.isValidHex(e) && t({ hex: e, source: "hex" }, r);
                    },
                    b = (0, i.default)(
                        {
                            default: {
                                card: { width: c, background: "#fff", boxShadow: "0 1px rgba(0,0,0,.1)", borderRadius: "6px", position: "relative" },
                                head: { height: "110px", background: n, borderRadius: "6px 6px 0 0", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" },
                                body: { padding: "10px" },
                                label: { fontSize: "18px", color: _ ? "rgba(0,0,0,0.4)" : "#fff", position: "relative" },
                                triangle: {
                                    width: "0px",
                                    height: "0px",
                                    borderStyle: "solid",
                                    borderWidth: "0 10px 10px 10px",
                                    borderColor: "transparent transparent " + n + " transparent",
                                    position: "absolute",
                                    top: "-10px",
                                    left: "50%",
                                    marginLeft: "-10px",
                                },
                                input: { width: "100%", fontSize: "12px", color: "#666", border: "0px", outline: "none", height: "22px", boxShadow: "inset 0 0 0 1px #ddd", borderRadius: "4px", padding: "0 7px", boxSizing: "border-box" },
                            },
                            "hide-triangle": { triangle: { display: "none" } },
                        },
                        { "hide-triangle": "hide" === p }
                    );
                return o.default.createElement(
                    "div",
                    { style: b.card, className: "block-picker " + d },
                    o.default.createElement("div", { style: b.triangle }),
                    o.default.createElement("div", { style: b.head }, _ && o.default.createElement(u.Checkboard, { borderRadius: "6px 6px 0 0" }), o.default.createElement("div", { style: b.label }, n)),
                    o.default.createElement(
                        "div",
                        { style: b.body },
                        o.default.createElement(s.default, { colors: a, onClick: h, onSwatchHover: r }),
                        o.default.createElement(u.EditableInput, { style: { input: b.input }, value: n, onChange: h })
                    )
                );
            });
        (c.propTypes = { width: a.default.oneOfType([a.default.string, a.default.number]), colors: a.default.arrayOf(a.default.string), triangle: a.default.oneOf(["top", "hide"]) }),
            (c.defaultProps = { width: 170, colors: ["#D9E3F0", "#F47373", "#697689", "#37D67A", "#2CCCE4", "#555555", "#dce775", "#ff8a65", "#ba68c8"], triangle: "top" }),
            (t.default = (0, u.ColorWrap)(c));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.BlockSwatches = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = n(r(14)),
            l = r(5),
            u = (t.BlockSwatches = function (e) {
                var t = e.colors,
                    r = e.onClick,
                    n = e.onSwatchHover,
                    u = (0, a.default)({ default: { swatches: { marginRight: "-10px" }, swatch: { width: "22px", height: "22px", float: "left", marginRight: "10px", marginBottom: "10px", borderRadius: "4px" }, clear: { clear: "both" } } });
                return o.default.createElement(
                    "div",
                    { style: u.swatches },
                    (0, i.default)(t, function (e) {
                        return o.default.createElement(l.Swatch, { key: e, color: e, style: u.swatch, onClick: r, onHover: n, focusStyle: { boxShadow: "0 0 4px " + e } });
                    }),
                    o.default.createElement("div", { style: u.clear })
                );
            });
        t.default = u;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Circle = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = n(r(14)),
            u = (function (e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return (t.default = e), t;
            })(r(108)),
            s = r(5),
            c = n(r(280)),
            p = (t.Circle = function (e) {
                var t = e.width,
                    r = e.onChange,
                    n = e.onSwatchHover,
                    a = e.colors,
                    u = e.hex,
                    s = e.circleSize,
                    p = e.circleSpacing,
                    f = e.className,
                    d = void 0 === f ? "" : f,
                    _ = (0, i.default)({ default: { card: { width: t, display: "flex", flexWrap: "wrap", marginRight: -p, marginBottom: -p } } }),
                    h = function (e, t) {
                        return r({ hex: e, source: "hex" }, t);
                    };
                return o.default.createElement(
                    "div",
                    { style: _.card, className: "circle-picker " + d },
                    (0, l.default)(a, function (e) {
                        return o.default.createElement(c.default, { key: e, color: e, onClick: h, onSwatchHover: n, active: u === e.toLowerCase(), circleSize: s, circleSpacing: p });
                    })
                );
            });
        (p.propTypes = { width: a.default.oneOfType([a.default.string, a.default.number]), circleSize: a.default.number, circleSpacing: a.default.number }),
            (p.defaultProps = {
                width: 252,
                circleSize: 28,
                circleSpacing: 14,
                colors: [
                    u.red[500],
                    u.pink[500],
                    u.purple[500],
                    u.deepPurple[500],
                    u.indigo[500],
                    u.blue[500],
                    u.lightBlue[500],
                    u.cyan[500],
                    u.teal[500],
                    u.green[500],
                    u.lightGreen[500],
                    u.lime[500],
                    u.yellow[500],
                    u.amber[500],
                    u.orange[500],
                    u.deepOrange[500],
                    u.brown[500],
                    u.blueGrey[500],
                ],
            }),
            (t.default = (0, s.ColorWrap)(p));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.CircleSwatch = void 0);
        var o = n(r(0)),
            a = r(2),
            i = n(a),
            l = r(5),
            u = (t.CircleSwatch = function (e) {
                var t = e.color,
                    r = e.onClick,
                    n = e.onSwatchHover,
                    a = e.hover,
                    u = e.active,
                    s = e.circleSize,
                    c = e.circleSpacing,
                    p = (0, i.default)(
                        {
                            default: {
                                swatch: { width: s, height: s, marginRight: c, marginBottom: c, transform: "scale(1)", transition: "100ms transform ease" },
                                Swatch: { borderRadius: "50%", background: "transparent", boxShadow: "inset 0 0 0 " + s / 2 + "px " + t, transition: "100ms box-shadow ease" },
                            },
                            hover: { swatch: { transform: "scale(1.2)" } },
                            active: { Swatch: { boxShadow: "inset 0 0 0 3px " + t } },
                        },
                        { hover: a, active: u }
                    );
                return o.default.createElement("div", { style: p.swatch }, o.default.createElement(l.Swatch, { style: p.Swatch, color: t, onClick: r, onHover: n, focusStyle: { boxShadow: p.Swatch.boxShadow + ", 0 0 5px " + t } }));
            });
        (u.defaultProps = { circleSize: 28, circleSpacing: 14 }), (t.default = (0, a.handleHover)(u));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Chrome = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = r(5),
            u = n(r(282)),
            s = n(r(283)),
            c = n(r(284)),
            p = (t.Chrome = function (e) {
                var t = e.onChange,
                    r = e.disableAlpha,
                    n = e.rgb,
                    a = e.hsl,
                    p = e.hsv,
                    f = e.hex,
                    d = e.renderers,
                    _ = e.className,
                    h = void 0 === _ ? "" : _,
                    b = (0, i.default)(
                        {
                            default: {
                                picker: { background: "#fff", borderRadius: "2px", boxShadow: "0 0 2px rgba(0,0,0,.3), 0 4px 8px rgba(0,0,0,.3)", boxSizing: "initial", width: "225px", fontFamily: "Menlo" },
                                saturation: { width: "100%", paddingBottom: "55%", position: "relative", borderRadius: "2px 2px 0 0", overflow: "hidden" },
                                Saturation: { radius: "2px 2px 0 0" },
                                body: { padding: "16px 16px 12px" },
                                controls: { display: "flex" },
                                color: { width: "32px" },
                                swatch: { marginTop: "6px", width: "16px", height: "16px", borderRadius: "8px", position: "relative", overflow: "hidden" },
                                active: { absolute: "0px 0px 0px 0px", borderRadius: "8px", boxShadow: "inset 0 0 0 1px rgba(0,0,0,.1)", background: "rgba(" + n.r + ", " + n.g + ", " + n.b + ", " + n.a + ")", zIndex: "2" },
                                toggles: { flex: "1" },
                                hue: { height: "10px", position: "relative", marginBottom: "8px" },
                                Hue: { radius: "2px" },
                                alpha: { height: "10px", position: "relative" },
                                Alpha: { radius: "2px" },
                            },
                            disableAlpha: { color: { width: "22px" }, alpha: { display: "none" }, hue: { marginBottom: "0px" }, swatch: { width: "10px", height: "10px", marginTop: "0px" } },
                        },
                        { disableAlpha: r }
                    );
                return o.default.createElement(
                    "div",
                    { style: b.picker, className: "chrome-picker " + h },
                    o.default.createElement("div", { style: b.saturation }, o.default.createElement(l.Saturation, { style: b.Saturation, hsl: a, hsv: p, pointer: c.default, onChange: t })),
                    o.default.createElement(
                        "div",
                        { style: b.body },
                        o.default.createElement(
                            "div",
                            { style: b.controls, className: "flexbox-fix" },
                            o.default.createElement(
                                "div",
                                { style: b.color },
                                o.default.createElement("div", { style: b.swatch }, o.default.createElement("div", { style: b.active }), o.default.createElement(l.Checkboard, { renderers: d }))
                            ),
                            o.default.createElement(
                                "div",
                                { style: b.toggles },
                                o.default.createElement("div", { style: b.hue }, o.default.createElement(l.Hue, { style: b.Hue, hsl: a, pointer: s.default, onChange: t })),
                                o.default.createElement("div", { style: b.alpha }, o.default.createElement(l.Alpha, { style: b.Alpha, rgb: n, hsl: a, pointer: s.default, renderers: d, onChange: t }))
                            )
                        ),
                        o.default.createElement(u.default, { rgb: n, hsl: a, hex: f, onChange: t, disableAlpha: r })
                    )
                );
            });
        (p.propTypes = { disableAlpha: a.default.bool }), (p.defaultProps = { disableAlpha: !1 }), (t.default = (0, l.ColorWrap)(p));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function a(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function i(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.ChromeFields = void 0);
        var l = (function () {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                    }
                }
                return function (t, r, n) {
                    return r && e(t.prototype, r), n && e(t, n), t;
                };
            })(),
            u = n(r(0)),
            s = n(r(2)),
            c = n(r(13)),
            p = r(5),
            f = (t.ChromeFields = (function (e) {
                function t() {
                    var e, r, n, i;
                    o(this, t);
                    for (var l = arguments.length, u = Array(l), s = 0; s < l; s++) u[s] = arguments[s];
                    return (
                        (r = n = a(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [this].concat(u)))),
                        (n.state = { view: "" }),
                        (n.toggleViews = function () {
                            "hex" === n.state.view
                                ? n.setState({ view: "rgb" })
                                : "rgb" === n.state.view
                                ? n.setState({ view: "hsl" })
                                : "hsl" === n.state.view && (1 === n.props.hsl.a ? n.setState({ view: "hex" }) : n.setState({ view: "rgb" }));
                        }),
                        (n.handleChange = function (e, t) {
                            e.hex
                                ? c.default.isValidHex(e.hex) && n.props.onChange({ hex: e.hex, source: "hex" }, t)
                                : e.r || e.g || e.b
                                ? n.props.onChange({ r: e.r || n.props.rgb.r, g: e.g || n.props.rgb.g, b: e.b || n.props.rgb.b, source: "rgb" }, t)
                                : e.a
                                ? (e.a < 0 ? (e.a = 0) : e.a > 1 && (e.a = 1), n.props.onChange({ h: n.props.hsl.h, s: n.props.hsl.s, l: n.props.hsl.l, a: Math.round(100 * e.a) / 100, source: "rgb" }, t))
                                : (e.h || e.s || e.l) && n.props.onChange({ h: e.h || n.props.hsl.h, s: (e.s && e.s) || n.props.hsl.s, l: (e.l && e.l) || n.props.hsl.l, source: "hsl" }, t);
                        }),
                        (n.showHighlight = function (e) {
                            e.target.style.background = "#eee";
                        }),
                        (n.hideHighlight = function (e) {
                            e.target.style.background = "transparent";
                        }),
                        (i = r),
                        a(n, i)
                    );
                }
                return (
                    i(t, u.default.Component),
                    l(t, [
                        {
                            key: "componentDidMount",
                            value: function () {
                                1 === this.props.hsl.a && "hex" !== this.state.view ? this.setState({ view: "hex" }) : "rgb" !== this.state.view && "hsl" !== this.state.view && this.setState({ view: "rgb" });
                            },
                        },
                        {
                            key: "componentWillReceiveProps",
                            value: function (e) {
                                1 !== e.hsl.a && "hex" === this.state.view && this.setState({ view: "rgb" });
                            },
                        },
                        {
                            key: "render",
                            value: function () {
                                var e = this,
                                    t = (0, s.default)(
                                        {
                                            default: {
                                                wrap: { paddingTop: "16px", display: "flex" },
                                                fields: { flex: "1", display: "flex", marginLeft: "-6px" },
                                                field: { paddingLeft: "6px", width: "100%" },
                                                alpha: { paddingLeft: "6px", width: "100%" },
                                                toggle: { width: "32px", textAlign: "right", position: "relative" },
                                                icon: { marginRight: "-4px", marginTop: "12px", cursor: "pointer", position: "relative" },
                                                iconHighlight: { position: "absolute", width: "24px", height: "28px", background: "#eee", borderRadius: "4px", top: "10px", left: "12px", display: "none" },
                                                input: { fontSize: "11px", color: "#333", width: "100%", borderRadius: "2px", border: "none", boxShadow: "inset 0 0 0 1px #dadada", height: "21px", textAlign: "center" },
                                                label: { textTransform: "uppercase", fontSize: "11px", lineHeight: "11px", color: "#969696", textAlign: "center", display: "block", marginTop: "12px" },
                                                svg: { width: "24px", height: "24px", border: "1px transparent solid", borderRadius: "5px" },
                                            },
                                            disableAlpha: { alpha: { display: "none" } },
                                        },
                                        this.props,
                                        this.state
                                    ),
                                    r = void 0;
                                return (
                                    "hex" === this.state.view
                                        ? (r = u.default.createElement(
                                              "div",
                                              { style: t.fields, className: "flexbox-fix" },
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.field },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "hex", value: this.props.hex, onChange: this.handleChange })
                                              )
                                          ))
                                        : "rgb" === this.state.view
                                        ? (r = u.default.createElement(
                                              "div",
                                              { style: t.fields, className: "flexbox-fix" },
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.field },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "r", value: this.props.rgb.r, onChange: this.handleChange })
                                              ),
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.field },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "g", value: this.props.rgb.g, onChange: this.handleChange })
                                              ),
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.field },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "b", value: this.props.rgb.b, onChange: this.handleChange })
                                              ),
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.alpha },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "a", value: this.props.rgb.a, arrowOffset: 0.01, onChange: this.handleChange })
                                              )
                                          ))
                                        : "hsl" === this.state.view &&
                                          (r = u.default.createElement(
                                              "div",
                                              { style: t.fields, className: "flexbox-fix" },
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.field },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "h", value: Math.round(this.props.hsl.h), onChange: this.handleChange })
                                              ),
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.field },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "s", value: Math.round(100 * this.props.hsl.s) + "%", onChange: this.handleChange })
                                              ),
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.field },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "l", value: Math.round(100 * this.props.hsl.l) + "%", onChange: this.handleChange })
                                              ),
                                              u.default.createElement(
                                                  "div",
                                                  { style: t.alpha },
                                                  u.default.createElement(p.EditableInput, { style: { input: t.input, label: t.label }, label: "a", value: this.props.hsl.a, arrowOffset: 0.01, onChange: this.handleChange })
                                              )
                                          )),
                                    u.default.createElement(
                                        "div",
                                        { style: t.wrap, className: "flexbox-fix" },
                                        r,
                                        u.default.createElement(
                                            "div",
                                            { style: t.toggle },
                                            u.default.createElement(
                                                "div",
                                                {
                                                    style: t.icon,
                                                    onClick: this.toggleViews,
                                                    ref: function (t) {
                                                        return (e.icon = t);
                                                    },
                                                },
                                                u.default.createElement(
                                                    "svg",
                                                    { style: t.svg, viewBox: "0 0 24 24", onMouseOver: this.showHighlight, onMouseEnter: this.showHighlight, onMouseOut: this.hideHighlight },
                                                    u.default.createElement("path", {
                                                        ref: function (t) {
                                                            return (e.iconUp = t);
                                                        },
                                                        fill: "#333",
                                                        d: "M12,5.83L15.17,9L16.58,7.59L12,3L7.41,7.59L8.83,9L12,5.83Z",
                                                    }),
                                                    u.default.createElement("path", {
                                                        ref: function (t) {
                                                            return (e.iconDown = t);
                                                        },
                                                        fill: "#333",
                                                        d: "M12,18.17L8.83,15L7.42,16.41L12,21L16.59,16.41L15.17,15Z",
                                                    })
                                                )
                                            )
                                        )
                                    )
                                );
                            },
                        },
                    ]),
                    t
                );
            })());
        t.default = f;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.ChromePointer = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.ChromePointer = function () {
                var e = (0, a.default)({
                    default: { picker: { width: "12px", height: "12px", borderRadius: "6px", transform: "translate(-6px, -1px)", backgroundColor: "rgb(248, 248, 248)", boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)" } },
                });
                return o.default.createElement("div", { style: e.picker });
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.ChromePointerCircle = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.ChromePointerCircle = function () {
                var e = (0, a.default)({ default: { picker: { width: "12px", height: "12px", borderRadius: "6px", boxShadow: "inset 0 0 0 1px #fff", transform: "translate(-6px, -6px)" } } });
                return o.default.createElement("div", { style: e.picker });
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Compact = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = n(r(14)),
            u = n(r(13)),
            s = r(5),
            c = n(r(286)),
            p = n(r(287)),
            f = (t.Compact = function (e) {
                var t = e.onChange,
                    r = e.onSwatchHover,
                    n = e.colors,
                    a = e.hex,
                    f = e.rgb,
                    d = e.className,
                    _ = void 0 === d ? "" : d,
                    h = (0, i.default)({ default: { Compact: { background: "#f6f6f6", radius: "4px" }, compact: { paddingTop: "5px", paddingLeft: "5px", boxSizing: "initial", width: "240px" }, clear: { clear: "both" } } }),
                    b = function (e, r) {
                        e.hex ? u.default.isValidHex(e.hex) && t({ hex: e.hex, source: "hex" }, r) : t(e, r);
                    };
                return o.default.createElement(
                    s.Raised,
                    { style: h.Compact },
                    o.default.createElement(
                        "div",
                        { style: h.compact, className: "compact-picker " + _ },
                        o.default.createElement(
                            "div",
                            null,
                            (0, l.default)(n, function (e) {
                                return o.default.createElement(c.default, { key: e, color: e, active: e.toLowerCase() === a, onClick: b, onSwatchHover: r });
                            }),
                            o.default.createElement("div", { style: h.clear })
                        ),
                        o.default.createElement(p.default, { hex: a, rgb: f, onChange: b })
                    )
                );
            });
        (f.propTypes = { colors: a.default.arrayOf(a.default.string) }),
            (f.defaultProps = {
                colors: [
                    "#4D4D4D",
                    "#999999",
                    "#FFFFFF",
                    "#F44E3B",
                    "#FE9200",
                    "#FCDC00",
                    "#DBDF00",
                    "#A4DD00",
                    "#68CCCA",
                    "#73D8FF",
                    "#AEA1FF",
                    "#FDA1FF",
                    "#333333",
                    "#808080",
                    "#cccccc",
                    "#D33115",
                    "#E27300",
                    "#FCC400",
                    "#B0BC00",
                    "#68BC00",
                    "#16A5A5",
                    "#009CE0",
                    "#7B64FF",
                    "#FA28FF",
                    "#000000",
                    "#666666",
                    "#B3B3B3",
                    "#9F0500",
                    "#C45100",
                    "#FB9E00",
                    "#808900",
                    "#194D33",
                    "#0C797D",
                    "#0062B1",
                    "#653294",
                    "#AB149E",
                ],
            }),
            (t.default = (0, s.ColorWrap)(f));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.CompactColor = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = r(5),
            l = (t.CompactColor = function (e) {
                var t = e.color,
                    r = e.onClick,
                    n = void 0 === r ? function () {} : r,
                    l = e.onSwatchHover,
                    u = e.active,
                    s = (0, a.default)(
                        {
                            default: {
                                color: { background: t, width: "15px", height: "15px", float: "left", marginRight: "5px", marginBottom: "5px", position: "relative", cursor: "pointer" },
                                dot: { absolute: "5px 5px 5px 5px", background: "#fff", borderRadius: "50%", opacity: "0" },
                            },
                            active: { dot: { opacity: "1" } },
                            "color-#FFFFFF": { color: { boxShadow: "inset 0 0 0 1px #ddd" }, dot: { background: "#000" } },
                            transparent: { dot: { background: "#000" } },
                        },
                        { active: u, "color-#FFFFFF": "#FFFFFF" === t, transparent: "transparent" === t }
                    );
                return o.default.createElement(i.Swatch, { style: s.color, color: t, onClick: n, onHover: l, focusStyle: { boxShadow: "0 0 4px " + t } }, o.default.createElement("div", { style: s.dot }));
            });
        t.default = l;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.CompactFields = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = r(5),
            l = (t.CompactFields = function (e) {
                var t = e.hex,
                    r = e.rgb,
                    n = e.onChange,
                    l = (0, a.default)({
                        default: {
                            fields: { display: "flex", paddingBottom: "6px", paddingRight: "5px", position: "relative" },
                            active: { position: "absolute", top: "6px", left: "5px", height: "9px", width: "9px", background: t },
                            HEXwrap: { flex: "6", position: "relative" },
                            HEXinput: { width: "80%", padding: "0px", paddingLeft: "20%", border: "none", outline: "none", background: "none", fontSize: "12px", color: "#333", height: "16px" },
                            HEXlabel: { display: "none" },
                            RGBwrap: { flex: "3", position: "relative" },
                            RGBinput: { width: "70%", padding: "0px", paddingLeft: "30%", border: "none", outline: "none", background: "none", fontSize: "12px", color: "#333", height: "16px" },
                            RGBlabel: { position: "absolute", top: "3px", left: "0px", lineHeight: "16px", textTransform: "uppercase", fontSize: "12px", color: "#999" },
                        },
                    }),
                    u = function (e, t) {
                        e.r || e.g || e.b ? n({ r: e.r || r.r, g: e.g || r.g, b: e.b || r.b, source: "rgb" }, t) : n({ hex: e.hex, source: "hex" }, t);
                    };
                return o.default.createElement(
                    "div",
                    { style: l.fields, className: "flexbox-fix" },
                    o.default.createElement("div", { style: l.active }),
                    o.default.createElement(i.EditableInput, { style: { wrap: l.HEXwrap, input: l.HEXinput, label: l.HEXlabel }, label: "hex", value: t, onChange: u }),
                    o.default.createElement(i.EditableInput, { style: { wrap: l.RGBwrap, input: l.RGBinput, label: l.RGBlabel }, label: "r", value: r.r, onChange: u }),
                    o.default.createElement(i.EditableInput, { style: { wrap: l.RGBwrap, input: l.RGBinput, label: l.RGBlabel }, label: "g", value: r.g, onChange: u }),
                    o.default.createElement(i.EditableInput, { style: { wrap: l.RGBwrap, input: l.RGBinput, label: l.RGBlabel }, label: "b", value: r.b, onChange: u })
                );
            });
        t.default = l;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Github = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = n(r(14)),
            u = r(5),
            s = n(r(289)),
            c = (t.Github = function (e) {
                var t = e.width,
                    r = e.colors,
                    n = e.onChange,
                    a = e.onSwatchHover,
                    u = e.triangle,
                    c = e.className,
                    p = void 0 === c ? "" : c,
                    f = (0, i.default)(
                        {
                            default: {
                                card: {
                                    width: t,
                                    background: "#fff",
                                    border: "1px solid rgba(0,0,0,0.2)",
                                    boxShadow: "0 3px 12px rgba(0,0,0,0.15)",
                                    borderRadius: "4px",
                                    position: "relative",
                                    padding: "5px",
                                    display: "flex",
                                    flexWrap: "wrap",
                                },
                                triangle: { position: "absolute", border: "7px solid transparent", borderBottomColor: "#fff" },
                                triangleShadow: { position: "absolute", border: "8px solid transparent", borderBottomColor: "rgba(0,0,0,0.15)" },
                            },
                            "hide-triangle": { triangle: { display: "none" }, triangleShadow: { display: "none" } },
                            "top-left-triangle": { triangle: { top: "-14px", left: "10px" }, triangleShadow: { top: "-16px", left: "9px" } },
                            "top-right-triangle": { triangle: { top: "-14px", right: "10px" }, triangleShadow: { top: "-16px", right: "9px" } },
                            "bottom-right-triangle": { triangle: { top: "35px", right: "10px", transform: "rotate(180deg)" }, triangleShadow: { top: "37px", right: "9px", transform: "rotate(180deg)" } },
                        },
                        { "hide-triangle": "hide" === u, "top-left-triangle": "top-left" === u, "top-right-triangle": "top-right" === u, "bottom-right-triangle": "bottom-right" === u }
                    ),
                    d = function (e, t) {
                        return n({ hex: e, source: "hex" }, t);
                    };
                return o.default.createElement(
                    "div",
                    { style: f.card, className: "github-picker " + p },
                    o.default.createElement("div", { style: f.triangleShadow }),
                    o.default.createElement("div", { style: f.triangle }),
                    (0, l.default)(r, function (e) {
                        return o.default.createElement(s.default, { color: e, key: e, onClick: d, onSwatchHover: a });
                    })
                );
            });
        (c.propTypes = { width: a.default.oneOfType([a.default.string, a.default.number]), colors: a.default.arrayOf(a.default.string), triangle: a.default.oneOf(["hide", "top-left", "top-right"]) }),
            (c.defaultProps = {
                width: 200,
                colors: ["#B80000", "#DB3E00", "#FCCB00", "#008B02", "#006B76", "#1273DE", "#004DCF", "#5300EB", "#EB9694", "#FAD0C3", "#FEF3BD", "#C1E1C5", "#BEDADC", "#C4DEF6", "#BED3F3", "#D4C4FB"],
                triangle: "top-left",
            }),
            (t.default = (0, u.ColorWrap)(c));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.GithubSwatch = void 0);
        var o = n(r(0)),
            a = r(2),
            i = n(a),
            l = r(5),
            u = (t.GithubSwatch = function (e) {
                var t = e.hover,
                    r = e.color,
                    n = e.onClick,
                    a = e.onSwatchHover,
                    u = { position: "relative", zIndex: "2", outline: "2px solid #fff", boxShadow: "0 0 5px 2px rgba(0,0,0,0.25)" },
                    s = (0, i.default)({ default: { swatch: { width: "25px", height: "25px", fontSize: "0" } }, hover: { swatch: u } }, { hover: t });
                return o.default.createElement("div", { style: s.swatch }, o.default.createElement(l.Swatch, { color: r, onClick: n, onHover: a, focusStyle: u }));
            });
        t.default = (0, a.handleHover)(u);
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.HuePicker = void 0);
        var o =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            a = n(r(0)),
            i = n(r(2)),
            l = r(5),
            u = n(r(291)),
            s = (t.HuePicker = function (e) {
                var t = e.width,
                    r = e.height,
                    n = e.onChange,
                    u = e.hsl,
                    s = e.direction,
                    c = e.pointer,
                    p = e.className,
                    f = void 0 === p ? "" : p,
                    d = (0, i.default)({ default: { picker: { position: "relative", width: t, height: r }, hue: { radius: "2px" } } });
                return a.default.createElement(
                    "div",
                    { style: d.picker, className: "hue-picker " + f },
                    a.default.createElement(
                        l.Hue,
                        o({}, d.hue, {
                            hsl: u,
                            pointer: c,
                            onChange: function (e) {
                                return n({ a: 1, h: e.h, l: 0.5, s: 1 });
                            },
                            direction: s,
                        })
                    )
                );
            });
        (s.defaultProps = { width: "316px", height: "16px", direction: "horizontal", pointer: u.default }), (t.default = (0, l.ColorWrap)(s));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SliderPointer = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.SliderPointer = function (e) {
                var t = e.direction,
                    r = (0, a.default)(
                        {
                            default: { picker: { width: "18px", height: "18px", borderRadius: "50%", transform: "translate(-9px, -1px)", backgroundColor: "rgb(248, 248, 248)", boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)" } },
                            vertical: { picker: { transform: "translate(-3px, -9px)" } },
                        },
                        { vertical: "vertical" === t }
                    );
                return o.default.createElement("div", { style: r.picker });
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Material = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = n(r(13)),
            l = r(5),
            u = (t.Material = function (e) {
                var t = e.onChange,
                    r = e.hex,
                    n = e.rgb,
                    u = e.className,
                    s = void 0 === u ? "" : u,
                    c = (0, a.default)({
                        default: {
                            material: { width: "98px", height: "98px", padding: "16px", fontFamily: "Roboto" },
                            HEXwrap: { position: "relative" },
                            HEXinput: { width: "100%", marginTop: "12px", fontSize: "15px", color: "#333", padding: "0px", border: "0px", borderBottom: "2px solid " + r, outline: "none", height: "30px" },
                            HEXlabel: { position: "absolute", top: "0px", left: "0px", fontSize: "11px", color: "#999999", textTransform: "capitalize" },
                            Hex: { style: {} },
                            RGBwrap: { position: "relative" },
                            RGBinput: { width: "100%", marginTop: "12px", fontSize: "15px", color: "#333", padding: "0px", border: "0px", borderBottom: "1px solid #eee", outline: "none", height: "30px" },
                            RGBlabel: { position: "absolute", top: "0px", left: "0px", fontSize: "11px", color: "#999999", textTransform: "capitalize" },
                            split: { display: "flex", marginRight: "-10px", paddingTop: "11px" },
                            third: { flex: "1", paddingRight: "10px" },
                        },
                    }),
                    p = function (e, r) {
                        e.hex ? i.default.isValidHex(e.hex) && t({ hex: e.hex, source: "hex" }, r) : (e.r || e.g || e.b) && t({ r: e.r || n.r, g: e.g || n.g, b: e.b || n.b, source: "rgb" }, r);
                    };
                return o.default.createElement(
                    l.Raised,
                    null,
                    o.default.createElement(
                        "div",
                        { style: c.material, className: "material-picker " + s },
                        o.default.createElement(l.EditableInput, { style: { wrap: c.HEXwrap, input: c.HEXinput, label: c.HEXlabel }, label: "hex", value: r, onChange: p }),
                        o.default.createElement(
                            "div",
                            { style: c.split, className: "flexbox-fix" },
                            o.default.createElement("div", { style: c.third }, o.default.createElement(l.EditableInput, { style: { wrap: c.RGBwrap, input: c.RGBinput, label: c.RGBlabel }, label: "r", value: n.r, onChange: p })),
                            o.default.createElement("div", { style: c.third }, o.default.createElement(l.EditableInput, { style: { wrap: c.RGBwrap, input: c.RGBinput, label: c.RGBlabel }, label: "g", value: n.g, onChange: p })),
                            o.default.createElement("div", { style: c.third }, o.default.createElement(l.EditableInput, { style: { wrap: c.RGBwrap, input: c.RGBinput, label: c.RGBlabel }, label: "b", value: n.b, onChange: p }))
                        )
                    )
                );
            });
        t.default = (0, l.ColorWrap)(u);
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function a(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || ("object" != typeof t && "function" != typeof t) ? e : t;
        }
        function i(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            (e.prototype = Object.create(t && t.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } })), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : (e.__proto__ = t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Photoshop = void 0);
        var l = (function () {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        (n.enumerable = n.enumerable || !1), (n.configurable = !0), "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n);
                    }
                }
                return function (t, r, n) {
                    return r && e(t.prototype, r), n && e(t, n), t;
                };
            })(),
            u = n(r(0)),
            s = n(r(6)),
            c = n(r(2)),
            p = r(5),
            f = n(r(294)),
            d = n(r(295)),
            _ = n(r(296)),
            h = n(r(297)),
            b = n(r(298)),
            m = (t.Photoshop = (function (e) {
                function t(e) {
                    o(this, t);
                    var r = a(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    return (r.state = { currentColor: e.hex }), r;
                }
                return (
                    i(t, u.default.Component),
                    l(t, [
                        {
                            key: "render",
                            value: function () {
                                var e = this.props.className,
                                    t = void 0 === e ? "" : e,
                                    r = (0, c.default)({
                                        default: {
                                            picker: { background: "#DCDCDC", borderRadius: "4px", boxShadow: "0 0 0 1px rgba(0,0,0,.25), 0 8px 16px rgba(0,0,0,.15)", boxSizing: "initial", width: "513px" },
                                            head: {
                                                backgroundImage: "linear-gradient(-180deg, #F0F0F0 0%, #D4D4D4 100%)",
                                                borderBottom: "1px solid #B1B1B1",
                                                boxShadow: "inset 0 1px 0 0 rgba(255,255,255,.2), inset 0 -1px 0 0 rgba(0,0,0,.02)",
                                                height: "23px",
                                                lineHeight: "24px",
                                                borderRadius: "4px 4px 0 0",
                                                fontSize: "13px",
                                                color: "#4D4D4D",
                                                textAlign: "center",
                                            },
                                            body: { padding: "15px 15px 0", display: "flex" },
                                            saturation: { width: "256px", height: "256px", position: "relative", border: "2px solid #B3B3B3", borderBottom: "2px solid #F0F0F0", overflow: "hidden" },
                                            hue: { position: "relative", height: "256px", width: "19px", marginLeft: "10px", border: "2px solid #B3B3B3", borderBottom: "2px solid #F0F0F0" },
                                            controls: { width: "180px", marginLeft: "10px" },
                                            top: { display: "flex" },
                                            previews: { width: "60px" },
                                            actions: { flex: "1", marginLeft: "20px" },
                                        },
                                    });
                                return u.default.createElement(
                                    "div",
                                    { style: r.picker, className: "photoshop-picker " + t },
                                    u.default.createElement("div", { style: r.head }, this.props.header),
                                    u.default.createElement(
                                        "div",
                                        { style: r.body, className: "flexbox-fix" },
                                        u.default.createElement("div", { style: r.saturation }, u.default.createElement(p.Saturation, { hsl: this.props.hsl, hsv: this.props.hsv, pointer: d.default, onChange: this.props.onChange })),
                                        u.default.createElement("div", { style: r.hue }, u.default.createElement(p.Hue, { direction: "vertical", hsl: this.props.hsl, pointer: _.default, onChange: this.props.onChange })),
                                        u.default.createElement(
                                            "div",
                                            { style: r.controls },
                                            u.default.createElement(
                                                "div",
                                                { style: r.top, className: "flexbox-fix" },
                                                u.default.createElement("div", { style: r.previews }, u.default.createElement(b.default, { rgb: this.props.rgb, currentColor: this.state.currentColor })),
                                                u.default.createElement(
                                                    "div",
                                                    { style: r.actions },
                                                    u.default.createElement(h.default, { label: "OK", onClick: this.props.onAccept, active: !0 }),
                                                    u.default.createElement(h.default, { label: "Cancel", onClick: this.props.onCancel }),
                                                    u.default.createElement(f.default, { onChange: this.props.onChange, rgb: this.props.rgb, hsv: this.props.hsv, hex: this.props.hex })
                                                )
                                            )
                                        )
                                    )
                                );
                            },
                        },
                    ]),
                    t
                );
            })());
        (m.propTypes = { header: s.default.string }), (m.defaultProps = { header: "Color Picker" }), (t.default = (0, p.ColorWrap)(m));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.PhotoshopPicker = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = n(r(13)),
            l = r(5),
            u = (t.PhotoshopPicker = function (e) {
                var t = e.onChange,
                    r = e.rgb,
                    n = e.hsv,
                    u = e.hex,
                    s = (0, a.default)({
                        default: {
                            fields: { paddingTop: "5px", paddingBottom: "9px", width: "80px", position: "relative" },
                            divider: { height: "5px" },
                            RGBwrap: { position: "relative" },
                            RGBinput: {
                                marginLeft: "40%",
                                width: "40%",
                                height: "18px",
                                border: "1px solid #888888",
                                boxShadow: "inset 0 1px 1px rgba(0,0,0,.1), 0 1px 0 0 #ECECEC",
                                marginBottom: "5px",
                                fontSize: "13px",
                                paddingLeft: "3px",
                                marginRight: "10px",
                            },
                            RGBlabel: { left: "0px", width: "34px", textTransform: "uppercase", fontSize: "13px", height: "18px", lineHeight: "22px", position: "absolute" },
                            HEXwrap: { position: "relative" },
                            HEXinput: {
                                marginLeft: "20%",
                                width: "80%",
                                height: "18px",
                                border: "1px solid #888888",
                                boxShadow: "inset 0 1px 1px rgba(0,0,0,.1), 0 1px 0 0 #ECECEC",
                                marginBottom: "6px",
                                fontSize: "13px",
                                paddingLeft: "3px",
                            },
                            HEXlabel: { position: "absolute", top: "0px", left: "0px", width: "14px", textTransform: "uppercase", fontSize: "13px", height: "18px", lineHeight: "22px" },
                            fieldSymbols: { position: "absolute", top: "5px", right: "-7px", fontSize: "13px" },
                            symbol: { height: "20px", lineHeight: "22px", paddingBottom: "7px" },
                        },
                    }),
                    c = function (e, o) {
                        e["#"]
                            ? i.default.isValidHex(e["#"]) && t({ hex: e["#"], source: "hex" }, o)
                            : e.r || e.g || e.b
                            ? t({ r: e.r || r.r, g: e.g || r.g, b: e.b || r.b, source: "rgb" }, o)
                            : (e.h || e.s || e.v) && t({ h: e.h || n.h, s: e.s || n.s, v: e.v || n.v, source: "hsv" }, o);
                    };
                return o.default.createElement(
                    "div",
                    { style: s.fields },
                    o.default.createElement(l.EditableInput, { style: { wrap: s.RGBwrap, input: s.RGBinput, label: s.RGBlabel }, label: "h", value: Math.round(n.h), onChange: c }),
                    o.default.createElement(l.EditableInput, { style: { wrap: s.RGBwrap, input: s.RGBinput, label: s.RGBlabel }, label: "s", value: Math.round(100 * n.s), onChange: c }),
                    o.default.createElement(l.EditableInput, { style: { wrap: s.RGBwrap, input: s.RGBinput, label: s.RGBlabel }, label: "v", value: Math.round(100 * n.v), onChange: c }),
                    o.default.createElement("div", { style: s.divider }),
                    o.default.createElement(l.EditableInput, { style: { wrap: s.RGBwrap, input: s.RGBinput, label: s.RGBlabel }, label: "r", value: r.r, onChange: c }),
                    o.default.createElement(l.EditableInput, { style: { wrap: s.RGBwrap, input: s.RGBinput, label: s.RGBlabel }, label: "g", value: r.g, onChange: c }),
                    o.default.createElement(l.EditableInput, { style: { wrap: s.RGBwrap, input: s.RGBinput, label: s.RGBlabel }, label: "b", value: r.b, onChange: c }),
                    o.default.createElement("div", { style: s.divider }),
                    o.default.createElement(l.EditableInput, { style: { wrap: s.HEXwrap, input: s.HEXinput, label: s.HEXlabel }, label: "#", value: u.replace("#", ""), onChange: c }),
                    o.default.createElement(
                        "div",
                        { style: s.fieldSymbols },
                        o.default.createElement("div", { style: s.symbol }, "°"),
                        o.default.createElement("div", { style: s.symbol }, "%"),
                        o.default.createElement("div", { style: s.symbol }, "%")
                    )
                );
            });
        t.default = u;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.PhotoshopPointerCircle = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.PhotoshopPointerCircle = function (e) {
                var t = e.hsl,
                    r = (0, a.default)(
                        {
                            default: { picker: { width: "12px", height: "12px", borderRadius: "6px", boxShadow: "inset 0 0 0 1px #fff", transform: "translate(-6px, -6px)" } },
                            "black-outline": { picker: { boxShadow: "inset 0 0 0 1px #000" } },
                        },
                        { "black-outline": t.l > 0.5 }
                    );
                return o.default.createElement("div", { style: r.picker });
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.PhotoshopPointerCircle = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.PhotoshopPointerCircle = function () {
                var e = (0, a.default)({
                    default: {
                        triangle: { width: 0, height: 0, borderStyle: "solid", borderWidth: "4px 0 4px 6px", borderColor: "transparent transparent transparent #fff", position: "absolute", top: "1px", left: "1px" },
                        triangleBorder: { width: 0, height: 0, borderStyle: "solid", borderWidth: "5px 0 5px 8px", borderColor: "transparent transparent transparent #555" },
                        left: { Extend: "triangleBorder", transform: "translate(-13px, -4px)" },
                        leftInside: { Extend: "triangle", transform: "translate(-8px, -5px)" },
                        right: { Extend: "triangleBorder", transform: "translate(20px, -14px) rotate(180deg)" },
                        rightInside: { Extend: "triangle", transform: "translate(-8px, -5px)" },
                    },
                });
                return o.default.createElement(
                    "div",
                    { style: e.pointer },
                    o.default.createElement("div", { style: e.left }, o.default.createElement("div", { style: e.leftInside })),
                    o.default.createElement("div", { style: e.right }, o.default.createElement("div", { style: e.rightInside }))
                );
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.PhotoshopBotton = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.PhotoshopBotton = function (e) {
                var t = e.onClick,
                    r = e.label,
                    n = e.children,
                    i = e.active,
                    l = (0, a.default)(
                        {
                            default: {
                                button: {
                                    backgroundImage: "linear-gradient(-180deg, #FFFFFF 0%, #E6E6E6 100%)",
                                    border: "1px solid #878787",
                                    borderRadius: "2px",
                                    height: "20px",
                                    boxShadow: "0 1px 0 0 #EAEAEA",
                                    fontSize: "14px",
                                    color: "#000",
                                    lineHeight: "20px",
                                    textAlign: "center",
                                    marginBottom: "10px",
                                    cursor: "pointer",
                                },
                            },
                            active: { button: { boxShadow: "0 0 0 1px #878787" } },
                        },
                        { active: i }
                    );
                return o.default.createElement("div", { style: l.button, onClick: t }, r || n);
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.PhotoshopPreviews = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.PhotoshopPreviews = function (e) {
                var t = e.rgb,
                    r = e.currentColor,
                    n = (0, a.default)({
                        default: {
                            swatches: { border: "1px solid #B3B3B3", borderBottom: "1px solid #F0F0F0", marginBottom: "2px", marginTop: "1px" },
                            new: { height: "34px", background: "rgb(" + t.r + "," + t.g + ", " + t.b + ")", boxShadow: "inset 1px 0 0 #000, inset -1px 0 0 #000, inset 0 1px 0 #000" },
                            current: { height: "34px", background: r, boxShadow: "inset 1px 0 0 #000, inset -1px 0 0 #000, inset 0 -1px 0 #000" },
                            label: { fontSize: "14px", color: "#000", textAlign: "center" },
                        },
                    });
                return o.default.createElement(
                    "div",
                    null,
                    o.default.createElement("div", { style: n.label }, "new"),
                    o.default.createElement("div", { style: n.swatches }, o.default.createElement("div", { style: n.new }), o.default.createElement("div", { style: n.current })),
                    o.default.createElement("div", { style: n.label }, "current")
                );
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Sketch = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = r(5),
            u = n(r(300)),
            s = n(r(301)),
            c = (t.Sketch = function (e) {
                var t = e.width,
                    r = e.rgb,
                    n = e.hex,
                    a = e.hsv,
                    c = e.hsl,
                    p = e.onChange,
                    f = e.onSwatchHover,
                    d = e.disableAlpha,
                    _ = e.presetColors,
                    h = e.renderers,
                    b = e.className,
                    m = void 0 === b ? "" : b,
                    g = (0, i.default)(
                        {
                            default: {
                                picker: { width: t, padding: "10px 10px 0", boxSizing: "initial", background: "#fff", borderRadius: "4px", boxShadow: "0 0 0 1px rgba(0,0,0,.15), 0 8px 16px rgba(0,0,0,.15)" },
                                saturation: { width: "100%", paddingBottom: "75%", position: "relative", overflow: "hidden" },
                                Saturation: { radius: "3px", shadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)" },
                                controls: { display: "flex" },
                                sliders: { padding: "4px 0", flex: "1" },
                                color: { width: "24px", height: "24px", position: "relative", marginTop: "4px", marginLeft: "4px", borderRadius: "3px" },
                                activeColor: {
                                    absolute: "0px 0px 0px 0px",
                                    borderRadius: "2px",
                                    background: "rgba(" + r.r + "," + r.g + "," + r.b + "," + r.a + ")",
                                    boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)",
                                },
                                hue: { position: "relative", height: "10px", overflow: "hidden" },
                                Hue: { radius: "2px", shadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)" },
                                alpha: { position: "relative", height: "10px", marginTop: "4px", overflow: "hidden" },
                                Alpha: { radius: "2px", shadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)" },
                            },
                            disableAlpha: { color: { height: "10px" }, hue: { height: "10px" }, alpha: { display: "none" } },
                        },
                        { disableAlpha: d }
                    );
                return o.default.createElement(
                    "div",
                    { style: g.picker, className: "sketch-picker " + m },
                    o.default.createElement("div", { style: g.saturation }, o.default.createElement(l.Saturation, { style: g.Saturation, hsl: c, hsv: a, onChange: p })),
                    o.default.createElement(
                        "div",
                        { style: g.controls, className: "flexbox-fix" },
                        o.default.createElement(
                            "div",
                            { style: g.sliders },
                            o.default.createElement("div", { style: g.hue }, o.default.createElement(l.Hue, { style: g.Hue, hsl: c, onChange: p })),
                            o.default.createElement("div", { style: g.alpha }, o.default.createElement(l.Alpha, { style: g.Alpha, rgb: r, hsl: c, renderers: h, onChange: p }))
                        ),
                        o.default.createElement("div", { style: g.color }, o.default.createElement(l.Checkboard, null), o.default.createElement("div", { style: g.activeColor }))
                    ),
                    o.default.createElement(u.default, { rgb: r, hsl: c, hex: n, onChange: p, disableAlpha: d }),
                    o.default.createElement(s.default, { colors: _, onClick: p, onSwatchHover: f })
                );
            });
        (c.propTypes = { disableAlpha: a.default.bool, width: a.default.oneOfType([a.default.string, a.default.number]) }),
            (c.defaultProps = {
                disableAlpha: !1,
                width: 200,
                presetColors: ["#D0021B", "#F5A623", "#F8E71C", "#8B572A", "#7ED321", "#417505", "#BD10E0", "#9013FE", "#4A90E2", "#50E3C2", "#B8E986", "#000000", "#4A4A4A", "#9B9B9B", "#FFFFFF"],
            }),
            (t.default = (0, l.ColorWrap)(c));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SketchFields = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = n(r(13)),
            l = r(5),
            u = (t.SketchFields = function (e) {
                var t = e.onChange,
                    r = e.rgb,
                    n = e.hsl,
                    u = e.hex,
                    s = e.disableAlpha,
                    c = (0, a.default)(
                        {
                            default: {
                                fields: { display: "flex", paddingTop: "4px" },
                                single: { flex: "1", paddingLeft: "6px" },
                                alpha: { flex: "1", paddingLeft: "6px" },
                                double: { flex: "2" },
                                input: { width: "80%", padding: "4px 10% 3px", border: "none", boxShadow: "inset 0 0 0 1px #ccc", fontSize: "11px" },
                                label: { display: "block", textAlign: "center", fontSize: "11px", color: "#222", paddingTop: "3px", paddingBottom: "4px", textTransform: "capitalize" },
                            },
                            disableAlpha: { alpha: { display: "none" } },
                        },
                        { disableAlpha: s }
                    ),
                    p = function (e, o) {
                        e.hex
                            ? i.default.isValidHex(e.hex) && t({ hex: e.hex, source: "hex" }, o)
                            : e.r || e.g || e.b
                            ? t({ r: e.r || r.r, g: e.g || r.g, b: e.b || r.b, a: r.a, source: "rgb" }, o)
                            : e.a && (e.a < 0 ? (e.a = 0) : e.a > 100 && (e.a = 100), (e.a /= 100), t({ h: n.h, s: n.s, l: n.l, a: e.a, source: "rgb" }, o));
                    };
                return o.default.createElement(
                    "div",
                    { style: c.fields, className: "flexbox-fix" },
                    o.default.createElement("div", { style: c.double }, o.default.createElement(l.EditableInput, { style: { input: c.input, label: c.label }, label: "hex", value: u.replace("#", ""), onChange: p })),
                    o.default.createElement("div", { style: c.single }, o.default.createElement(l.EditableInput, { style: { input: c.input, label: c.label }, label: "r", value: r.r, onChange: p, dragLabel: "true", dragMax: "255" })),
                    o.default.createElement("div", { style: c.single }, o.default.createElement(l.EditableInput, { style: { input: c.input, label: c.label }, label: "g", value: r.g, onChange: p, dragLabel: "true", dragMax: "255" })),
                    o.default.createElement("div", { style: c.single }, o.default.createElement(l.EditableInput, { style: { input: c.input, label: c.label }, label: "b", value: r.b, onChange: p, dragLabel: "true", dragMax: "255" })),
                    o.default.createElement(
                        "div",
                        { style: c.alpha },
                        o.default.createElement(l.EditableInput, { style: { input: c.input, label: c.label }, label: "a", value: Math.round(100 * r.a), onChange: p, dragLabel: "true", dragMax: "100" })
                    )
                );
            });
        t.default = u;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SketchPresetColors = void 0);
        var o =
                Object.assign ||
                function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                    }
                    return e;
                },
            a = n(r(0)),
            i = n(r(6)),
            l = n(r(2)),
            u = r(5),
            s = (t.SketchPresetColors = function (e) {
                var t = e.colors,
                    r = e.onClick,
                    n = void 0 === r ? function () {} : r,
                    i = e.onSwatchHover,
                    s = (0, l.default)(
                        {
                            default: {
                                colors: { margin: "0 -10px", padding: "10px 0 0 10px", borderTop: "1px solid #eee", display: "flex", flexWrap: "wrap", position: "relative" },
                                swatchWrap: { width: "16px", height: "16px", margin: "0 10px 10px 0" },
                                swatch: { borderRadius: "3px", boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15)" },
                            },
                            "no-presets": { colors: { display: "none" } },
                        },
                        { "no-presets": !t || !t.length }
                    ),
                    c = function (e, t) {
                        n({ hex: e, source: "hex" }, t);
                    };
                return a.default.createElement(
                    "div",
                    { style: s.colors, className: "flexbox-fix" },
                    t.map(function (e) {
                        var t = "string" == typeof e ? { color: e } : e;
                        return a.default.createElement(
                            "div",
                            { key: t.color, style: s.swatchWrap },
                            a.default.createElement(u.Swatch, o({}, t, { style: s.swatch, onClick: c, onHover: i, focusStyle: { boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15), 0 0 4px " + t.color } }))
                        );
                    })
                );
            });
        (s.propTypes = { colors: i.default.arrayOf(i.default.oneOfType([i.default.string, i.default.shape({ color: i.default.string, title: i.default.string })])).isRequired }), (t.default = s);
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Slider = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = r(5),
            l = n(r(303)),
            u = n(r(305)),
            s = (t.Slider = function (e) {
                var t = e.hsl,
                    r = e.onChange,
                    n = e.pointer,
                    u = e.className,
                    s = void 0 === u ? "" : u,
                    c = (0, a.default)({ default: { hue: { height: "12px", position: "relative" }, Hue: { radius: "2px" } } });
                return o.default.createElement(
                    "div",
                    { className: "slider-picker " + s },
                    o.default.createElement("div", { style: c.hue }, o.default.createElement(i.Hue, { style: c.Hue, hsl: t, pointer: n, onChange: r })),
                    o.default.createElement("div", { style: c.swatches }, o.default.createElement(l.default, { hsl: t, onClick: r }))
                );
            });
        (s.defaultProps = { pointer: u.default }), (t.default = (0, i.ColorWrap)(s));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SliderSwatches = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = n(r(304)),
            l = (t.SliderSwatches = function (e) {
                var t = e.onClick,
                    r = e.hsl,
                    n = (0, a.default)({ default: { swatches: { marginTop: "20px" }, swatch: { boxSizing: "border-box", width: "20%", paddingRight: "1px", float: "left" }, clear: { clear: "both" } } });
                return o.default.createElement(
                    "div",
                    { style: n.swatches },
                    o.default.createElement("div", { style: n.swatch }, o.default.createElement(i.default, { hsl: r, offset: ".80", active: Math.round(100 * r.l) / 100 == 0.8 && Math.round(100 * r.s) / 100 == 0.5, onClick: t, first: !0 })),
                    o.default.createElement("div", { style: n.swatch }, o.default.createElement(i.default, { hsl: r, offset: ".65", active: Math.round(100 * r.l) / 100 == 0.65 && Math.round(100 * r.s) / 100 == 0.5, onClick: t })),
                    o.default.createElement("div", { style: n.swatch }, o.default.createElement(i.default, { hsl: r, offset: ".50", active: Math.round(100 * r.l) / 100 == 0.5 && Math.round(100 * r.s) / 100 == 0.5, onClick: t })),
                    o.default.createElement("div", { style: n.swatch }, o.default.createElement(i.default, { hsl: r, offset: ".35", active: Math.round(100 * r.l) / 100 == 0.35 && Math.round(100 * r.s) / 100 == 0.5, onClick: t })),
                    o.default.createElement("div", { style: n.swatch }, o.default.createElement(i.default, { hsl: r, offset: ".20", active: Math.round(100 * r.l) / 100 == 0.2 && Math.round(100 * r.s) / 100 == 0.5, onClick: t, last: !0 })),
                    o.default.createElement("div", { style: n.clear })
                );
            });
        t.default = l;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SliderSwatch = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.SliderSwatch = function (e) {
                var t = e.hsl,
                    r = e.offset,
                    n = e.onClick,
                    i = void 0 === n ? function () {} : n,
                    l = e.active,
                    u = e.first,
                    s = e.last,
                    c = (0, a.default)(
                        {
                            default: { swatch: { height: "12px", background: "hsl(" + t.h + ", 50%, " + 100 * r + "%)", cursor: "pointer" } },
                            first: { swatch: { borderRadius: "2px 0 0 2px" } },
                            last: { swatch: { borderRadius: "0 2px 2px 0" } },
                            active: { swatch: { transform: "scaleY(1.8)", borderRadius: "3.6px/2px" } },
                        },
                        { active: l, first: u, last: s }
                    );
                return o.default.createElement("div", {
                    style: c.swatch,
                    onClick: function (e) {
                        return i({ h: t.h, s: 0.5, l: r, source: "hsl" }, e);
                    },
                });
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SliderPointer = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = (t.SliderPointer = function () {
                var e = (0, a.default)({
                    default: { picker: { width: "14px", height: "14px", borderRadius: "6px", transform: "translate(-7px, -1px)", backgroundColor: "rgb(248, 248, 248)", boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)" } },
                });
                return o.default.createElement("div", { style: e.picker });
            });
        t.default = i;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Swatches = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = n(r(14)),
            u = n(r(13)),
            s = (function (e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                return (t.default = e), t;
            })(r(108)),
            c = r(5),
            p = n(r(307)),
            f = (t.Swatches = function (e) {
                var t = e.width,
                    r = e.height,
                    n = e.onChange,
                    a = e.onSwatchHover,
                    s = e.colors,
                    f = e.hex,
                    d = e.className,
                    _ = void 0 === d ? "" : d,
                    h = (0, i.default)({ default: { picker: { width: t, height: r }, overflow: { height: r, overflowY: "scroll" }, body: { padding: "16px 0 6px 16px" }, clear: { clear: "both" } } }),
                    b = function (e, t) {
                        u.default.isValidHex(e) && n({ hex: e, source: "hex" }, t);
                    };
                return o.default.createElement(
                    "div",
                    { style: h.picker, className: "swatches-picker " + _ },
                    o.default.createElement(
                        c.Raised,
                        null,
                        o.default.createElement(
                            "div",
                            { style: h.overflow },
                            o.default.createElement(
                                "div",
                                { style: h.body },
                                (0, l.default)(s, function (e) {
                                    return o.default.createElement(p.default, { key: e.toString(), group: e, active: f, onClick: b, onSwatchHover: a });
                                }),
                                o.default.createElement("div", { style: h.clear })
                            )
                        )
                    )
                );
            });
        (f.propTypes = { width: a.default.oneOfType([a.default.string, a.default.number]), height: a.default.oneOfType([a.default.string, a.default.number]), colors: a.default.arrayOf(a.default.arrayOf(a.default.string)) }),
            (f.defaultProps = {
                width: 320,
                height: 240,
                colors: [
                    [s.red[900], s.red[700], s.red[500], s.red[300], s.red[100]],
                    [s.pink[900], s.pink[700], s.pink[500], s.pink[300], s.pink[100]],
                    [s.purple[900], s.purple[700], s.purple[500], s.purple[300], s.purple[100]],
                    [s.deepPurple[900], s.deepPurple[700], s.deepPurple[500], s.deepPurple[300], s.deepPurple[100]],
                    [s.indigo[900], s.indigo[700], s.indigo[500], s.indigo[300], s.indigo[100]],
                    [s.blue[900], s.blue[700], s.blue[500], s.blue[300], s.blue[100]],
                    [s.lightBlue[900], s.lightBlue[700], s.lightBlue[500], s.lightBlue[300], s.lightBlue[100]],
                    [s.cyan[900], s.cyan[700], s.cyan[500], s.cyan[300], s.cyan[100]],
                    [s.teal[900], s.teal[700], s.teal[500], s.teal[300], s.teal[100]],
                    ["#194D33", s.green[700], s.green[500], s.green[300], s.green[100]],
                    [s.lightGreen[900], s.lightGreen[700], s.lightGreen[500], s.lightGreen[300], s.lightGreen[100]],
                    [s.lime[900], s.lime[700], s.lime[500], s.lime[300], s.lime[100]],
                    [s.yellow[900], s.yellow[700], s.yellow[500], s.yellow[300], s.yellow[100]],
                    [s.amber[900], s.amber[700], s.amber[500], s.amber[300], s.amber[100]],
                    [s.orange[900], s.orange[700], s.orange[500], s.orange[300], s.orange[100]],
                    [s.deepOrange[900], s.deepOrange[700], s.deepOrange[500], s.deepOrange[300], s.deepOrange[100]],
                    [s.brown[900], s.brown[700], s.brown[500], s.brown[300], s.brown[100]],
                    [s.blueGrey[900], s.blueGrey[700], s.blueGrey[500], s.blueGrey[300], s.blueGrey[100]],
                    ["#000000", "#525252", "#969696", "#D9D9D9", "#FFFFFF"],
                ],
            }),
            (t.default = (0, c.ColorWrap)(f));
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SwatchesGroup = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = n(r(14)),
            l = n(r(308)),
            u = (t.SwatchesGroup = function (e) {
                var t = e.onClick,
                    r = e.onSwatchHover,
                    n = e.group,
                    u = e.active,
                    s = (0, a.default)({ default: { group: { paddingBottom: "10px", width: "40px", float: "left", marginRight: "10px" } } });
                return o.default.createElement(
                    "div",
                    { style: s.group },
                    (0, i.default)(n, function (e, a) {
                        return o.default.createElement(l.default, { key: e, color: e, active: e.toLowerCase() === u, first: 0 === a, last: a === n.length - 1, onClick: t, onSwatchHover: r });
                    })
                );
            });
        t.default = u;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.SwatchesColor = void 0);
        var o = n(r(0)),
            a = n(r(2)),
            i = r(5),
            l = (t.SwatchesColor = function (e) {
                var t = e.color,
                    r = e.onClick,
                    n = void 0 === r ? function () {} : r,
                    l = e.onSwatchHover,
                    u = e.first,
                    s = e.last,
                    c = e.active,
                    p = (0, a.default)(
                        {
                            default: { color: { width: "40px", height: "24px", cursor: "pointer", background: t, marginBottom: "1px" }, check: { fill: "#fff", marginLeft: "8px", display: "none" } },
                            first: { color: { overflow: "hidden", borderRadius: "2px 2px 0 0" } },
                            last: { color: { overflow: "hidden", borderRadius: "0 0 2px 2px" } },
                            active: { check: { display: "block" } },
                            "color-#FFFFFF": { color: { boxShadow: "inset 0 0 0 1px #ddd" }, check: { fill: "#333" } },
                            transparent: { check: { fill: "#333" } },
                        },
                        { first: u, last: s, active: c, "color-#FFFFFF": "#FFFFFF" === t, transparent: "transparent" === t }
                    );
                return o.default.createElement(
                    i.Swatch,
                    { color: t, style: p.color, onClick: n, onHover: l, focusStyle: { boxShadow: "0 0 4px " + t } },
                    o.default.createElement(
                        "div",
                        { style: p.check },
                        o.default.createElement("svg", { style: { width: "24px", height: "24px" }, viewBox: "0 0 24 24" }, o.default.createElement("path", { d: "M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" }))
                    )
                );
            });
        t.default = l;
    },
    function (e, t, r) {
        "use strict";
        function n(e) {
            return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "__esModule", { value: !0 }), (t.Twitter = void 0);
        var o = n(r(0)),
            a = n(r(6)),
            i = n(r(2)),
            l = n(r(14)),
            u = n(r(13)),
            s = r(5),
            c = (t.Twitter = function (e) {
                var t = e.onChange,
                    r = e.onSwatchHover,
                    n = e.hex,
                    a = e.colors,
                    c = e.width,
                    p = e.triangle,
                    f = e.className,
                    d = void 0 === f ? "" : f,
                    _ = (0, i.default)(
                        {
                            default: {
                                card: { width: c, background: "#fff", border: "0 solid rgba(0,0,0,0.25)", boxShadow: "0 1px 4px rgba(0,0,0,0.25)", borderRadius: "4px", position: "relative" },
                                body: { padding: "15px 9px 9px 15px" },
                                label: { fontSize: "18px", color: "#fff" },
                                triangle: { width: "0px", height: "0px", borderStyle: "solid", borderWidth: "0 9px 10px 9px", borderColor: "transparent transparent #fff transparent", position: "absolute" },
                                triangleShadow: { width: "0px", height: "0px", borderStyle: "solid", borderWidth: "0 9px 10px 9px", borderColor: "transparent transparent rgba(0,0,0,.1) transparent", position: "absolute" },
                                hash: { background: "#F0F0F0", height: "30px", width: "30px", borderRadius: "4px 0 0 4px", float: "left", color: "#98A1A4", display: "flex", alignItems: "center", justifyContent: "center" },
                                input: {
                                    width: "100px",
                                    fontSize: "14px",
                                    color: "#666",
                                    border: "0px",
                                    outline: "none",
                                    height: "28px",
                                    boxShadow: "inset 0 0 0 1px #F0F0F0",
                                    boxSizing: "content-box",
                                    borderRadius: "0 4px 4px 0",
                                    float: "left",
                                    paddingLeft: "8px",
                                },
                                swatch: { width: "30px", height: "30px", float: "left", borderRadius: "4px", margin: "0 6px 6px 0" },
                                clear: { clear: "both" },
                            },
                            "hide-triangle": { triangle: { display: "none" }, triangleShadow: { display: "none" } },
                            "top-left-triangle": { triangle: { top: "-10px", left: "12px" }, triangleShadow: { top: "-11px", left: "12px" } },
                            "top-right-triangle": { triangle: { top: "-10px", right: "12px" }, triangleShadow: { top: "-11px", right: "12px" } },
                        },
                        { "hide-triangle": "hide" === p, "top-left-triangle": "top-left" === p, "top-right-triangle": "top-right" === p }
                    ),
                    h = function (e, r) {
                        u.default.isValidHex(e) && t({ hex: e, source: "hex" }, r);
                    };
                return o.default.createElement(
                    "div",
                    { style: _.card, className: "twitter-picker " + d },
                    o.default.createElement("div", { style: _.triangleShadow }),
                    o.default.createElement("div", { style: _.triangle }),
                    o.default.createElement(
                        "div",
                        { style: _.body },
                        (0, l.default)(a, function (e, t) {
                            return o.default.createElement(s.Swatch, { key: t, color: e, hex: e, style: _.swatch, onClick: h, onHover: r, focusStyle: { boxShadow: "0 0 4px " + e } });
                        }),
                        o.default.createElement("div", { style: _.hash }, "#"),
                        o.default.createElement(s.EditableInput, { style: { input: _.input }, value: n.replace("#", ""), onChange: h }),
                        o.default.createElement("div", { style: _.clear })
                    )
                );
            });
        (c.propTypes = { width: a.default.oneOfType([a.default.string, a.default.number]), triangle: a.default.oneOf(["hide", "top-left", "top-right"]), colors: a.default.arrayOf(a.default.string) }),
            (c.defaultProps = { width: 276, colors: ["#FF6900", "#FCB900", "#7BDCB5", "#00D084", "#8ED1FC", "#0693E3", "#ABB8C3", "#EB144C", "#F78DA7", "#9900EF"], triangle: "top-left" }),
            (t.default = (0, s.ColorWrap)(c));
    },
    function (e, t) {
        e.exports = function () {
            throw new Error("define cannot be used indirect");
        };
    },
    function (e, t) {
        (function (t) {
            e.exports = t;
        }.call(this, {}));
    },
    function (e, t) {
        e.exports = { message: "message__message--3cDIf" };
    },
    ,
    ,
    ,
    ,
    function (e, t) {
        e.exports = { scene: "scene__scene--1wGK7", shifted: "scene__shifted--2S3eq scene__scene--1wGK7" };
    },
    ,
    function (e, t) {
        e.exports = { button: "button__button--3UeOv", active: "button__active--1usaN button__button--3UeOv", icon: "button__icon--1Faoc", text: "button__text--3rz6p" };
    },
    ,
    function (e, t) {
        e.exports = { colorPicker: "color-picker__colorPicker--E2oex", brick: "color-picker__brick--3ph1e", picker: "color-picker__picker--t81YN", visible: "color-picker__visible--2VvYZ color-picker__picker--t81YN" };
    },
    ,
    function (e, t) {
        e.exports = {
            brickPicker: "brick-picker__brickPicker--1DQ8E",
            brick: "brick-picker__brick--1zfOP",
            brickIcon: "brick-picker__brickIcon--9fCAo",
            picker: "brick-picker__picker--1o4vY",
            brickExample: "brick-picker__brickExample--Qs1tz",
            brickThumb: "brick-picker__brickThumb--QVXb4",
            selected: "brick-picker__selected--4-Qhk brick-picker__brickThumb--QVXb4",
            label: "brick-picker__label--3OpYv",
        };
    },
    ,
    function (e, t) {
        e.exports = { topbar: "topbar__topbar--1cukd", section: "topbar__section--2FLBG", rightSection: "topbar__rightSection--Bn7ir topbar__section--2FLBG", title: "topbar__title--1eC9U" };
    },
    ,
    function (e, t) {
        e.exports = {
            help: "help__help--3-fxm",
            text: "help__text--2hH-a",
            inversed: "help__inversed--2NX2F help__text--2hH-a",
            modalWrapper: "help__modalWrapper--2ysOI",
            closedModal: "help__closedModal--3SXWP help__modalWrapper--2ysOI",
            modal: "help__modal--1-oGz",
            close: "help__close--N98eh",
            section: "help__section--1fwRg",
            icon: "help__icon--bV3-E",
            github: "help__github--2vkUG",
        };
    },
    ,
    function (e, t) {
        e.exports = { wrapper: "file-uploader__wrapper--2IHVd", input: "file-uploader__input--1Y5n4" };
    },
    ,
    function (e, t) {
        e.exports = {
            sidebar: "sidebar__sidebar--pPEzl",
            visible: "sidebar__visible--2TrDx sidebar__sidebar--pPEzl",
            separator: "sidebar__separator--2Xa5o",
            content: "sidebar__content--2SjCd",
            row: "sidebar__row--1rg6S",
            text: "sidebar__text--Orv4M",
        };
    },
    ,
    function (e, t) {
        e.exports = { builder: "builder__builder--UyPcr" };
    },
    ,
    function (e, t) {},
]);
//# sourceMappingURL=src/builder.bundle.js.map
