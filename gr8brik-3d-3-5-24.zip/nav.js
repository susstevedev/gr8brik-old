document.write('<ul><li><a href="../index.php">Home</a></li>');
document.write('<li><a href="index.php">Modeler</a></li>');
document.write('<li><a href="../creations/">Creations</a></li>');
document.write('<li><a href="about.php">Changelog</a></li>');
document.write('<li><a href="../account/">Account/Login</a></li></ul>');